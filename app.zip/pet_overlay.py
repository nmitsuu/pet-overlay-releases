"""
Pet Overlay for Aion 2
A small, read-only companion for "Aion 2 Pet Tracker".

It never touches the game. It only reads two files that the original tracker
already writes to %AppData%\\Aion2PetTracker:
  - tracker.log  (soul pickups, teleports)
  - pets.db      (pet icons and categories)
Both are opened read-only. Nothing is ever written to that folder.

Settings you can edit live in config.json next to this file (see README.txt).
"""

import ctypes
import json
from items import soul_pet_name, is_material, is_shugo_key
import ui as theme
import os
import re
import sqlite3
import sys
import threading
import time
import traceback
from collections import deque
from datetime import datetime, timedelta, timezone
from pathlib import Path

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer, QUrl
from PySide6.QtGui import (QAction, QColor, QCursor, QDesktopServices, QFont,
                           QFontMetricsF, QIcon, QImage, QPainter,
                           QPainterPath, QPen, QPixmap, QPolygonF)
from PySide6.QtWidgets import QApplication, QMenu, QSystemTrayIcon, QWidget

IS_WIN = sys.platform == "win32"
APP_DIR = Path(__file__).resolve().parent
CONFIG_PATH = APP_DIR / "config.json"
STATE_PATH = APP_DIR / "state.json"
NAMEMAP_PATH = APP_DIR / "name_map.json"
ERROR_LOG = APP_DIR / "overlay_error.log"

# Category number in pets.db -> (key, display name)
CATEGORIES = {1: ("cogni", "Cogni"), 2: ("fera", "Fera"),
              3: ("natura", "Natura"), 4: ("varian", "Varian")}

# What each family adds at Lv 1 / 2 / 3 (same for every pet in a family;
# source: aion2pets.app pet data, all 41/65/48/46 pets agree)
GENUS_STATS = {1: ["HP", "Crit", "Might"], 2: ["Mount Speed", "Accuracy", "Dexterity"],
               3: ["Stamina", "Crit Resist", "Precision"], 4: ["Sprint Cost", "Evasion", "Constitution"]}

DEFAULT_CONFIG = {
    "max_rows": 5,
    "fade_minutes": 5,
    "clear_on_teleport": False,
    "hide_keys": ["TAB", "K", "I", "ESC", "M", "G"],
    "show_keys": ["ESC"],
    "same_key_shows": True,
    "toggle_key": "NUMPAD_PLUS",
    "lock_hotkey": "",
    "kibelisk_label": "both",
    "data_source": "game",
    "hide_when_game_not_focused": True,
    "hover_opacity": 0.08,
    "hover_delay_seconds": 3,
    "game_window_titles": ["aion"],
    "game_window_classes": ["UnrealWindow"],
    "game_process_names": ["Aion2", "AION2", "Aion2-Win64-Shipping"],
    "write_status_file": True,
    "colours": {"cogni": "#5AA9FF", "fera": "#FF6B5E",
                "natura": "#5FD38A", "varian": "#F2C94C"},
    "tracker_data_folder": "",
}

DEFAULT_STATE = {
    "x": None, "y": None, "width": 280, "locked": False,
    "show": {"recent": True, "farm": True, "gather": True, "flight": True, "bosses": True},
    "flight_region": None,
    "farm": {"x": None, "y": None, "width": 300, "rows": 6, "open": False, "page": 0,
             "categories": {"cogni": True, "fera": True, "natura": True, "varian": True},
             "groups": {"elyos": True, "abyss": False, "asmo": False, "special": False}},
    "categories": {"cogni": True, "fera": True, "natura": True, "varian": True},
}


# --------------------------------------------------------------------------- #
# Small helpers
# --------------------------------------------------------------------------- #
def log_error(text):
    try:
        with open(ERROR_LOG, "a", encoding="utf-8") as f:
            f.write(f"{datetime.now():%Y-%m-%d %H:%M:%S}  {text}\n")
    except OSError:
        pass


def excepthook(etype, value, tb):
    log_error("".join(traceback.format_exception(etype, value, tb)))


def load_json(path, default):
    data = json.loads(json.dumps(default))  # deep copy
    try:
        with open(path, encoding="utf-8") as f:
            loaded = json.load(f)
        for k, v in loaded.items():
            if isinstance(v, dict) and isinstance(data.get(k), dict):
                data[k].update(v)
            else:
                data[k] = v
    except FileNotFoundError:
        pass
    except (OSError, ValueError) as e:
        log_error(f"Could not read {path.name}: {e} (using defaults)")
    return data


def save_json(path, data):
    try:
        tmp = path.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        os.replace(tmp, path)
    except OSError as e:
        log_error(f"Could not save {path.name}: {e}")


def tracker_folder(cfg):
    if cfg.get("tracker_data_folder"):
        return Path(os.path.expandvars(cfg["tracker_data_folder"]))
    if os.environ.get("PET_OVERLAY_DATA"):
        return Path(os.environ["PET_OVERLAY_DATA"])
    return Path(os.environ.get("APPDATA", str(Path.home()))) / "Aion2PetTracker"


def parse_log_time(s):
    # "2026-11-01 02:17:26.337"
    main, _, frac = s.partition(".")
    dt = datetime.strptime(main, "%Y-%m-%d %H:%M:%S")
    if frac:
        dt += timedelta(microseconds=int((frac + "000000")[:6]))
    return dt


# --------------------------------------------------------------------------- #
# Data: reads the original tracker's files (read-only)
# --------------------------------------------------------------------------- #
LINE_RE = re.compile(r"^(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d(?:\.\d+)?)\s+(.*?)\s*$")
PACKET_RE = re.compile(r"^Packet: soul ID (\d+) \((.*)\)$")
SOUL_RE = re.compile(r"^\+1 soul: [\u201c\"](.+?)[\u201d\"], Lv (\d+) \((?:(\d+) / (\d+)|MAX)\)")
COLLECTION_RE = re.compile(r"^Collection: [\u201c\"](.+?)[\u201d\"] (\d+) \u2192 (\d+) souls")
TELEPORT_RE = re.compile(r"^\[debug\] map: .*(entered zone|position reset)")


class Pet:
    __slots__ = ("name", "level", "cur", "need", "maxed", "last_seen",
                 "flash_at", "pet_key", "category")

    def __init__(self, name):
        self.name = name
        self.level = 0
        self.cur = 0
        self.need = 0
        self.maxed = False
        self.last_seen = None
        self.flash_at = None
        self.pet_key = None
        self.category = None


class TrackerData:
    def __init__(self, folder):
        self.folder = folder
        self.log_path = folder / "tracker.log"
        self.db_path = folder / "pets.db"
        self.game_names = []
        self.thresholds = self._read_thresholds()
        self.name_map = load_json(NAMEMAP_PATH, {})
        self.pets = {}
        self.last_teleport = None
        self.cleared_at = None
        self.teleport_seq = 0
        self.log_totals = {}       # English name -> latest soul total seen in the log
        self.pending = []          # [name, total, time, tries]
        self.icons = {}            # pet_key -> QPixmap or None
        self.categories = {}       # pet_key -> int
        self._pos = 0
        self._buf = b""
        self.ok = False
        self.changed = True

    # ---- setup ---------------------------------------------------------- #
    def _read_thresholds(self):
        try:
            with open(self.folder / "settings.json", encoding="utf-8-sig") as f:
                st = json.load(f)
            t = st.get("LevelThresholds")
            if isinstance(st.get("GameProcessNames"), list):
                self.game_names = [str(n) for n in st["GameProcessNames"]]
            if isinstance(t, list) and len(t) >= 1:
                return [int(x) for x in t]
        except (OSError, ValueError):
            pass
        return [5, 30, 105]

    def _db(self):
        uri = "file:" + self.db_path.as_posix() + "?mode=ro"
        con = sqlite3.connect(uri, uri=True, timeout=1.0)
        return con

    def _load_categories(self):
        try:
            con = self._db()
            try:
                for key, cat in con.execute("SELECT pet_key, category FROM pet_progress"):
                    self.categories[key] = cat
            finally:
                con.close()
        except sqlite3.Error as e:
            log_error(f"pets.db read failed: {e}")

    def start(self):
        self.ok = self.log_path.exists()
        if not self.ok:
            return
        self._load_categories()
        self.poll(live=False)
        self._resolve(bootstrap=True)
        for pet in self.pets.values():
            self._attach(pet)

    # ---- log reading ---------------------------------------------------- #
    def poll(self, live=True):
        if not self.log_path.exists():
            self.ok = False
            return
        self.ok = True
        try:
            size = self.log_path.stat().st_size
            if size < self._pos:          # log was rotated/cleared
                self._pos, self._buf = 0, b""
            if size == self._pos:
                return
            with open(self.log_path, "rb") as f:
                f.seek(self._pos)
                chunk = f.read()
                self._pos = f.tell()
        except OSError:
            return
        data = self._buf + chunk
        lines = data.split(b"\n")
        self._buf = lines.pop()           # keep a half-written last line
        for raw in lines:
            line = raw.decode("utf-8", errors="replace").rstrip("\r")
            m = LINE_RE.match(line)
            if not m:
                continue
            try:
                ts = parse_log_time(m.group(1))
            except ValueError:
                continue
            msg = m.group(2)
            sm = SOUL_RE.match(msg)
            if sm:
                self._on_soul(sm, ts, live)
                continue
            if TELEPORT_RE.match(msg):
                self.last_teleport = ts
                if live:
                    self.teleport_seq += 1
                self.changed = True
                continue
            pm = PACKET_RE.match(msg)
            if pm:      # pickup line; maxed pets get only this one, no "+1 soul" line
                self._on_packet(pm.group(2), ts, live)
                continue
            cm = COLLECTION_RE.match(msg)
            if cm:
                name, total = cm.group(1), int(cm.group(3))
                self.log_totals[name] = total
                if name not in self.name_map:
                    self.pending.append([name, total, ts, 0])
        if live:
            self._resolve()

    def _on_packet(self, name, ts, live):
        total = self.log_totals.get(name)
        if total is None:
            key = self.name_map.get(name)
            if key:
                try:
                    con = self._db()
                    try:
                        row = con.execute("SELECT souls FROM pet_progress WHERE pet_key=?", (key,)).fetchone()
                    finally:
                        con.close()
                    total = row[0] if row else None
                except sqlite3.Error:
                    total = None
        pet = self.pets.get(name)
        if pet is None:
            if total is None:
                return          # unknown pet: wait for its "+1 soul" line
            pet = self.pets[name] = Pet(name)
            self._attach(pet)
        if total is not None:
            pet.level, pet.cur, pet.need, pet.maxed = stage_of(total, self.thresholds)
        pet.last_seen = ts
        if live:
            pet.flash_at = time.monotonic()
        self.changed = True

    def _on_soul(self, m, ts, live):
        name = m.group(1)
        level = int(m.group(2))
        pet = self.pets.get(name)
        if pet is None:
            pet = self.pets[name] = Pet(name)
        pet.level = level
        if m.group(3) is None:
            pet.maxed, pet.cur, pet.need = True, 0, 0
            total = self.thresholds[-1]
        else:
            pet.maxed = False
            pet.cur, pet.need = int(m.group(3)), int(m.group(4))
            base = self.thresholds[level - 1] if 0 < level <= len(self.thresholds) else 0
            total = base + pet.cur
        pet.last_seen = ts
        self.log_totals[name] = total
        if live:
            pet.flash_at = time.monotonic()
        self.changed = True
        if name in self.name_map:
            if pet.pet_key is None:
                self._attach(pet)
        else:
            self.pending.append([name, total, ts, 0])

    # ---- linking English names to the tracker's pet keys ----------------- #
    def _resolve(self, bootstrap=False):
        if not self.pending:
            return
        todo = self.pending
        if bootstrap:  # newest first, one success per name is enough
            todo = sorted(todo, key=lambda p: p[2], reverse=True)
        keep = []
        try:
            con = self._db()
        except sqlite3.Error:
            return
        try:
            used = set(self.name_map.values())
            for item in todo:
                name, total, ts, tries = item
                if name in self.name_map:
                    continue
                lo = (ts - timedelta(seconds=3)).strftime("%Y-%m-%dT%H:%M:%S")
                hi = (ts + timedelta(seconds=3)).strftime("%Y-%m-%dT%H:%M:%S")
                try:
                    rows = con.execute(
                        "SELECT pet_key, at FROM souls_history WHERE souls=? AND substr(at,1,19) BETWEEN ? AND ? "
                        "UNION SELECT pet_key, updated_at FROM pet_progress WHERE souls=? AND substr(updated_at,1,19) BETWEEN ? AND ?",
                        (total, lo, hi, total, lo, hi)).fetchall()
                except sqlite3.Error:
                    rows = None
                if rows is None:          # database busy, try again later
                    keep.append(item)
                    continue
                # The tracker writes the database a few ms before the log line,
                # so the right pet is the one saved closest in time.
                best = {}
                for key, at in rows:
                    if key in used:
                        continue
                    try:
                        dt = abs((parse_log_time(at[:26].replace("T", " ").split("+")[0]) - ts).total_seconds())
                    except ValueError:
                        continue
                    best[key] = min(dt, best.get(key, 99.0))
                ranked = sorted(best.items(), key=lambda kv: kv[1])
                keys = set()
                if ranked and ranked[0][1] <= 0.6 and (
                        len(ranked) == 1 or ranked[1][1] - ranked[0][1] >= max(0.01, ranked[0][1])):
                    keys = {ranked[0][0]}
                if len(keys) == 1:
                    key = keys.pop()
                    self.name_map[name] = key
                    used.add(key)
                    self._attach(self.pets.get(name))
                elif not bootstrap and tries < 20:
                    item[3] += 1
                    keep.append(item)
        finally:
            con.close()
        self.pending = [] if bootstrap else keep
        save_json(NAMEMAP_PATH, self.name_map)

    def _attach(self, pet):
        if pet is None:
            return
        key = self.name_map.get(pet.name)
        if not key:
            return
        pet.pet_key = key
        if key not in self.categories:
            self._load_categories()
        pet.category = self.categories.get(key)
        self.changed = True

    def icon(self, key):
        if key in self.icons:
            return self.icons[key]
        pix = None
        try:
            con = self._db()
            try:
                row = con.execute("SELECT width, height, bgra FROM pet_icons WHERE pet_key=?",
                                  (key,)).fetchone()
            finally:
                con.close()
            if row:
                w, h, blob = row
                img = QImage(blob, w, h, w * 4, QImage.Format_ARGB32).copy()
                pix = QPixmap.fromImage(img)
        except sqlite3.Error:
            return None  # try again next time
        self.icons[key] = pix
        return pix

    # ---- what to show ---------------------------------------------------- #
    def visible(self, now, fade_minutes, clear_on_teleport, enabled_cats):
        cutoff = now - timedelta(minutes=fade_minutes)
        out = []
        for pet in self.pets.values():
            if pet.last_seen is None or pet.last_seen < cutoff:
                continue
            if clear_on_teleport and self.last_teleport and pet.last_seen < self.last_teleport:
                continue
            if self.cleared_at and pet.last_seen < self.cleared_at:
                continue
            if pet.category in CATEGORIES and not enabled_cats.get(CATEGORIES[pet.category][0], True):
                continue
            out.append(pet)
        out.sort(key=lambda p: p.last_seen, reverse=True)
        return out



# --------------------------------------------------------------------------- #
# Own data source: reads the game itself (game_reader.py), no original tracker
# --------------------------------------------------------------------------- #
COLLECTION_PATH = APP_DIR / "collection.json"
OPEN_WORLDS = {"20", "22", "23", "1000", "1010", "1011", "1100", "1110", "1111"}   # field maps (not dungeons)
INVENTORY_PATH = APP_DIR / "inventory.json"
ICON_DIR = APP_DIR / "maps" / "icons"


class GameData(TrackerData):
    """Same interface as TrackerData, but fed by our own packet reader."""

    def __init__(self, folder):
        super().__init__(folder)
        self.ok = True
        self.reader = None
        self.events = deque()
        self.coll = {}                       # petId -> total souls
        self.id_name, self.name_id, self.name_cat = {}, {}, {}
        try:
            with open(SPAWNS_PATH, encoding="utf-8") as f:
                for pid, name, g, _areas in json.load(f)["pets"]:
                    self.id_name[pid], self.name_id[name] = name, pid
                    self.name_cat[name] = GENUS_NUM.get(g)
        except (OSError, ValueError, KeyError) as e:
            log_error(f"pet list missing: {e}")
        saved = load_json(COLLECTION_PATH, {})
        self.coll = {int(k): int(v) for k, v in saved.get("souls", {}).items()}
        self.soul_map = {}                       # soul item id -> petId (real links, never guessed)
        try:
            with open(SPAWNS_PATH, encoding="utf-8") as f:
                self.soul_map = {int(k): v for k, v in json.load(f).get("soul_ids", {}).items()}
        except (OSError, ValueError):
            pass
        self.soul_map.update({int(k): v for k, v in saved.get("soul_map", {}).items()})
        self.pending_soul = None                 # (soul id, time) waiting for its pet-progress message
        self.bag = {}                            # item instance -> (item id, count), gathered materials only
        self.bag_changed = 0
        saved_inv = load_json(INVENTORY_PATH, {})     # last known bag + chests, so counts show before login
        self.bag = {int(k): tuple(v) for k, v in saved_inv.items() if isinstance(v, list) and len(v) == 3}
        self.full_bag = saved_inv.get("_full") == 2          # saved from a login that read every item
        self._inv_dirty, self._inv_next = False, 0.0
        self.world, self.zone_log = None, []
        self.session = {"start": time.time(), "souls": 0, "materials": 0, "kinah_in": 0, "kinah_out": 0,
                        "bkinah_in": 0, "bkinah_out": 0, "pets": {}, "mats": {}, "loot": {}, "log": []}
        self.live, self.kills = {}, []          # pets' monsters in view right now; pets you just killed
        self.content = {}                       # entries left for timed content (keys)
        self.moves = {}                         # entity -> (x, y, time) from the game's movement messages
        self.self_eid, self.char_name, self.self_pos = None, None, None
        self.region = None
        self._restore_session()
        self.boss_ids = load_json(APP_DIR / "boss_ids.json", {})      # learned: game boss id -> boss key
        self.field = {k: tuple(v) for k, v in load_json(APP_DIR / "field_bosses.json", {}).items()}
        self.field_unknown, self.field_seen = {}, 0
        if not (APP_DIR / "maps" / "boss_spots.json").exists():
            from map_builder import fetch_boss_spots
            (APP_DIR / "maps").mkdir(exist_ok=True)
            threading.Thread(target=fetch_boss_spots, args=(SPAWNS_PATH, APP_DIR / "maps" / "boss_spots.json",
                                                            log_error), daemon=True).start()
        self.gathered = deque(maxlen=500)        # (item id, amount, time) for each gathering pickup
        self.soul_counts = {}                    # item instance -> count, for souls
        self.unknown_souls = {}                  # soul item id -> time seen, waiting for its name
        from items import ItemInfo
        self.items = ItemInfo(APP_DIR / "maps")
        self.has_db = self.db_path.exists()
        # pet key per name: the original tracker's key when we know it (for its icons), else our own
        for name, pid in self.name_id.items():
            key = self.name_map.get(name) if self.has_db else None
            self.name_map[name] = key or f"id{pid}"
        self.categories = {self.name_map[n]: c for n, c in self.name_cat.items()}
        self.key_pid = {self.name_map[n]: pid for n, pid in self.name_id.items()}

    def start(self):
        try:
            from game_reader import GameReader
            self.reader = GameReader(self._on_reader, log_error)
            self.reader.start()
            from region import RegionFinder
            self.region = RegionFinder(APP_DIR, log_error)
        except Exception as e:
            log_error(f"Game reader could not start: {e}")
        for name, total in self._totals().items():
            self.log_totals[name] = total

    def _on_reader(self, kind, d):
        """Called on the packet thread. Positions and pets in view are applied at once (no wait for the
        next screen tick), so live pets show on the minimap the moment the game sends them."""
        if kind == "move":                                 # positions: live pets roaming
            eid, x, y = d
            tnow = time.time()
            self.moves[eid] = (x, y, tnow)
            if eid in self.live:
                self.live[eid] = (self.live[eid][0], x, y, tnow)
            if len(self.moves) > 400:
                self.moves = {k: v for k, v in list(self.moves.items()) if tnow - v[2] < 30}
        elif kind == "npc":                                # a pet's monster in view: live on the minimap
            eid, mon, x, y = d
            name = self.mon_name().get(mon)
            if name:
                self.live[eid] = (name, x, y, time.time())
            elif eid in self.live:
                self.live.pop(eid, None)
        elif kind == "self":                               # your character (entity id + name)
            self.self_eid = d[0]
            self.char_name = d[1] or self.char_name
        elif kind == "self_pos":                           # where you stand (sent with effects on you)
            self.self_pos = (d[0], d[1], time.time())
        else:
            self.events.append((kind, d))

    def _totals(self):
        return {self.id_name[p]: t for p, t in self.coll.items() if p in self.id_name}

    SESSION_PATH = APP_DIR / "session.json"

    def _restore_session(self):
        """Carry on the same session after the overlay restarts (an update), unless you stopped playing."""
        try:
            d = json.loads(self.SESSION_PATH.read_text(encoding="utf-8"))
            if time.time() - d.get("saved", 0) < 20 * 60:
                for k in ("mats", "loot"):
                    d[k] = {int(i): c for i, c in d.get(k, {}).items()}
                d.pop("saved", None)
                self.session.update(d)
        except (OSError, ValueError, AttributeError):
            pass

    def save_session(self):
        try:
            d = dict(self.session, saved=time.time())
            self.SESSION_PATH.write_text(json.dumps(d), encoding="utf-8")
        except (OSError, TypeError, ValueError):
            pass

    def mon_name(self):
        if not hasattr(self, "_mon_name"):
            try:
                sp = json.loads((APP_DIR / "pet_spawns.json").read_text(encoding="utf-8"))
                self._mon_name = {i: n for n, ids in sp.get("monsters", {}).items() for i in ids}
            except (OSError, ValueError):
                self._mon_name = {}
        return self._mon_name

    def _slog(self, kind, what, amount):
        """Session history, newest last; repeats of the same thing within a minute are merged."""
        log, t = self.session["log"], time.time()
        if log and log[-1][1] == kind and log[-1][2] == what and t - log[-1][0] < 60 and \
                (log[-1][3] > 0) == (amount > 0):
            log[-1][3] += amount
            log[-1][0] = t
        else:
            log.append([t, kind, what, amount])
            del log[:-200]

    def materials(self):
        """{item id: total count} for gathered materials in your bag and chests (bound or not)."""
        out = {}
        for item, count, _c in self.bag.values():
            if is_material(item, self.items.name(item)):
                out[item] = out.get(item, 0) + count
        return out

    KEYS_PATH = APP_DIR / "maps" / "event_keys.json"
    CONTENT_LOG = APP_DIR / "maps" / "content_log.jsonl"

    def event_keys(self):
        """{"shugo": n, "invasion": n}: reward keys left, from the game's content table. Which entry is which
        event is learned by itself: the entry that drops by one during that event, seen twice."""
        out = {}
        for ev, cid in self.key_ids().items():
            v = self.content.get(int(cid)) if isinstance(cid, (int, str)) and str(cid).isdigit() else None
            if v:
                out[ev] = v[0]
        return out

    def key_ids(self):
        if not hasattr(self, "_key_ids"):
            self._key_ids = load_json(self.KEYS_PATH, {})
        return {k: v for k, v in self._key_ids.items() if not k.startswith("_")}

    def _content(self, table):
        if not hasattr(self, "content"):
            self.content = {}
        self.key_ids()
        now = datetime.now(timezone.utc)
        changes = {}
        for cid, v in table.items():
            old = self.content.get(cid)
            if old != v:
                changes[cid] = v
            if old and v[0] == old[0] - 1:                   # one used just now: which event is on?
                m = now.minute
                ev = "shugo" if m < 15 else "invasion" if 30 <= m < 50 else None
                if ev:
                    seen = self._key_ids.setdefault("_seen", {}).setdefault(ev, [])
                    seen.append(cid)
                    if seen.count(cid) >= 2:                 # the same entry dropped in two events
                        self._key_ids[ev] = cid
                    save_json(self.KEYS_PATH, self._key_ids)
            self.content[cid] = v
        if changes:                                          # kept so the keys can be checked against the game
            try:
                with open(self.CONTENT_LOG, "a", encoding="utf-8") as f:
                    f.write(json.dumps([round(time.time()), {str(k): v for k, v in changes.items()}]) + "\n")
            except OSError:
                pass

    def _field_bosses(self, world, lst):
        from bosses import FIELD_IDS, FIELD, WORLD_REGION
        region = WORLD_REGION.get(world)
        spots = load_json(APP_DIR / "maps" / "boss_spots.json", {})
        for bid, alive, t, pos in lst:
            key = FIELD_IDS.get(bid) or self.boss_ids.get(str(bid))
            if pos and region:                              # alive: we know where it stands -> its name
                best, bd = None, 25000 ** 2
                for f in FIELD:
                    if f["region"] != region:
                        continue
                    for x, y in spots.get(f["name"], {}).get(str(world), []):
                        dd = (x - pos[0]) ** 2 + (y + pos[1]) ** 2     # the game's y is flipped vs the map data
                        if dd < bd:
                            best, bd = f["key"], dd
                if best and best != key and bid not in FIELD_IDS:
                    key = best
                    self.boss_ids[str(bid)] = key
                    save_json(APP_DIR / "boss_ids.json", self.boss_ids)
            if key:
                self.field[key] = (alive, t, time.time())
            else:
                self.field_unknown[bid] = (world, alive, t, pos)
        save_json(APP_DIR / "field_bosses.json", {k: list(v) for k, v in self.field.items()})
        self.field_seen = time.time()

    def record(self, kind, secs):
        """Save a short sample of the game data (kept small: 4 per kind) to learn new parts of it."""
        rd = getattr(self, "reader", None)
        if not rd:
            return
        folder = APP_DIR / "samples"
        folder.mkdir(exist_ok=True)
        n = int(time.time()) % 4
        rd.record(secs, str(folder / f"{kind}_{n}.jsonl"))

    def materials_split(self):
        """{item id: {container: count}}  (1 = bag, 2 = character chest, others = other storage)"""
        out = {}
        for item, count, c in self.bag.values():
            if not is_material(item, self.items.name(item)):
                continue
            d = out.setdefault(item, {})
            d[c] = d.get(c, 0) + count
        return out

    def own_souls(self):
        return {self.name_map[self.id_name[p]]: t for p, t in self.coll.items() if p in self.id_name}

    def _save(self):
        save_json(COLLECTION_PATH, {"souls": {str(k): v for k, v in self.coll.items()},
                                    "soul_map": {str(k): v for k, v in self.soul_map.items()}})

    def poll(self, live=True):
        changed = False
        if self.region and self.reader:
            self.region.update(self.reader.server_ip())
        if time.time() - getattr(self, "_sess_saved", 0) > 15:
            self._sess_saved = time.time()
            self.save_session()
        while self.events:
            kind, d = self.events.popleft()
            if kind == "collection":
                base = [0] + self.thresholds
                for pid, (lvl, cur) in d.items():
                    total = self.thresholds[-1] if lvl >= len(self.thresholds) else base[lvl] + cur
                    self.coll[pid] = total
                changed = True
            elif kind == "pet_souls":
                pid, amount = d
                self.session["souls"] += amount
                nm = self.id_name.get(pid)
                if nm:
                    self.kills.append((nm, time.time()))
                    self.session["pets"][nm] = self.session["pets"].get(nm, 0) + amount
                    self._slog("soul", nm, amount)
                if self.pending_soul and time.monotonic() - self.pending_soul[1] < 3:
                    self.soul_map[self.pending_soul[0]] = pid      # learn the real link
                self.pending_soul = None
                total = min(self.thresholds[-1], self.coll.get(pid, 0) + amount)
                self.coll[pid] = total
                changed |= self._show_pickup(pid, total)
            elif kind == "bag":                       # login: bag + character chest, sent whole
                self.full_bag = True
                self.record("login", 40)
                conts = {c for _i, _c, c in d.values()} | {1, 2, 15}
                self.bag = {k: v for k, v in self.bag.items() if v[2] not in conts}
                self.bag.update(d)
                self.bag_changed += 1
                self._inv_dirty = True
            elif kind == "store":                     # another chest opened: replace that chest's part
                _t, inv = d
                conts = {c for _i, _c, c in inv.values()}
                self.bag = {k: v for k, v in self.bag.items() if v[2] not in conts}
                self.bag.update(inv)
                self.bag_changed += 1
                self._inv_dirty = True
            elif kind == "item":
                item, count, inst, cont = d
                if not 534660000 <= item < 534661000:            # everything you hold (souls handled below)
                    prev = self.bag.get(inst)
                    old = prev[1] if prev else 0
                    if count:
                        self.bag[inst] = (item, count, cont)
                    else:
                        self.bag.pop(inst, None)
                    if count > old and (not prev or prev[2] == 1) and is_material(item, self.items.name(item)):
                        self.gathered.append((item, count - old, time.monotonic()))
                        self.session["materials"] += count - old
                        self.session["mats"][item] = self.session["mats"].get(item, 0) + count - old
                        self._slog("mat", item, count - old)
                    elif count > old and (not prev or prev[2] == 1) and cont == 1 and \
                            item not in (930100031, 930100001) and self.full_bag:
                        self.session["loot"][item] = self.session["loot"].get(item, 0) + count - old
                        self._slog("loot", item, count - old)
                    if item in (930100031, 930100001) and prev:           # Kinah / bound Kinah
                        k = "kinah" if item == 930100031 else "bkinah"
                        if count > old:
                            self.session[k + "_in"] += count - old
                        else:
                            self.session[k + "_out"] += old - count
                        self._slog(k, item, count - old)
                    self.bag_changed += 1
                    self._inv_dirty = True
                if 534660000 <= item < 534661000:
                    old = self.soul_counts.get(inst, 0)
                    self.soul_counts[inst] = count
                    if count > old:                          # a soul came in (they can stack)
                        pid = self.soul_map.get(item)
                        if pid and self.coll.get(pid, 0) >= self.thresholds[-1]:
                            changed |= self._show_pickup(pid, self.thresholds[-1])  # maxed: no progress message
                        elif not pid:
                            self.pending_soul = (item, time.monotonic())
                            self.unknown_souls[item] = time.monotonic()
                            self.items.name(item)            # look its name up: "Soul: <pet> (Bound)"
            elif kind == "content":
                self._content(d)
            elif kind == "field_bosses":
                self._field_bosses(*d)
            elif kind == "zone":
                if d:
                    self.world = d
                    self.zone_log = (self.zone_log + [d])[-6:]
                self.last_teleport = datetime.now()
                self.teleport_seq += 1
        for item in list(self.unknown_souls):                # name looked up: link soul -> pet
            pet = soul_pet_name(self.items.names.get(item))
            if item in self.soul_map:
                self.unknown_souls.pop(item)
            elif pet and pet in self.name_id:
                pid = self.name_id[pet]
                self.soul_map[item] = pid
                self.unknown_souls.pop(item)
                if self.coll.get(pid, 0) >= self.thresholds[-1]:
                    changed |= self._show_pickup(pid, self.thresholds[-1])
                self._save()
            elif time.monotonic() - self.unknown_souls[item] > 900:
                self.unknown_souls.pop(item)
        if self._inv_dirty and time.monotonic() > self._inv_next:
            self._inv_dirty, self._inv_next = False, time.monotonic() + 10
            inv = {str(k): list(v) for k, v in self.bag.items()}
            if self.full_bag:
                inv["_full"] = 2
            save_json(INVENTORY_PATH, inv)
        if changed:
            self.log_totals.update(self._totals())
            self.changed = True
            self._save()

    def _show_pickup(self, pid, total):
        name = self.id_name.get(pid)
        if not name:
            return False
        pet = self.pets.get(name)
        if pet is None:
            pet = self.pets[name] = Pet(name)
            pet.pet_key = self.name_map.get(name)
            pet.category = self.name_cat.get(name)
        pet.level, pet.cur, pet.need, pet.maxed = stage_of(total, self.thresholds)
        pet.last_seen = datetime.now()
        pet.flash_at = time.monotonic()
        return True

    def icon(self, key):
        """Pet picture: the original tracker's if it has one, else our own download (maps/icons/<petId>.png)."""
        if not key:
            return None
        pix = super().icon(key) if self.has_db and not key.startswith("id") else None
        if pix is not None and not pix.isNull():
            return pix
        ck = "own:" + key
        if ck in self.icons:
            return self.icons[ck]
        pid = key[2:] if key.startswith("id") else self.key_pid.get(key)
        for ext in ("png", "webp"):
            f = ICON_DIR / f"{pid}.{ext}"
            if pid and f.exists():
                p2 = QPixmap(str(f))
                if not p2.isNull():
                    self.icons[ck] = p2
                    return p2
        return None


# --------------------------------------------------------------------------- #
# Windows helpers (passive: only reads key state and the active window title)
# --------------------------------------------------------------------------- #
VK_NAMES = {"TAB": 0x09, "ESC": 0x1B, "ESCAPE": 0x1B, "ENTER": 0x0D, "SPACE": 0x20,
            "CTRL": 0x11, "SHIFT": 0x10, "ALT": 0x12, "BACKSPACE": 0x08,
            "`": 0xC0, "TILDE": 0xC0}
VK_NAMES.update({f"F{i}": 0x6F + i for i in range(1, 13)})
VK_NAMES.update({f"NUMPAD{i}": 0x60 + i for i in range(10)})
VK_NAMES.update({"NUMPAD_PLUS": 0x6B, "NUMPADPLUS": 0x6B, "ADD": 0x6B, "NUMPAD_MINUS": 0x6D,
                 "NUMPAD_STAR": 0x6A, "NUMPAD_SLASH": 0x6F, "HOME": 0x24, "END": 0x23,
                 "INSERT": 0x2D, "DELETE": 0x2E, "PAGEUP": 0x21, "PAGEDOWN": 0x22})


def pretty_key(combo):
    names = {"NUMPAD_PLUS": "Numpad +", "NUMPADPLUS": "Numpad +", "ADD": "Numpad +",
             "NUMPAD_MINUS": "Numpad -", "NUMPAD_STAR": "Numpad *", "NUMPAD_SLASH": "Numpad /"}
    return " + ".join(names.get(k.strip().upper(), k.strip().title()) for k in str(combo).split("+"))
MODIFIERS = {0x10, 0x11, 0x12}


def vk_of(name):
    name = str(name).strip().upper()
    if name in VK_NAMES:
        return VK_NAMES[name]
    if len(name) == 1 and (name.isalpha() or name.isdigit()):
        return ord(name)
    return None


class KeyWatcher:
    """Polls key state. Does not hook, block, or send any keys."""

    def __init__(self, vks):
        self.vks = {v for v in vks if v is not None}
        self.down = set()
        self.user32 = ctypes.windll.user32 if IS_WIN else None

    def is_down(self, vk):
        return bool(self.user32 and self.user32.GetAsyncKeyState(vk) & 0x8000)

    def poll(self):
        if not self.user32:
            return []
        pressed = []
        for vk in self.vks:
            d = self.is_down(vk)
            if d and vk not in self.down:
                pressed.append(vk)
            if d:
                self.down.add(vk)
            else:
                self.down.discard(vk)
        return pressed


if IS_WIN:
    from ctypes import wintypes

    class PROCESSENTRY32W(ctypes.Structure):
        _fields_ = [("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD),
                    ("th32ProcessID", wintypes.DWORD), ("th32DefaultHeapID", ctypes.c_size_t),
                    ("th32ModuleID", wintypes.DWORD), ("cntThreads", wintypes.DWORD),
                    ("th32ParentProcessID", wintypes.DWORD), ("pcPriClassBase", ctypes.c_long),
                    ("dwFlags", wintypes.DWORD), ("szExeFile", ctypes.c_wchar * 260)]


def list_processes():
    """{pid: exe name} from the Windows process list (like Task Manager).
    Does not open or touch any process."""
    out = {}
    if not IS_WIN:
        return out
    k32 = ctypes.windll.kernel32
    k32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
    k32.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
    k32.Process32FirstW.argtypes = [wintypes.HANDLE, ctypes.POINTER(PROCESSENTRY32W)]
    k32.Process32NextW.argtypes = [wintypes.HANDLE, ctypes.POINTER(PROCESSENTRY32W)]
    k32.CloseHandle.argtypes = [wintypes.HANDLE]
    snap = k32.CreateToolhelp32Snapshot(0x2, 0)
    if not snap or snap == wintypes.HANDLE(-1).value:
        return out
    try:
        e = PROCESSENTRY32W()
        e.dwSize = ctypes.sizeof(PROCESSENTRY32W)
        ok = k32.Process32FirstW(snap, ctypes.byref(e))
        while ok:
            out[e.th32ProcessID] = e.szExeFile
            ok = k32.Process32NextW(snap, ctypes.byref(e))
    finally:
        k32.CloseHandle(snap)
    return out


class GameWatcher:
    """Works out whether the game window is the active one."""

    def __init__(self, cfg, tracker_names):
        names = list(cfg.get("game_process_names") or []) + list(tracker_names or [])
        self.names = {n.lower().removesuffix(".exe") for n in names if n}
        self.cfg = cfg
        self.game_pids = set()
        self._next_scan = 0.0
        self.last = {}

    def _scan(self):
        if time.monotonic() < self._next_scan:
            return
        self._next_scan = time.monotonic() + 3.0
        procs = list_processes()
        self.game_pids = {pid for pid, exe in procs.items()
                          if exe.lower().removesuffix(".exe") in self.names}

    def info(self):
        """Returns (game_is_active, overlay_is_active)."""
        if not IS_WIN:
            return True, False
        self._scan()
        user32 = ctypes.windll.user32
        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            self.last = {"fg": "none"}
            return False, False
        pid = ctypes.c_ulong()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pid.value == os.getpid():
            self.last = {"fg": "overlay"}
            return False, True
        buf = ctypes.create_unicode_buffer(256)
        user32.GetClassNameW(hwnd, buf, 256)
        cls = buf.value
        user32.GetWindowTextW(hwnd, buf, 256)
        title = buf.value
        if self.game_pids:
            game = pid.value in self.game_pids
        else:   # game process not found yet: only trust Unreal's window class
            game = cls in self.cfg["game_window_classes"]
        self.last = {"fg_pid": pid.value, "fg_class": cls, "fg_title": title,
                     "game_pids": sorted(self.game_pids), "game_active": game}
        return game, False


class _POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


class _RECT(ctypes.Structure):
    _fields_ = [("l", ctypes.c_long), ("t", ctypes.c_long), ("r", ctypes.c_long), ("b", ctypes.c_long)]


def cursor_in(widget):
    """(inside, local point) using the real Windows cursor, so hovering works
    without clicking the overlay first."""
    if widget is None or not widget.isVisible():
        return False, None
    if IS_WIN:
        u = ctypes.windll.user32
        pt, r = _POINT(), _RECT()
        u.GetCursorPos(ctypes.byref(pt))
        u.GetWindowRect(ctypes.c_void_p(int(widget.winId())), ctypes.byref(r))
        if not (r.l <= pt.x < r.r and r.t <= pt.y < r.b):
            return False, None
        sx = widget.width() / max(1, r.r - r.l)
        sy = widget.height() / max(1, r.b - r.t)
        return True, QPointF((pt.x - r.l) * sx, (pt.y - r.t) * sy)
    g = QCursor.pos()
    if not widget.geometry().contains(g):
        return False, None
    return True, QPointF(widget.mapFromGlobal(g))


class TipCard(QWidget):
    """Small card: family name, what it gives per level, and maxed counts."""

    def __init__(self, colours):
        super().__init__()
        self.colours = colours
        self.cat = None
        self.counts = None
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool
                            | Qt.WindowDoesNotAcceptFocus | Qt.WindowTransparentForInput)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)

    def show_for(self, cat, counts, anchor):
        self.cat, self.counts = cat, counts
        t1, t2, t3 = self._lines()
        f1, f2 = _font(12, QFont.DemiBold), _font(10.5)
        w = int(max(QFontMetricsF(f1).horizontalAdvance(t1) + 22,
                    QFontMetricsF(f2).horizontalAdvance(t2), QFontMetricsF(f2).horizontalAdvance(t3)) + 24)
        self.resize(w, 66)
        scr = QApplication.screenAt(anchor) or QApplication.primaryScreen()
        g = scr.availableGeometry()
        x = min(anchor.x() + 12, g.right() - w - 4)
        y = min(anchor.y() + 14, g.bottom() - 70)
        self.move(int(x), int(y))
        self.update()
        if not self.isVisible():
            self.show()

    def _lines(self):
        key, label = CATEGORIES[self.cat]
        st = GENUS_STATS[self.cat]
        t2 = f"Lv1 {st[0]}  \u00b7  Lv2 {st[1]}  \u00b7  Lv3 {st[2]}"
        if self.counts:
            ma, ta, mf, tf = self.counts
            t3 = f"Farmable maxed {mf}/{tf}   \u00b7   All {ma}/{ta}"
        else:
            t3 = ""
        return label, t2, t3

    def paintEvent(self, _):
        if self.cat not in CATEGORIES:
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.TextAntialiasing)
        w, h = self.width(), self.height()
        col = QColor(self.colours.get(CATEGORIES[self.cat][0], "#ccc"))
        p.setPen(QPen(QColor(col.red(), col.green(), col.blue(), 90), 1))
        p.setBrush(QColor(9, 11, 17, 182))
        p.drawRoundedRect(QRectF(0.5, 0.5, w - 1, h - 1), 6, 6)
        t1, t2, t3 = self._lines()
        p.setPen(Qt.NoPen)
        p.setBrush(col)
        p.drawPolygon(Overlay._diamond(16, 18, 5))
        p.setFont(_font(12, QFont.DemiBold))
        p.setPen(col)
        p.drawText(QPointF(28, 22.5), t1)
        p.setFont(_font(10.5))
        p.setPen(QColor(255, 255, 255, 220))
        p.drawText(QPointF(12, 41), t2)
        p.setPen(QColor(255, 255, 255, 140))
        p.drawText(QPointF(12, 57), t3)


class MapCard(QWidget):  # noqa
    """Map picture of where a pet spawns, shown while you rest the mouse on it."""
    SIZE = 320

    def __init__(self):
        super().__init__()
        self.pix, self.title, self.sub, self.msg = None, "", "", ""
        self._cache = {}
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool
                            | Qt.WindowDoesNotAcceptFocus | Qt.WindowTransparentForInput)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)

    def show_for(self, store, name, world, area, body, title=None):
        self.SIZE = int(320 * max(0.75, theme.UI._inst.S if theme.UI._inst else 1.0))
        self.title, self.sub = title or name, area
        self.pix, self.msg = None, ""
        self.marks = store.entry(name, world) if store and hasattr(store, "entry") else None
        path = store.path_for(name, world) if store else None
        if path and path.exists():
            self.pix = self.load(path)
        elif store and store.status in ("building", "idle"):
            self.msg = store.progress or "Preparing maps..."
        elif store and store.status == "failed":
            self.msg = store.progress
        else:
            self.msg = "No map for this pet"
        h = 42 + self.SIZE + 8 if self.pix else 70
        self.resize(self.SIZE + 16, h)
        g = body.frameGeometry()
        scr = (QApplication.screenAt(g.center()) or QApplication.primaryScreen()).availableGeometry()
        x = g.x() - self.width() - 8
        if x < scr.left():
            x = g.right() + 8
        y = min(max(scr.top(), QCursor.pos().y() - h // 2), scr.bottom() - h)
        self.move(int(x), int(y))
        self.update()
        if not self.isVisible():
            self.show()

    def paint_controls(self, p, w):
        pass

    def _marks(self, p, r):
        m = self.marks
        if not m:
            return
        k = r.width() / float(m.get("size", 640))
        colours = getattr(self, "colours", DEFAULT_CONFIG["colours"])
        key = {"C": "cogni", "F": "fera", "N": "natura", "V": "varian"}.get(m.get("genus"), "")
        col = QColor(colours.get(key, "#dddddd"))
        if m.get("genus") == "B":
            col = QColor("#F2C94C")
        if m.get("genus") == "R":                 # materials: colour of the crafting system they feed
            from items import craft_of
            col = QColor(craft_of(self.title)[1])
        P = lambda x, y: QPointF(r.x() + x * k, r.y() + y * k)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(255, 255, 255, 150))
        for x, y, num, main in m.get("kibs", []):
            if not main:
                p.drawPolygon(Overlay._diamond(P(x, y).x(), P(x, y).y(), 4))
        p.setBrush(col)
        for x, y in m.get("dots", []):
            p.drawEllipse(P(x, y), 4.5, 4.5)
        for x, y, num, main in m.get("kibs", []):
            if not main:
                continue
            q = P(x, y)
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(255, 255, 255))
            p.drawPolygon(Overlay._diamond(q.x(), q.y(), 7))
            if num:
                f = _font(12.5, QFont.DemiBold)
                fm = QFontMetricsF(f)
                t = str(num)
                tw = fm.horizontalAdvance(t)
                ty = q.y() - 11 if q.y() - r.y() > 26 else q.y() + 11 + fm.ascent()
                tx = min(max(r.x() + 6, q.x() - tw / 2), r.right() - 6 - tw)
                p.setFont(f)
                p.setPen(QColor(255, 255, 255))
                p.drawText(QPointF(tx, ty), t)

    def load(self, path):
        """Pixmap already scaled to the size it's shown at, kept in memory."""
        key = str(path)
        pix = self._cache.get(key)
        if pix is None:
            scr = QApplication.primaryScreen()
            dpr = scr.devicePixelRatio() if scr else 1.0
            side = int(self.SIZE * dpr)
            img = QImage(key)
            if img.isNull():
                return None
            pix = QPixmap.fromImage(img.scaled(side, side, Qt.IgnoreAspectRatio, Qt.SmoothTransformation))
            pix.setDevicePixelRatio(dpr)
            self._cache[key] = pix
        return pix

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        p.setRenderHint(QPainter.TextAntialiasing)
        w, h = self.width(), self.height()
        cw = getattr(self, "ctrl_w", 0)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(14, 17, 24, 228))
        p.drawRoundedRect(QRectF(0, 0, w, h), 10, 10)
        p.setFont(_font(12, QFont.DemiBold))
        p.setPen(QColor(255, 255, 255, 235))
        fm = QFontMetricsF(_font(12, QFont.DemiBold))
        p.drawText(QPointF(10, 20), fm.elidedText(self.title, Qt.ElideRight, w - 20 - cw))
        p.setFont(_font(10))
        p.setPen(QColor(255, 255, 255, 150))
        p.drawText(QPointF(10, 35), QFontMetricsF(_font(10)).elidedText(self.sub, Qt.ElideRight, w - 20 - cw))
        self.paint_controls(p, w)
        if self.pix:
            r = QRectF(8, 42, self.SIZE, self.SIZE)
            path = QPainterPath()
            path.addRoundedRect(r, 5, 5)
            p.setClipPath(path)
            p.drawPixmap(r, self.pix, QRectF(self.pix.rect()))
            p.fillRect(r, QColor(8, 10, 16, 90))      # dimmed so the marks stand out
            self._marks(p, r)
        else:
            p.setPen(QColor(255, 255, 255, 120))
            p.drawText(QRectF(10, 40, w - 20, 24), Qt.AlignLeft | Qt.AlignVCenter, self.msg)


class PinCard(MapCard):
    """A map card that stays open (click a row): ‹ › flicks through that pet's / material's spots."""

    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool | Qt.WindowDoesNotAcceptFocus)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.setMouseTracking(True)
        self.ctrl_w = 92
        self.spots, self.idx, self.store, self.body, self.anchor = [], 0, None, None, None
        self.hits, self.hover = [], None

    def open(self, store, spots, idx, body):
        same = self.isVisible() and self.spots == spots
        self.store, self.spots, self.idx, self.body = store, spots, idx % max(1, len(spots)), body
        if same:
            self.close_card()
            return
        self.anchor = None
        self._show()

    def _show(self):
        key, world, sub, title = self.spots[self.idx]
        n = len(self.spots)
        pos = self.anchor
        self.show_for(self.store, key, world, sub, self.body, title)
        if pos is not None:
            self.move(pos)
        self.anchor = self.pos()
        self.update()

    def flick(self, d):
        if len(self.spots) > 1:
            self.idx = (self.idx + d) % len(self.spots)
            self._show()

    def close_card(self):
        self.spots = []
        self.suspended = False
        self.hide()

    def suspend(self, on):
        """Hide with the rest of the overlay (full-screen windows, alt-tab) and come back after."""
        if on and self.isVisible():
            self.suspended = True
            self.hide()
        elif not on and getattr(self, "suspended", False) and self.spots:
            self.suspended = False
            self.show()
            self.raise_()

    def paint_controls(self, p, w):
        self.hits = []
        n = len(self.spots)
        x = w - 10
        # close ×
        r = QRectF(x - 20, 8, 20, 20)
        p.setPen(Qt.NoPen)
        if self.hover == "close":
            p.setBrush(QColor("#262C3A"))
            p.drawRoundedRect(r, 5, 5)
        p.setPen(QPen(QColor(255, 255, 255, 220 if self.hover == "close" else 150), 1.6, Qt.SolidLine, Qt.RoundCap))
        c = r.center()
        p.drawLine(QPointF(c.x() - 4, c.y() - 4), QPointF(c.x() + 4, c.y() + 4))
        p.drawLine(QPointF(c.x() + 4, c.y() - 4), QPointF(c.x() - 4, c.y() + 4))
        self.hits.append((r, "close"))
        if n > 1:
            f = _font(11, QFont.DemiBold)
            t = f"{self.idx + 1}/{n}"
            tw_ = QFontMetricsF(f).horizontalAdvance(t)
            nr = QRectF(r.x() - 24, 8, 20, 20)
            tx = nr.x() - 2 - tw_
            pr = QRectF(tx - 22, 8, 20, 20)
            for rr_, d, tag in ((pr, -1, "prev"), (nr, 1, "next")):
                p.setPen(Qt.NoPen)
                if self.hover == tag:
                    p.setBrush(QColor("#262C3A"))
                    p.drawRoundedRect(rr_, 5, 5)
                cc = rr_.center()
                p.setPen(QPen(QColor(255, 255, 255, 230 if self.hover == tag else 170), 1.8, Qt.SolidLine,
                              Qt.RoundCap, Qt.RoundJoin))
                p.drawPolyline([QPointF(cc.x() - 2 * d, cc.y() - 4), QPointF(cc.x() + 2 * d, cc.y()),
                                QPointF(cc.x() - 2 * d, cc.y() + 4)])
                self.hits.append((rr_, tag))
            p.setFont(f)
            p.setPen(QColor(255, 255, 255, 210))
            p.drawText(QPointF(tx, 22), t)

    def _hit(self, pos):
        for r, tag in self.hits:
            if r.contains(pos):
                return tag
        return None

    def mousePressEvent(self, e):
        tag = self._hit(e.position())
        if tag is None and e.position().y() < 40:        # drag the card by its title
            self._drag = e.globalPosition().toPoint() - self.pos()
            return
        if tag == "close":
            self.close_card()
        elif tag == "prev":
            self.flick(-1)
        elif tag == "next":
            self.flick(1)

    def mouseMoveEvent(self, e):
        if getattr(self, "_drag", None) is not None:
            self.move(e.globalPosition().toPoint() - self._drag)
            self.anchor = self.pos()
            return
        tag = self._hit(e.position())
        if tag != self.hover:
            self.hover = tag
            self.setCursor(Qt.PointingHandCursor if tag else (Qt.SizeAllCursor if e.position().y() < 40 else Qt.ArrowCursor))
            self.update()

    def mouseReleaseEvent(self, e):
        self._drag = None

    def wheelEvent(self, e):
        d = e.angleDelta().y() or e.angleDelta().x()
        if d:
            self.flick(-1 if d > 0 else 1)


# --------------------------------------------------------------------------- #
# The overlay window
# --------------------------------------------------------------------------- #
BASE_W = 280.0
PAD, HEADER_H, ROW_H, ICON, GAP = 8.0, 24.0, 40.0, 30.0, 9.0
FLASH_SECS = 1.4
COUNTS_H = 34.0
NOTICE_H = 30.0


class Overlay(QWidget):
    def __init__(self, cfg, state, data):
        super().__init__()
        self.cfg, self.state, self.data = cfg, state, data
        self.locked = True
        state["locked"] = True
        self.rows = []
        self.opacity = 0.0
        self.menu_hidden = False
        self.hidden_by = None
        self.hover_cat = None
        self.cat_rects = {}
        self.drag = None          # ("move", offset) or ("resize", start_x, start_w)
        self._tick_n = 0
        self._save_due = None

        self.colours = {k: QColor(v) for k, v in cfg["colours"].items()}
        self.hide_vks = {vk_of(k) for k in cfg["hide_keys"]} - {None}
        self.show_vks = {vk_of(k) for k in cfg["show_keys"]} - {None}
        self.lock_combo = [vk_of(k) for k in str(cfg.get("lock_hotkey") or "").split("+") if k.strip()]
        self.keys = KeyWatcher(self.hide_vks | self.show_vks | set(self.lock_combo) | MODIFIERS)
        self.game = GameWatcher(cfg, data.game_names)
        self.toggle_vk = vk_of(cfg.get("toggle_key", "NUMPAD_MINUS"))
        if self.toggle_vk:
            self.keys.vks.add(self.toggle_vk)
        self.force = None          # None = automatic, "show" / "hide" = toggle key
        self._last_game_fg = False
        self._was_covered = False
        self._tp_seen = data.teleport_seq
        self.tips = []             # (rect, category) hover targets, filled while painting
        self.counts = {}
        self._counts_next = 0.0
        self.card = TipCard(self.colours)
        self.mapcard = MapCard()
        self.mapcard.colours = self.colours
        from hud import HudWatcher
        self.hud = HudWatcher()
        self.pin = PinCard()
        self.pin.colours = self.colours
        self.maps = None
        self._tip = None
        self.keys_seen = 0
        self.last_key = None
        # If the game runs as admin, Windows hides its key presses from us.
        # We notice that if the game is active for a while and we never see
        # movement keys or mouse buttons go down.
        self.probe_vks = [0x57, 0x41, 0x53, 0x44, 0x20, 0x01, 0x02]
        self.probe_seen = False
        self.game_active_secs = 0.0
        self.keys_blocked = False
        try:
            self.is_admin = bool(ctypes.windll.shell32.IsUserAnAdmin()) if IS_WIN else False
        except Exception:
            self.is_admin = False

        self.setWindowTitle("Pet Overlay")
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.setMouseTracking(True)
        self._apply_flags()

        w = int(state.get("width") or BASE_W)
        screen = QApplication.primaryScreen().availableGeometry()
        x = state.get("x")
        y = state.get("y")
        if x is None or y is None:
            x, y = screen.right() - w - 40, screen.top() + 220
        self.resize(w, 60)
        self.move(int(x), int(y))

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.tick)
        self.timer.start(30)

    # ---- window flags / lock -------------------------------------------- #
    def _apply_flags(self):
        flags = (Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool
                 | Qt.WindowDoesNotAcceptFocus)
        if self.locked:
            flags |= Qt.WindowTransparentForInput
        self.setWindowFlags(flags)

    def set_locked(self, locked):
        self.locked = locked
        visible = self.isVisible()
        self._apply_flags()
        if visible:
            self.show()
        self.state["locked"] = locked
        if getattr(self, "farm", None):
            self.farm.set_locked(locked)
        self._queue_save()
        self._relayout()
        if hasattr(self, "tray_lock_action"):
            self.tray_lock_action.setText("Move / resize Farm" if locked else "Done moving")

    def toggle_lock(self):
        self.set_locked(not self.locked)

    def clear_list(self):
        self.data.cleared_at = datetime.now()
        self.data.changed = True

    # ---- geometry helpers ----------------------------------------------- #
    def s(self):
        return self.width() / BASE_W

    def _content_height(self):
        s = self.s()
        h = PAD * 2
        if not self.locked:
            h += HEADER_H
        n = len(self.rows)
        if n == 0 and not self.locked:
            n = 1  # room for the "waiting" message
        h += n * ROW_H + COUNTS_H
        if self.keys_blocked:
            h += NOTICE_H
        return max(int(round(h * s)), 1)

    def _relayout(self):
        h = self._content_height()
        if h != self.height():
            self.resize(self.width(), h)
        self.update()

    def _queue_save(self):
        self._save_due = time.monotonic() + 0.6
        QTimer.singleShot(700, self._save_now)            # saves even while the overlay is hidden

    def _save_now(self):
        if self._save_due:
            self._save_due = None
            save_json(STATE_PATH, self.state)

    # ---- main loop ------------------------------------------------------- #
    def tick(self):
        self._tick_n += 1
        now_m = time.monotonic()

        # keys
        for vk in self.keys.poll():
            self.keys_seen += 1
            self.last_key = vk
            self._on_key(vk)

        # data (every ~300 ms)
        if self._tick_n % 10 == 1:
            self.data.poll()
            rows = self.data.visible(datetime.now(), self.cfg["fade_minutes"],
                                     self.cfg["clear_on_teleport"], self.state["categories"])
            rows = rows[: max(1, int(self.cfg["max_rows"]))]
            if self.data.teleport_seq != self._tp_seen:   # map closes itself on teleport
                self._tp_seen = self.data.teleport_seq
                self.menu_hidden = False
                self.hidden_by = None
            if now_m >= self._counts_next:
                self._counts_next = now_m + 3.0
                self.counts = self.compute_counts()
                self.update()
            if [id(r) for r in rows] != [id(r) for r in self.rows] or self.data.changed:
                self.rows = rows
                self.data.changed = False
                self._relayout()

        # keep on top (some borderless games push other windows down)
        if IS_WIN and self._tick_n % 66 == 0 and self.isVisible():
            HWND_TOPMOST, SWP = -1, 0x0001 | 0x0002 | 0x0010
            ctypes.windll.user32.SetWindowPos(int(self.winId()), HWND_TOPMOST, 0, 0, 0, 0, SWP)

        # visibility + fade
        game_fg, self_fg = self.game.info()
        if IS_WIN and game_fg and not self.probe_seen:
            if any(self.keys.is_down(v) for v in self.probe_vks):
                self.probe_seen = True
                if self.keys_blocked:
                    self.keys_blocked = False
                    self._relayout()
            else:
                self.game_active_secs += 0.03
                if self.game_active_secs > 45 and not self.keys_blocked and not self.is_admin:
                    self.keys_blocked = True
                    self._relayout()
        if game_fg and not self._last_game_fg and self.force == "show":
            self.force = None                 # back in the game: automatic again
        self._last_game_fg = game_fg
        auto = not (self.cfg["hide_when_game_not_focused"] and not (game_fg or self_fg))
        if self.force == "hide":
            want = False
        elif self.force == "show":
            want = not self.menu_hidden
        else:
            want = auto and not self.menu_hidden
        self._auto_want = auto
        inside = self.locked and cursor_in(self)[0]
        show = self.state.get("show", {})
        want_recent = False                     # the old list window is replaced by the Pets panel
        self._hover_t = (getattr(self, "_hover_t", None) or now_m) if inside else None
        target = 1.0 if want_recent else 0.0
        if target > 0 and not self.isVisible():
            self.opacity = 0.0
            self.setWindowOpacity(0.0)
            self.show()
        self.opacity += (target - self.opacity) * 0.28
        if abs(target - self.opacity) < 0.01:
            self.opacity = target
        self.setWindowOpacity(self.opacity)
        if self.opacity <= 0.01 and self.isVisible() and target == 0:
            self.hide()
        if getattr(self, "ui", None):
            if self._tick_n % 3 == 1:                    # full-screen game window / popup, or a dungeon? (~90 ms)
                covered = False
                if game_fg and IS_WIN:
                    import ctypes
                    covered = self.hud.update(ctypes.windll.user32.GetForegroundWindow())
                w = getattr(self.data, "world", None)
                dungeon = bool(w) and str(w) not in OPEN_WORLDS
                if covered and not self._was_covered:      # a full-screen window opened: sample it (keys etc.)
                    self.data.record("window", 15) if hasattr(self.data, "record") else None
                self._was_covered = covered
                self.ui.auto_fold = covered or dungeon
                mv = getattr(self, "mapview", None)
                if mv is not None:
                    import ctypes
                    from hud import client_rect
                    hw = ctypes.windll.user32.GetForegroundWindow() if game_fg else None
                    try:
                        cr = client_rect(hw) if hw else None
                        mv.tick(game_fg, hw, covered, cr)
                        mm = getattr(self, "minimap", None)
                        if mm is not None:
                            mm.tick(game_fg and not covered and not dungeon, cr)
                    except Exception as e:
                        log_error(f"map overlay: {e}")
            self.ui.tick(want, self.rows)
        if getattr(self, "flight", None) and self._tick_n % 8 == 3:
            import ctypes
            hw = ctypes.windll.user32.GetForegroundWindow() if (IS_WIN and game_fg) else None
            self.flight.tick(game_fg and not getattr(self.ui, "auto_fold", False), hw)
        if getattr(self, "bosses", None) and self._tick_n % 33 == 11:
            self.bosses.tick()
        self._update_tip(want, now_m)
        self._preload_maps()

        # animations (flash + fade-out) need repaints
        if any(r.flash_at and now_m - r.flash_at < FLASH_SECS for r in self.rows) or self._tick_n % 33 == 0:
            self.update()

        if self.cfg.get("write_status_file") and self._tick_n % 66 == 5:
            self._write_status(game_fg)

        if self._save_due and now_m >= self._save_due:
            self._save_due = None
            self.state.update(x=self.x(), y=self.y(), width=self.width())
            save_json(STATE_PATH, self.state)

    def compute_counts(self):
        """{category: (maxed_all, total_all, maxed_farmable, total_farmable)}"""
        fd = getattr(self, "fd", None)
        if fd is None:
            return {}
        fd.refresh()
        top = self.data.thresholds[-1]
        out = {c: [0, 0, 0, 0] for c in CATEGORIES}
        if not self.data.categories:
            self.data._load_categories()
        for key, cat in self.data.categories.items():
            if cat in out:
                out[cat][1] += 1
                if fd.souls.get(key, 0) >= top:
                    out[cat][0] += 1
        for pid, name, g, areas in fd.pets:
            cat = GENUS_NUM.get(g)
            if cat not in out or not areas or name in fd.special:
                continue
            out[cat][3] += 1
            key = self.data.name_map.get(name)
            total = fd.souls.get(key) if key else self.data.log_totals.get(name, 0)
            if (total or 0) >= top:
                out[cat][2] += 1
        return {c: tuple(v) for c, v in out.items()}

    def _preload_maps(self):
        m = self.maps
        if not m or m.status != "ready":
            return
        if getattr(self, "_preload_queue", None) is None:
            self._preload_queue = [m.dir / e["png"] for worlds in m.index.values()
                                   for e in worlds.values() if isinstance(e, dict)]
        for _ in range(3):
            if not self._preload_queue:
                return
            path = self._preload_queue.pop()
            if path.exists():
                self.mapcard.load(path)

    def open_pin(self, payload, body):
        spots = payload[5] if len(payload) > 5 and payload[5] else [(payload[1], payload[2], payload[3], payload[4])]
        self.mapcard.hide()
        self.pin.open(self.maps, spots, payload[6] if len(payload) > 6 else 0, body)

    def _update_tip(self, want, now_m):
        target = None
        folded = getattr(getattr(self, "ui", None), "auto_fold", False) and not self.ui.fold_override
        self.pin.suspend(not want or folded)
        if self.pin.isVisible():                       # a pinned map is open: no hover cards
            if self.mapcard.isVisible():
                self.mapcard.hide()
            want = False
        if want:
            widgets = [self]
            if getattr(self, "ui", None):
                widgets += [w for w in self.ui.panels() if w.isVisible()]
            for w in widgets:
                inside, lp = cursor_in(w)
                if not inside:
                    continue
                for rect, payload in getattr(w, "tips", []):
                    if rect.contains(lp):
                        target = (id(w), payload, w, rect)
                        break
                if target:
                    break
        if target is None:
            self._tip = None
            for c in (self.card, self.mapcard):
                if c.isVisible():
                    c.hide()
            return
        key = target[:2]
        if not self._tip or self._tip[0] != key:
            self._tip = (key, now_m, False)
            for c in (self.card, self.mapcard):
                if c.isVisible():
                    c.hide()
            return
        delay = 0.12 if isinstance(target[1], tuple) else 0.45
        if now_m - self._tip[1] >= delay and not self._tip[2]:
            self._tip = (key, self._tip[1], True)
            w, payload, rect = target[2], target[1], target[3]
            if isinstance(payload, tuple) and payload[0] == "map":
                self.mapcard.show_for(self.maps, payload[1], payload[2], payload[3], w,
                                      payload[4] if len(payload) > 4 else payload[1])
            else:
                anchor = w.mapToGlobal(rect.bottomLeft().toPoint())
                self.card.show_for(payload, self.counts.get(payload), anchor)

    def _write_status(self, game_fg):
        info = dict(self.game.last)
        lines = [
            f"time: {datetime.now():%H:%M:%S}   app: {QApplication.instance().updater.status() if hasattr(QApplication.instance(), 'updater') else '-'}",
            f"character: {getattr(self.data, 'char_name', None) or 'not seen yet'}   region: "
            f"{self.data.region.status() if getattr(self.data, 'region', None) else '-'}",
            f"event keys: {self.data.event_keys() if hasattr(self.data, 'event_keys') else '-'}",
            f"game detected as active window: {'YES' if game_fg else 'no'}",
            f"active window: {info}",
            f"keys noticed so far: {self.keys_seen} (last: {self.last_key})",
            f"locked: {self.locked}   shown: {self.isVisible()}   opacity: {self.opacity:.2f}",
            f"hidden by menu key: {self.menu_hidden}   toggle: {self.force}   mouse over list: {cursor_in(self)[0]}",
            f"pets on list: {len(self.rows)}   tracker data found: {self.data.ok}",
            f"game reader: {getattr(getattr(self.data, 'reader', None), 'status', 'off')}  packets {getattr(getattr(self.data, 'reader', None), 'packets', 0)}  messages {getattr(getattr(self.data, 'reader', None), 'messages', 0)}",
            f"boss alerts sent: {getattr(getattr(self, 'bosses', None), 'log', [])}",
            f"last mouse wheel: {theme.UI.last_wheel}",
            f"window check: {getattr(getattr(self, 'hud', None), 'state', '-')} ({getattr(getattr(self, 'hud', None), 'last', '')})  zone: {getattr(self.data, 'world', None)} seen {getattr(self.data, 'zone_log', [])}",
            f"flight: {self.flight.status() if getattr(self, 'flight', None) else '-'}",
            f"map overlay: {self.mapview.status() if getattr(self, 'mapview', None) else '-'}",
            f"minimap overlay: {self.minimap.status() if getattr(self, 'minimap', None) else '-'}",
            f"field bosses known: {len(getattr(self.data, 'field', {}))}  unknown ids: {sorted(getattr(self.data, 'field_unknown', {}))}",
            f"souls linked: {len(getattr(self.data, 'soul_map', {}))}   waiting for names: {len(getattr(self.data, 'unknown_souls', {}))}",
            f"running as admin: {self.is_admin}   game keys visible: {self.probe_seen}   keys look blocked: {self.keys_blocked}",
        ]
        try:
            (APP_DIR / "overlay_status.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
        except OSError:
            pass

    def _on_key(self, vk):
        game_fg, _ = self.game.info()
        if not game_fg:            # hotkeys only count inside the Aion window
            return
        if vk == 0x1B and self.pin.isVisible():
            self.pin.close_card()
        if self.lock_combo and None not in self.lock_combo and vk in self.lock_combo:
            if all(self.keys.is_down(k) for k in self.lock_combo):
                self.toggle_lock()
                return
        if vk in MODIFIERS:
            return
        if self.keys.is_down(0x11) or self.keys.is_down(0x12):  # Ctrl/Alt combos
            return
        if vk == 0x4D and getattr(self.data, "reader", None):    # M: the map (with its Field Boss list)
            n = len(list(APP_DIR.glob("map_capture_*.jsonl")))
            if n < 6:
                self.data.reader.record(25, str(APP_DIR / f"map_capture_{n + 1}.jsonl"))
        if vk == self.toggle_vk:
            if self.force != "hide" and not self.menu_hidden:
                self.force = "hide"
            else:
                self.force = None
                self.menu_hidden = False
                self.hidden_by = None
            return
        if self.menu_hidden:
            if vk in self.show_vks or (self.cfg["same_key_shows"] and vk == self.hidden_by):
                self.menu_hidden = False
                self.hidden_by = None
            elif vk in self.hide_vks:
                self.hidden_by = vk       # switched to another menu
        elif vk in self.hide_vks:
            self.menu_hidden = True
            self.hidden_by = vk

    # ---- painting -------------------------------------------------------- #
    def _font(self, px, weight=QFont.Normal, spacing=0.0):
        f = QFont(theme.BODY)
        f.setPixelSize(max(6, int(round(px))))
        f.setWeight(weight)
        if spacing:
            f.setLetterSpacing(QFont.AbsoluteSpacing, spacing)
        f.setHintingPreference(QFont.PreferNoHinting)
        return f

    def _cat_colour(self, cat):
        if cat in CATEGORIES:
            return QColor(self.colours.get(CATEGORIES[cat][0], QColor(200, 200, 200)))
        return QColor(190, 190, 200)

    @staticmethod
    def _diamond(cx, cy, r):
        return QPolygonF([QPointF(cx, cy - r), QPointF(cx + r, cy),
                          QPointF(cx, cy + r), QPointF(cx - r, cy)])

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        p.setRenderHint(QPainter.TextAntialiasing)
        s = self.s()
        w, h = self.width(), self.height()

        self.tips = []
        # panel
        p.setPen(QPen(QColor(255, 255, 255, 24), 1))
        p.setBrush(QColor(9, 11, 17, 178))
        p.drawRoundedRect(QRectF(0.5, 0.5, w - 1, h - 1), 6 * s, 6 * s)

        y = PAD * s
        x0 = PAD * s
        right = w - PAD * s

        if not self.locked:
            self._paint_header(p, s, x0, y, right)
            y += HEADER_H * s
        self._paint_counts(p, s, x0, y, right)
        y += COUNTS_H * s

        if self.keys_blocked:
            p.setPen(QColor(255, 200, 120, 230))
            p.setFont(self._font(10 * s))
            p.drawText(QRectF(x0, y, right - x0, NOTICE_H * s), Qt.AlignCenter | Qt.TextWordWrap,
                       "Game keys hidden: restart with run_as_admin.bat")
            y += NOTICE_H * s

        if not self.rows:
            if not self.locked:
                p.setPen(QColor(255, 255, 255, 110))
                p.setFont(self._font(11 * s))
                msg = ("Waiting for souls..." if self.data.ok
                       else "Can't find the tracker's data folder")
                p.drawText(QRectF(x0, y, right - x0, ROW_H * s), Qt.AlignCenter, msg)
                y += ROW_H * s
        else:
            now_dt = datetime.now()
            now_m = time.monotonic()
            fade_end = timedelta(minutes=self.cfg["fade_minutes"])
            for pet in self.rows:
                self._paint_row(p, s, pet, x0, y, right, now_dt, now_m, fade_end)
                y += ROW_H * s
            p.setOpacity(1.0)

    def _paint_counts(self, p, s, x0, y, right):
        p.setPen(QPen(QColor(255, 255, 255, 20), 1))
        if self.rows or not self.locked:
            p.drawLine(QPointF(x0, y + COUNTS_H * s - 2), QPointF(right, y + COUNTS_H * s - 2))
        colw = (right - x0) / 4
        big, small = self._font(11 * s, QFont.DemiBold), self._font(9 * s)
        for i, (num, (key, label)) in enumerate(CATEGORIES.items()):
            cx = x0 + i * colw
            col = QColor(self.colours.get(key))
            ma, ta, mf, tf = self.counts.get(num, (0, 0, 0, 0))
            p.setPen(Qt.NoPen)
            p.setBrush(col)
            p.drawPolygon(self._diamond(cx + 5 * s, y + 12 * s, 4 * s))
            p.setFont(big)
            p.setPen(QColor(255, 255, 255, 225))
            p.drawText(QPointF(cx + 13 * s, y + 14 * s), f"{mf}/{tf}")
            p.setFont(small)
            p.setPen(QColor(255, 255, 255, 120))
            p.drawText(QPointF(cx + 13 * s, y + 26 * s), f"{ma}/{ta} all")
            self.tips.append((QRectF(cx, y, colw, COUNTS_H * s), num))

    def _paint_header(self, p, s, x0, y, right):
        cy = y + HEADER_H * s / 2 - 1 * s
        self.cat_rects = {}
        x = x0 + 6 * s
        for num, (key, label) in CATEGORIES.items():
            on = self.state["categories"].get(key, True)
            col = QColor(self.colours.get(key))
            poly = self._diamond(x, cy, 5 * s)
            if on:
                p.setPen(Qt.NoPen)
                p.setBrush(col)
            else:
                c = QColor(col)
                c.setAlpha(110)
                p.setPen(QPen(c, max(1.0, 1.2 * s)))
                p.setBrush(Qt.NoBrush)
            p.drawPolygon(poly)
            self.cat_rects[key] = (QRectF(x - 9 * s, y, 18 * s, HEADER_H * s), label)
            self.tips.append((self.cat_rects[key][0], num))
            x += 19 * s

        if self.hover_cat:
            label = self.cat_rects[self.hover_cat][1]
            on = self.state["categories"].get(self.hover_cat, True)
            text, col = f"{label}  {'shown' if on else 'hidden'}", QColor(255, 255, 255, 190)
        else:
            text, col = "Editing \u00b7 tray icon > Done", QColor(255, 255, 255, 95)
        p.setPen(col)
        p.setFont(self._font(9.5 * s))
        p.drawText(QRectF(x + 4 * s, y, right - x - 4 * s, HEADER_H * s - 2 * s),
                   Qt.AlignRight | Qt.AlignVCenter, text)
        p.setPen(QPen(QColor(255, 255, 255, 20), 1))
        p.drawLine(QPointF(x0, y + HEADER_H * s - 1), QPointF(right, y + HEADER_H * s - 1))

    def _paint_row(self, p, s, pet, x0, y, right, now_dt, now_m, fade_end):
        col = self._cat_colour(pet.category)
        remaining = (pet.last_seen + fade_end - now_dt).total_seconds()
        alpha = max(0.0, min(1.0, remaining / 60.0))   # last minute fades out
        p.setOpacity(alpha * (0.5 if pet.maxed else 1.0))

        # pickup flash
        if pet.flash_at:
            age = now_m - pet.flash_at
            if age < FLASH_SECS:
                fc = QColor(col)
                fc.setAlpha(int(70 * (1 - age / FLASH_SECS)))
                p.setPen(Qt.NoPen)
                p.setBrush(fc)
                p.drawRoundedRect(QRectF(x0 - 3 * s, y + 2 * s, right - x0 + 6 * s, ROW_H * s - 4 * s),
                                  4 * s, 4 * s)

        # icon
        isz = ICON * s
        irect = QRectF(x0, y + (ROW_H * s - isz) / 2, isz, isz)
        if pet.category in CATEGORIES:
            self.tips.append((irect, pet.category))
        pix = self.data.icon(pet.pet_key) if pet.pet_key else None
        if pix is not None and not pix.isNull():
            path = QPainterPath()
            path.addRoundedRect(irect, 4 * s, 4 * s)
            p.save()
            p.setClipPath(path)
            p.drawPixmap(irect, pix, QRectF(pix.rect()))
            p.restore()
        else:
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(255, 255, 255, 18))
            p.drawRoundedRect(irect, 4 * s, 4 * s)
            p.setBrush(col)
            p.drawPolygon(self._diamond(irect.center().x(), irect.center().y(), 5 * s))

        tx = irect.right() + GAP * s
        name_base = y + ROW_H * s * 0.47

        # right-side label
        if pet.maxed:
            label = "MAXED"
            lf = self._font(9.5 * s, QFont.DemiBold, 1.2 * s)
            lcol = QColor(col)
        else:
            label = f"{pet.cur}/{pet.need}"
            lf = self._font(11.5 * s, QFont.DemiBold)
            lcol = QColor(255, 255, 255, 235)
        lfm = QFontMetricsF(lf)
        lw = lfm.horizontalAdvance(label)
        p.setFont(lf)
        p.setPen(lcol)
        p.drawText(QPointF(right - lw, name_base), label)

        # name + level
        nf = self._font(12.5 * s, QFont.Medium)
        nfm = QFontMetricsF(nf)
        lvf = self._font(10 * s)
        lvfm = QFontMetricsF(lvf)
        lv = f"Lv {pet.level}"
        avail = right - lw - 10 * s - tx
        lvw = lvfm.horizontalAdvance(lv) + 6 * s
        show_lv = avail - lvw > 50 * s
        name_space = avail - (lvw if show_lv else 0)
        name = nfm.elidedText(pet.name, Qt.ElideRight, max(10.0, name_space))
        p.setFont(nf)
        p.setPen(QColor(255, 255, 255, 235))
        p.drawText(QPointF(tx, name_base), name)
        if show_lv:
            p.setFont(lvf)
            p.setPen(QColor(255, 255, 255, 120))
            p.drawText(QPointF(tx + nfm.horizontalAdvance(name) + 6 * s, name_base), lv)

        # progress bar
        by = y + ROW_H * s * 0.66
        bh = max(2.0, 3 * s)
        bar = QRectF(tx, by, right - tx, bh)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(255, 255, 255, 26))
        p.drawRoundedRect(bar, bh / 2, bh / 2)
        frac = 1.0 if pet.maxed else (pet.cur / pet.need if pet.need else 0.0)
        if frac > 0:
            fill = QRectF(bar.x(), bar.y(), max(bh, bar.width() * min(1.0, frac)), bh)
            p.setBrush(col)
            p.drawRoundedRect(fill, bh / 2, bh / 2)

    # ---- mouse (only reachable while unlocked) ---------------------------- #
    def _near_edge(self, pos):
        return pos.x() >= self.width() - 9 * self.s()

    def _cat_at(self, pos):
        for key, (rect, _) in self.cat_rects.items():
            if rect.contains(QPointF(pos)):
                return key
        return None

    def mousePressEvent(self, e):
        if e.button() != Qt.LeftButton:
            return
        pos = e.position().toPoint()
        if not self.locked:
            key = self._cat_at(pos)
            if key:
                self.state["categories"][key] = not self.state["categories"].get(key, True)
                self.data.changed = True
                self._queue_save()
                self.update()
                return
        gpos = e.globalPosition().toPoint()
        if self._near_edge(pos):
            self.drag = ("resize", gpos.x(), self.width())
        else:
            self.drag = ("move", gpos - self.frameGeometry().topLeft())

    def mouseMoveEvent(self, e):
        pos = e.position().toPoint()
        gpos = e.globalPosition().toPoint()
        if self.drag and self.drag[0] == "move":
            self.move(gpos - self.drag[1])
        elif self.drag and self.drag[0] == "resize":
            nw = int(min(700, max(170, self.drag[2] + gpos.x() - self.drag[1])))
            self.resize(nw, self.height())
            self._relayout()
        else:
            self.setCursor(Qt.SizeHorCursor if self._near_edge(pos) else Qt.ArrowCursor)
            hc = None if self.locked else self._cat_at(pos)
            if hc != self.hover_cat:
                self.hover_cat = hc
                self.update()

    def mouseReleaseEvent(self, _):
        if self.drag:
            self.drag = None
            self._queue_save()

    def leaveEvent(self, _):
        if self.hover_cat:
            self.hover_cat = None
            self.update()

    def contextMenuEvent(self, e):
        self.build_menu().exec(e.globalPos())

    def build_menu(self):
        m = QMenu()
        a = m.addAction("Move / resize" if self.locked else "Done moving")
        a.triggered.connect(self.toggle_lock)
        m.addAction("Clear list").triggered.connect(self.clear_list)
        m.addAction("Open settings file").triggered.connect(
            lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(CONFIG_PATH))))
        m.addSeparator()
        m.addAction("Quit").triggered.connect(QApplication.instance().quit)
        return m


# --------------------------------------------------------------------------- #
# Farm menu: where every pet spawns and the closest Kibelisk
# (spawn data: pet_spawns.json, built from guildmanager.app's Global catalog)
# --------------------------------------------------------------------------- #
# Eltnen (1011) and Morheim (1111) are Korea/Taiwan only for now, so they're left out
WORLD_GROUPS = {"elyos": {"1000", "1010"}, "abyss": {"20", "22", "23"},
                "asmo": {"1100", "1110"}}
GROUP_LABELS = [("elyos", "ELY"), ("abyss", "ABY"), ("asmo", "ASM"), ("special", "SPECIAL")]
SPECIAL_HOW = "Black Cloud Merchant \u00b7 chests \u00b7 achievements \u00b7 Ascension Trial"
WORLD_ORDER = {w: i for i, w in enumerate(["1010", "1011", "1000", "20", "22", "23", "1110", "1111", "1100"])}
GENUS_NUM = {"C": 1, "F": 2, "N": 3, "V": 4}
SPAWNS_PATH = APP_DIR / "pet_spawns.json"
FARM_W = 300.0
FARM_MIN_W = 300
STRIP_H, FROW_H, FPAD, TAB_W = 26.0, 56.0, 7.0, 64.0


def stage_of(total, thresholds):
    """(level, current, needed, maxed) from a total soul count."""
    prev = 0
    for lvl, t in enumerate(thresholds):
        if total < t:
            return lvl, total - prev, t - prev, False
        prev = t
    return len(thresholds), 0, 0, True


class FarmRow:
    __slots__ = ("name", "category", "pet_key", "level", "cur", "need", "maxed",
                 "area", "world", "kib", "extra", "special", "boss")


class FarmData:
    def __init__(self, data):
        self.data = data
        self.pets, self.kibs, self.worlds, self.special = [], {}, {}, {}
        try:
            with open(SPAWNS_PATH, encoding="utf-8") as f:
                d = json.load(f)
            self.pets, self.kibs, self.worlds = d["pets"], d["kibelisks"], d["worlds"]
            self.special = d.get("special", {})
        except (OSError, ValueError, KeyError) as e:
            log_error(f"Could not read pet_spawns.json: {e}")
        self.souls = {}
        self._next = 0.0

    def refresh(self, force=False):
        if hasattr(self.data, "own_souls"):
            self.souls = self.data.own_souls()
            return
        if not force and time.monotonic() < self._next:
            return
        self._next = time.monotonic() + 3.0
        try:
            con = self.data._db()
            try:
                self.souls = dict(con.execute("SELECT pet_key, souls FROM pet_progress"))
            finally:
                con.close()
        except sqlite3.Error:
            pass

    def rows(self, cats, groups):
        worlds_on = set()
        for g, on in groups.items():
            if on:
                worlds_on |= WORLD_GROUPS.get(g, set())
        out = []
        for pid, name, g, areas in self.pets:
            cat = GENUS_NUM.get(g)
            if cat in CATEGORIES and not cats.get(CATEGORIES[cat][0], True):
                continue
            is_special = name in self.special
            ok = [] if is_special else [a for a in areas if a[1] in worlds_on]
            if not ok and not (is_special and groups.get("special")):
                continue
            key = self.data.name_map.get(name)
            total = self.souls.get(key) if key else None
            if total is None:
                total = self.data.log_totals.get(name, 0)
            r = FarmRow()
            r.name, r.category, r.pet_key = name, cat, key
            r.level, r.cur, r.need, r.maxed = stage_of(total, self.data.thresholds)
            r.special, r.boss = is_special, self.special.get(name)
            if is_special:
                r.area, r.world, r.kib, r.extra = SPECIAL_HOW, "special", None, 0
                out.append(r)
                continue
            a = ok[0]
            r.area, r.world = a[0], a[1]
            k = self.kibs.get(str(a[2])) if a[2] else None
            r.kib = (k[2], k[0], a[3]) if k else None      # (number, name, metres)
            r.extra = len(ok) - 1
            out.append(r)
        out.sort(key=lambda r: (r.special, r.maxed, WORLD_ORDER.get(r.world, 99),
                                r.kib[0] if r.kib and r.kib[0] is not None else 999,
                                r.kib[1] if r.kib else "", r.name))
        return out


def _base_flags():
    return (Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool
            | Qt.WindowDoesNotAcceptFocus)


def _font(px, weight=QFont.Normal, spacing=0.0):
    f = QFont(theme.BODY)
    f.setPixelSize(max(6, int(round(px))))
    f.setWeight(weight)
    if spacing:
        f.setLetterSpacing(QFont.AbsoluteSpacing, spacing)
    f.setHintingPreference(QFont.PreferNoHinting)
    return f


def tray_icon_pixmap(colours):
    pix = QPixmap(64, 64)
    pix.fill(Qt.transparent)
    p = QPainter(pix)
    p.setRenderHint(QPainter.Antialiasing)
    p.setPen(Qt.NoPen)
    spots = [(20, 20, "cogni"), (44, 20, "fera"), (20, 44, "natura"), (44, 44, "varian")]
    for cx, cy, key in spots:
        p.setBrush(QColor(colours[key]))
        p.drawPolygon(Overlay._diamond(cx, cy, 11))
    p.end()
    return pix


def main():
    sys.excepthook = excepthook
    raw_cfg = load_json(CONFIG_PATH, {})
    cfg = load_json(CONFIG_PATH, DEFAULT_CONFIG)
    cfg["hide_keys"], cfg["show_keys"] = [], []          # windows are detected from the screen now
    if not CONFIG_PATH.exists():
        save_json(CONFIG_PATH, cfg)
    else:
        dirty = False
        if "kibelisk_label" not in raw_cfg:      # first run of the farm-menu version
            if raw_cfg.get("lock_hotkey", "CTRL+SHIFT+O") == "CTRL+SHIFT+O":
                cfg["lock_hotkey"] = "NUMPAD_PLUS"
            dirty = True
        if "hover_delay_seconds" not in raw_cfg:  # M/G hide, keep list after death/teleport
            for k in ("M", "G"):
                if k not in [str(x).upper() for x in cfg["hide_keys"]]:
                    cfg["hide_keys"].append(k)
            cfg["clear_on_teleport"] = False
            cfg.setdefault("hover_opacity", 0.08)
            dirty = True
        if raw_cfg.get("toggle_key") in (None, "NUMPAD_MINUS") and raw_cfg.get("lock_hotkey"):
            cfg["toggle_key"] = "NUMPAD_PLUS"      # lock key removed; Numpad + now shows/hides
            cfg["lock_hotkey"] = ""
            dirty = True
        if dirty:
            save_json(CONFIG_PATH, cfg)
    state = load_json(STATE_PATH, DEFAULT_STATE)

    if IS_WIN:   # started with python.exe instead of pythonw? hide the black console window
        try:
            hwnd = ctypes.windll.kernel32.GetConsoleWindow()
            if hwnd:
                ctypes.windll.user32.ShowWindow(hwnd, 0)
        except Exception:
            pass
    if IS_WIN:   # own taskbar identity so the pinned shortcut keeps its icon
        try:
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("PetOverlay.Aion2")
        except Exception:
            pass
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    from PySide6.QtCore import QLockFile
    lock = QLockFile(str(APP_DIR / ".running.lock"))
    lock.setStaleLockTime(0)
    if not lock.tryLock(200):   # already running: don't open a second copy
        sys.exit(0)
    app._lock = lock
    ico = APP_DIR / "pet_overlay.ico"
    if ico.exists():
        app.setWindowIcon(QIcon(str(ico)))

    from updater import Updater, ensure_npcap
    npcap_wait = IS_WIN and not ensure_npcap(log_error)   # a new PC: opens the Npcap installer once
    app.updater = Updater(APP_DIR, log_error)
    app.updater.start()

    if str(cfg.get("data_source", "game")).lower() == "tracker":
        data = TrackerData(tracker_folder(cfg))     # old way: read the original tracker's files
    else:
        data = GameData(tracker_folder(cfg))        # read the game ourselves
    data.start()

    theme.load_fonts(APP_DIR / "fonts")
    ov = Overlay(cfg, state, data)
    ov.fd = FarmData(data)
    try:
        from map_builder import MapStore
        ov.maps = MapStore(APP_DIR, SPAWNS_PATH, cfg["colours"], log_error)
        ov.maps.start()
        if isinstance(data, GameData) and len(list(ICON_DIR.glob("*.png"))) < 150:
            from map_builder import download_icons
            threading.Thread(target=download_icons, args=(SPAWNS_PATH, ICON_DIR, log_error), daemon=True).start()
    except Exception as e:
        log_error(f"Maps disabled: {e}")

    ov.ui = theme.UI(ov, cfg, state, data, APP_DIR, ov.fd)
    ov.ui.cat_keys = {n: k for n, (k, _l) in CATEGORIES.items()}
    ov.ui.world_groups, ov.ui.world_order = WORLD_GROUPS, WORLD_ORDER
    from flight import FlightWatcher
    from bosses import BossAlerts
    ov.flight = FlightWatcher(state, lambda msg: ov.ui.flight_full())
    ov.bosses = BossAlerts(state, ov.ui.boss_alert)
    ov.ui.flight, ov.ui.bosses = ov.flight, ov.bosses
    ov.ui.items.prefetch([562100004, 536400001, 534320022])

    def _takeoff():                     # a few flights' game data, to find the game's own flight energy number
        if isinstance(data, GameData) and state.get("flight_recs", 0) < 3:
            state["flight_recs"] = state.get("flight_recs", 0) + 1
            data.record("flight", 25)
            (APP_DIR / "samples").mkdir(exist_ok=True)
            ov.flight.log_path = str(APP_DIR / "samples" / "flight_gauge.jsonl")
            ov.flight.log_until = time.time() + 25
    ov.flight.on_takeoff = _takeoff
    if isinstance(data, GameData):
        try:
            from mapview import Capture, MapView, MiniView
            _want = {"t": 0, "v": set()}

            def want_pets():                          # pets still to collect (maxed ones are left off the map)
                if time.time() - _want["t"] > 5:
                    top = data.thresholds[-1] if data.thresholds else 0
                    _want["v"] = {n for n, pid in data.name_id.items() if data.coll.get(pid, 0) < top}
                    _want["t"] = time.time()
                return _want["v"]

            def icon_for(name):
                k = data.name_map.get(name)
                return data.icon(k) if k else None
            fam = {"C": "Cogni", "F": "Fera", "N": "Natura", "V": "Varian"}

            def info_for(name):
                pid = data.name_id.get(name)
                if pid is None or not data.thresholds:
                    return None
                lvl, cur, need, maxed = stage_of(data.coll.get(pid, 0), data.thresholds)
                g = next((g for _p, n, g, _a in ov.fd.pets if n == name), None) if hasattr(ov.fd, "pets") else None
                return {"level": lvl, "cur": cur, "need": need, "maxed": maxed, "family": fam.get(g, "")}
            show_map = lambda: state.get("show", {}).get("map_pets", True)
            ov.mapview = MapView(APP_DIR, data, log_error, icon_for, want_pets, info_for, show_map,
                                 Capture(APP_DIR, log_error))
            ov.minimap = MiniView(ov.mapview, log_error)

            def set_map_pets(on):
                state.setdefault("show", {})["map_pets"] = bool(on)
                save_json(STATE_PATH, state)
            ov.mapview.set_enabled = set_map_pets
        except Exception as e:
            log_error(f"map overlay disabled: {e}")
    def os_notify(title, msg):
        if not ov.game.info()[0]:                     # only when you're not looking at the game
            tray.showMessage(title, msg, tray.icon(), 6000)
    ov.ui.os_notify = os_notify
    ov.bosses.data = data

    ico = APP_DIR / "pet_overlay.ico"
    tray = QSystemTrayIcon(QIcon(str(ico)) if ico.exists() else QIcon(tray_icon_pixmap(cfg["colours"])))
    tray.setToolTip("Pet Overlay")
    menu = QMenu()
    show = state.setdefault("show", {})
    size_menu = menu.addMenu("Size")
    for pct in (50, 67, 80, 100, 125):
        act = QAction(f"{pct}%", size_menu)
        act.setCheckable(True)
        act.setChecked(abs(ov.ui.S * 100 - pct) < 2)
        def pick(_=False, v=pct):
            ov.ui.set_scale(v / 100)
            for a2 in size_menu.actions():
                a2.setChecked(a2.text() == f"{v}%")
        act.triggered.connect(pick)
        size_menu.addAction(act)
    vol_menu = menu.addMenu("Volume")
    if not state.get("sounds", True):
        state["volume"], state["sounds"] = 0.0, True
    levels = (("Off", 0.0), ("Quiet", 0.25), ("Medium", 0.5), ("Loud", 1.0))
    cur = float(state.get("volume", 0.5))
    for label, v in levels:
        act = QAction(label, vol_menu)
        act.setCheckable(True)
        act.setChecked(abs(cur - v) < 0.01)
        def pick_vol(_=False, v=v, label=label):
            state["volume"] = v
            save_json(STATE_PATH, state)
            for a2 in vol_menu.actions():
                a2.setChecked(a2.text() == label)
            ov.ui.play("boss")                     # hear the new level
        act.triggered.connect(pick_vol)
        vol_menu.addAction(act)
    from bosses import EVENTS, EVENT_OPTIONS, event_alerts
    ev_menu = menu.addMenu("Event alerts")
    for e in EVENTS:
        sub = ev_menu.addMenu(e["name"])
        for off, label in EVENT_OPTIONS.get(e["key"], []):
            act = QAction(label, sub)
            act.setCheckable(True)
            act.setChecked(off in event_alerts(state, e["key"]))
            def pick_ev(on, k=e["key"], off=off):
                cur = [o for o in event_alerts(state, k) if o != off] + ([off] if on else [])
                state.setdefault("event_alerts", {})[k] = sorted(cur)
                save_json(STATE_PATH, state)
            act.toggled.connect(pick_ev)
            sub.addAction(act)
    sr = QAction("Spots tabs go back to Recent", menu)
    sr.setCheckable(True)
    sr.setChecked(state.get("spots_return", True))
    sr.toggled.connect(lambda on: (state.__setitem__("spots_return", on), save_json(STATE_PATH, state)))
    menu.addAction(sr)
    pm = QAction("Pets on the map", menu)
    pm.setCheckable(True)
    pm.setChecked(show.get("map_pets", True))
    pm.toggled.connect(lambda on: (show.__setitem__("map_pets", on), save_json(STATE_PATH, state)))
    menu.addAction(pm)
    menu.addSeparator()
    def reset_layout():
        for k in ("lx", "ly"):
            state.get("dock", {}).pop(k, None)
        ov.ui.set_scale(theme.DEFAULT_SCALE)
    menu.addAction("Reset position and size").triggered.connect(reset_layout)
    menu.addSeparator()
    menu.addAction("Quit").triggered.connect(app.quit)
    tray.setContextMenu(menu)
    tray.show()

    def on_quit():
        state.update(x=ov.x(), y=ov.y(), width=ov.width(), locked=ov.locked)
        save_json(STATE_PATH, state)
    app.aboutToQuit.connect(on_quit)

    # When the app's files are updated, restart by itself (once the new files stop changing)
    def _mtimes():
        return {f.name: f.stat().st_mtime for f in list(APP_DIR.glob("*.py")) + list(APP_DIR.glob("*.json"))
                if f.name in ("pet_spawns.json",) or f.suffix == ".py"}
    upd = {"base": _mtimes(), "seen": None}

    def restart():
        on_quit()
        app._lock.unlock()
        import subprocess
        frozen = getattr(sys, "frozen", False)
        subprocess.Popen([sys.executable] if frozen else [sys.executable, str(APP_DIR / "pet_overlay.py")],
                         cwd=str(APP_DIR), creationflags=0x08000000 if IS_WIN else 0)
        app.quit()

    def check_update():
        try:
            nonlocal npcap_wait
            if npcap_wait and (Path(os.environ.get("WINDIR", r"C:\Windows")) / "System32" / "Npcap" / "wpcap.dll").exists():
                npcap_wait = False                 # Npcap just got installed: start again to use it
                restart()
                return
            cur = _mtimes()
            if cur == upd["base"]:
                upd["seen"] = None
                return
            if cur != upd["seen"]:
                upd["seen"] = cur
                return
            restart()
        except Exception as e:
            log_error(f"self-restart failed: {e}")
    upd_timer = QTimer()
    upd_timer.timeout.connect(check_update)
    upd_timer.start(3000)
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
