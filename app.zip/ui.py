"""
The overlay's look: one launcher button, and the panels that open under it
(Pets with Recent/Farm tabs, Gathering with Recent/Spots tabs, World bosses),
plus the quiet alert notes. Only draws on screen; nothing touches the game.
"""
import math
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

from PySide6.QtCore import QPoint, QPointF, QRectF, Qt, QTimer
from PySide6.QtGui import (QColor, QCursor, QFont, QFontDatabase, QFontMetricsF, QGuiApplication,
                           QPainter, QPainterPath, QPen, QPixmap)
from PySide6.QtWidgets import QMenu, QWidget

BODY, HEAD = "Segoe UI", "Segoe UI"
BG = QColor(14, 17, 24, 228)
TILE = QColor("#1A1F2B")
TILE_HI = QColor("#262C3A")
TEXT = QColor(255, 255, 255, 238)
SOFT = QColor("#D7DCE6")
SUB = QColor("#A9B1C2")
LIT = QColor("#E6E9F0")
INK = QColor("#0E1118")
FLASH = QColor("#26304A")
GRADE_TILE = {0: "#262C39", 1: "#1B3527", 2: "#1A2B45", 3: "#3A3219", 4: "#2D2240"}
GENUS_TINT = {1: "#16263A", 2: "#3A1C1C", 3: "#16301F", 4: "#36301A"}
DEFAULT_SCALE = 0.67

# animation lengths (seconds): short, so everything feels instant
T_FADE, T_ROW, T_POP, T_FLASH, T_FLOAT, T_BAR, T_DOCK, T_TAB = 0.17, 0.16, 0.2, 0.45, 0.6, 0.25, 0.2, 0.14
T_CLOSE, T_BEAT, T_STAGGER, T_HEIGHT = 0.15, 0.05, 0.018, 0.16


def load_fonts(folder):
    global BODY, HEAD
    fams = {}
    for f in Path(folder).glob("*.ttf"):
        i = QFontDatabase.addApplicationFont(str(f))
        for fam in QFontDatabase.applicationFontFamilies(i) if i >= 0 else []:
            fams[fam.lower()] = fam
    BODY = fams.get("inter", BODY)
    HEAD = fams.get("chakra petch", BODY)


def font(px, weight=500, head=False):
    f = QFont(HEAD if head else BODY)
    f.setPixelSize(max(6, int(round(px))))
    f.setWeight(QFont.Weight(weight))
    f.setHintingPreference(QFont.PreferNoHinting)
    return f


def now():
    return time.monotonic()


def clamp(v, a=0.0, b=1.0):
    return a if v < a else b if v > b else v


def ease_out(t):
    return 1 - (1 - t) ** 3


def ease_back(t):
    c = 1.6
    return 1 + (c + 1) * (t - 1) ** 3 + c * (t - 1) ** 2


def pop(age, dur=T_POP, amt=0.14):
    return 1 + amt * math.sin(math.pi * age / dur) if 0 <= age < dur else 1.0


def rr(p, rect, r, col):
    p.setPen(Qt.NoPen)
    p.setBrush(col)
    p.drawRoundedRect(rect, r, r)


def diamond(p, cx, cy, r, col):
    path = QPainterPath()
    path.moveTo(cx, cy - r); path.lineTo(cx + r, cy); path.lineTo(cx, cy + r); path.lineTo(cx - r, cy)
    path.closeSubpath()
    p.setPen(Qt.NoPen)
    p.setBrush(col)
    p.drawPath(path)


def text(p, x, y, s, f, col, align=None, w=None):
    """Draw s with its baseline at y. Returns its width."""
    p.setFont(f)
    p.setPen(col)
    fm = QFontMetricsF(f)
    if w is not None:
        s = fm.elidedText(s, Qt.ElideRight, max(0, w))
    adv = fm.horizontalAdvance(s)
    if align == "r":
        x -= adv
    elif align == "c":
        x -= adv / 2
    p.drawText(QPointF(x, y), s)
    return adv


def tw(s, f):
    return QFontMetricsF(f).horizontalAdvance(s)


def _mix(a, b, t):
    return QColor(int(a.red() + (b.red() - a.red()) * t), int(a.green() + (b.green() - a.green()) * t),
                  int(a.blue() + (b.blue() - a.blue()) * t), int(a.alpha() + (b.alpha() - a.alpha()) * t))


def alpha(c, a):
    c = QColor(c)
    c.setAlphaF(clamp(a) * c.alphaF())
    return c


# ---------------------------------------------------------------- icons ---- #
def _poly(pts):
    path = QPainterPath()
    path.moveTo(*pts[0])
    for q in pts[1:]:
        path.lineTo(*q)
    path.closeSubpath()
    return path


def draw_icon(p, kind, x, y, size, col, bg=None):
    """Solid icons on a 24 x 24 grid."""
    p.save()
    p.translate(x, y)
    p.scale(size / 24, size / 24)
    p.setPen(Qt.NoPen)
    p.setBrush(col)
    path = QPainterPath()
    if kind == "pets":
        p.drawEllipse(QPointF(12, 16), 5.5, 4.5)
        for cx, cy in ((5.5, 10), (9.5, 6), (14.5, 6), (18.5, 10)):
            p.drawEllipse(QPointF(cx, cy), 2.3, 2.3)
    elif kind == "gather":
        p.setPen(QPen(col, 3, Qt.SolidLine, Qt.RoundCap))
        p.drawLine(QPointF(4, 20), QPointF(13, 11))
        p.setPen(Qt.NoPen)
        path.moveTo(8, 4); path.cubicTo(13, 3, 18, 6, 20, 11); path.lineTo(17, 12)
        path.cubicTo(15, 8, 12, 6.5, 9, 7); path.closeSubpath()
        p.drawPath(path)
    elif kind == "flight":
        path.moveTo(2, 14); path.cubicTo(6, 6, 13, 3, 22, 3); path.cubicTo(19, 6, 18, 8, 16, 9)
        path.cubicTo(18, 9, 19, 9, 20, 9); path.cubicTo(17, 12, 14, 13, 11, 13); path.cubicTo(12, 14, 13, 14, 14, 15)
        path.cubicTo(10, 17, 6, 17, 2, 14); path.closeSubpath()
        p.drawPath(path)
    elif kind == "bosses":
        p.drawPath(_poly([(3, 8), (8, 12), (12, 5), (16, 12), (21, 8), (19, 19), (5, 19)]))
    elif kind == "art":                                   # framed picture = drops an Artwork
        path.addRoundedRect(QRectF(3, 4, 18, 16), 2.5, 2.5)
        path.addRoundedRect(QRectF(5.5, 6.5, 13, 11), 1, 1)
        path.setFillRule(Qt.OddEvenFill)
        p.drawPath(path)
        p.drawPath(_poly([(6.5, 16.5), (10.5, 11), (13, 14), (14.8, 12.3), (17.5, 16.5)]))
        p.drawEllipse(QPointF(15.5, 9.3), 1.4, 1.4)
    elif kind == "rift":                                  # portal
        path.addEllipse(QPointF(12, 12), 9.5, 9.5)
        path.addEllipse(QPointF(12, 12), 6.5, 6.5)
        path.addEllipse(QPointF(12, 12), 3.2, 3.2)
        path.setFillRule(Qt.OddEvenFill)
        p.drawPath(path)
    elif kind == "invasion":                              # swirling rift
        p.setPen(QPen(col, 2.4, Qt.SolidLine, Qt.RoundCap))
        p.setBrush(Qt.NoBrush)
        for r, a0 in ((9, 20), (6, 140), (3, 260)):
            p.drawArc(QRectF(12 - r, 12 - r, 2 * r, 2 * r), a0 * 16, 230 * 16)
        p.setPen(Qt.NoPen)
    elif kind == "siege":                                 # tower
        p.drawPath(_poly([(5, 21), (5, 9), (7, 9), (7, 6), (9.5, 6), (9.5, 9), (11, 9), (11, 6), (13, 6), (13, 9),
                          (14.5, 9), (14.5, 6), (17, 6), (17, 9), (19, 9), (19, 21), (14, 21), (14, 16), (10, 16),
                          (10, 21)]))
    elif kind == "key":
        p.drawEllipse(QPointF(8, 12), 5, 5)
        p.drawRect(QRectF(11, 10.6, 10, 2.8))
        p.drawRect(QRectF(16, 13, 2.2, 3.5))
        p.drawRect(QRectF(19, 13, 2.2, 2.6))
        p.setBrush(bg or INK)
        p.drawEllipse(QPointF(8, 12), 2, 2)
    elif kind == "session":                               # hourglass
        p.drawRoundedRect(QRectF(5, 2.5, 14, 2.4), 1.2, 1.2)
        p.drawRoundedRect(QRectF(5, 19.1, 14, 2.4), 1.2, 1.2)
        p.setPen(QPen(col, 1.8, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        p.setBrush(Qt.NoBrush)
        p.drawPolyline([QPointF(7, 5), QPointF(7, 7.5), QPointF(12, 12), QPointF(7, 16.5), QPointF(7, 19)])
        p.drawPolyline([QPointF(17, 5), QPointF(17, 7.5), QPointF(12, 12), QPointF(17, 16.5), QPointF(17, 19)])
        p.setPen(Qt.NoPen)
        p.setBrush(col)
        p.drawPath(_poly([(9, 8.2), (15, 8.2), (12, 11)]))
        p.drawPath(_poly([(12, 15), (16, 18.6), (8, 18.6)]))
    elif kind == "events":
        path.addEllipse(QPointF(12, 12.5), 9, 9)
        path.addEllipse(QPointF(12, 12.5), 6.6, 6.6)
        path.setFillRule(Qt.OddEvenFill)
        p.drawPath(path)
        p.setPen(QPen(col, 2.2, Qt.SolidLine, Qt.RoundCap))
        p.drawLine(QPointF(12, 12.5), QPointF(12, 8.5))
        p.drawLine(QPointF(12, 12.5), QPointF(14.8, 14.3))
        p.setPen(Qt.NoPen)
    elif kind == "bell":
        path.moveTo(12, 3); path.cubicTo(8.5, 3, 6, 5.6, 6, 9); path.lineTo(6, 14); path.lineTo(4, 17)
        path.lineTo(20, 17); path.lineTo(18, 14); path.lineTo(18, 9); path.cubicTo(18, 5.6, 15.5, 3, 12, 3)
        path.closeSubpath()
        path.addEllipse(QPointF(12, 20), 2, 2)
        p.drawPath(path)
    elif kind == "logo":
        for (cx, cy), c in zip(((12, 5), (19, 12), (12, 19), (5, 12)), ("#5AA9FF", "#FF6B5E", "#5FD38A", "#F2C94C")):
            p.setBrush(QColor(c))
            p.drawPath(_poly([(cx, cy - 3.2), (cx + 3.2, cy), (cx, cy + 3.2), (cx - 3.2, cy)]))
    elif kind == "Odyle":
        for pts in ([(12, 2), (16, 9), (12, 22), (8, 9)], [(5, 10), (8, 13), (6, 20), (3, 14)],
                    [(19, 9), (21, 14), (18, 20), (16, 13)]):
            p.drawPath(_poly(pts))
    elif kind == "Ore":
        p.drawPath(_poly([(3, 15), (7, 7), (14, 5), (20, 9), (21, 16), (15, 20), (6, 19)]))
    elif kind == "Gem":
        p.drawPath(_poly([(6, 4), (18, 4), (22, 9), (12, 21), (2, 9)]))
    elif kind == "Herb":
        path.moveTo(5, 20); path.cubicTo(4, 11, 10, 4, 20, 3); path.cubicTo(20, 13, 14, 19, 5, 20)
        p.drawPath(path)
    elif kind == "Log":
        p.drawRoundedRect(QRectF(2, 8, 16, 9), 2, 2)
        p.drawEllipse(QPointF(18, 12.5), 4, 4.5)
    else:
        p.drawEllipse(QPointF(12, 14), 7.5, 7.5)
    p.restore()


def _setup(w, click_through=False):
    f = Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool | Qt.WindowDoesNotAcceptFocus
    if click_through:
        f |= Qt.WindowTransparentForInput
    w.setWindowFlags(f)
    w.setAttribute(Qt.WA_TranslucentBackground)
    w.setAttribute(Qt.WA_ShowWithoutActivating)
    w.setMouseTracking(True)


def keep_on_top(w):
    try:
        import ctypes
        ctypes.windll.user32.SetWindowPos(int(w.winId()), -1, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010)
    except Exception:
        pass


class Fader:
    """Quick time-based fade + 6 px slide."""

    def fade_init(self):
        self.op, self.target, self._from, self._t0 = 0.0, 0.0, 0.0, 0.0

    def set_want(self, want):
        t = 1.0 if want else 0.0
        if t != self.target:
            self._from, self.target, self._t0 = self.op, t, now()
            UI.kick()

    def fade_step(self):
        if self.target > 0 and not self.isVisible():
            ui = getattr(self, "ui", None)
            if ui is not None and isinstance(self, Panel):
                ui.layout()                              # put it in place before it appears
            self.setWindowOpacity(self.op)
            self.show()
        if self.op != self.target:
            k = ease_out(clamp((now() - self._t0) / (T_FADE if self.target else T_CLOSE)))
            self.op = self.target if k >= 1 else self._from + (self.target - self._from) * k
            self.setWindowOpacity(max(0.0, self.op))
            self.update()
            if self.op == 0 and self.target == 0 and self.isVisible():
                self.hide()
            return True
        return False


class Tween:
    """A number that glides to new values."""

    def __init__(self, v=0.0, dur=T_BAR):
        self.a = self.b = self.v = v
        self.t0, self.dur = 0.0, dur

    def to(self, v):
        if abs(v - self.b) > 1e-6:
            self.a, self.b, self.t0 = self.get(), v, now()

    def get(self):
        k = ease_out(clamp((now() - self.t0) / self.dur))
        self.v = self.a + (self.b - self.a) * k
        return self.v

    def moving(self):
        return now() - self.t0 < self.dur


def ago(secs):
    m = int(secs // 60)
    return "just now" if m < 1 else f"{m}m ago"


# ---------------------------------------------------------------- panel ---- #
class Panel(QWidget, Fader):
    """A panel that sits under the launcher. Not movable on its own."""
    KEY, TITLE, TABS, W = "", "", (), 300

    def __init__(self, ui):
        super().__init__()
        self.ui = ui
        _setup(self)
        self.fade_init()
        self.st = ui.state.setdefault("panels", {}).setdefault(self.KEY, {})
        self.tab = int(self.st.get("tab", 0)) if self.TABS else 0
        self.tab_x = Tween(0.0, T_TAB)
        self.tips, self.hits, self.hover = [], [], None
        self.relayout()

    @property
    def s(self):
        return self.ui.S

    def content_h(self):
        return 40

    def relayout(self):
        """Grow / shrink smoothly: the window takes the bigger size at once, the card glides to the new one."""
        w = int(round(self.W * self.s))
        h = int(round((30 + self.content_h() + 6) * self.s))
        if not hasattr(self, "h_tw"):
            self.h_tw = Tween(float(h), T_HEIGHT)
        if abs(self.h_tw.b - h) > 0.5:
            self.h_tw.to(float(h))
            UI.kick()
        need = max(h, int(self.h_tw.get() + 0.5))
        if (w, need) != (self.width(), self.height()):
            self.resize(w, need)
            self.ui.layout_needed = True
        self.update()

    def glide_to(self, x, y, snap=False):
        g = getattr(self, "_glide", None)
        if snap or not self.isVisible():
            self._glide = None
            if (x, y) != (self.x(), self.y()):
                self.move(x, y)
        elif (x, y) != (g[2:4] if g else (self.x(), self.y())):
            self._glide = (self.x(), self.y(), x, y, now())
            UI.kick()

    def _glide_step(self):
        g = getattr(self, "_glide", None)
        if not g:
            return False
        x0, y0, x1, y1, t0 = g
        k = ease_out(clamp((now() - t0) / 0.16))
        self.move(int(x0 + (x1 - x0) * k), int(y0 + (y1 - y0) * k))
        if k >= 1:
            self._glide = None
        return True

    def animating(self):
        return self.tab_x.moving() or (hasattr(self, "h_tw") and self.h_tw.moving()) or \
            (self.target > 0 and now() - self._t0 < T_FADE + T_BEAT + 0.3)

    def step(self):
        busy = self.fade_step()
        busy |= self._glide_step()
        # Pets Farm / Gathering Spots: back to Recent after 3 minutes untouched (tray setting)
        if self.KEY in ("pets", "gather") and self.tab == 1 and self.ui.state.get("spots_return", True) and \
                now() - getattr(self, "touch_t", now()) > 180:
            self.set_tab(0)
        if self.tab == 0:
            self.touch_t = now()
        if hasattr(self, "h_tw") and not self.h_tw.moving() and self.height() > int(self.h_tw.b + 0.5):
            self.resize(self.width(), int(self.h_tw.b + 0.5))      # settle at the smaller size
            self.ui.layout_needed = True
        if self.isVisible() and self.animating():
            self.update()
            busy = True
        return busy

    def set_tab(self, i):
        self.touch_t = now()
        if i != self.tab:
            self.tab = i
            self.st["tab"] = i
            self.ui.save()
            self.relayout()
            UI.kick()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        s = self.s
        w, h = self.width(), self.height()
        opening = self.target > 0
        age = now() - self._t0
        if opening:
            g = ease_back(clamp(age / T_FADE))
            sc = 0.965 + 0.035 * g
            p.translate(w / 2, 0)
            p.scale(sc, sc)
            p.translate(-w / 2, -(1 - clamp(g)) * 6 * s)
        else:
            p.translate(0, -(1 - self.op) * 4 * s)
        vh = self.h_tw.get() if hasattr(self, "h_tw") else h
        ct = self.ui.clip_y - self.y()
        if ct > 0:                                   # scrolled up under the launcher: hide that part
            p.setClipRect(QRectF(0, ct, w, h + 10 * s))
            p.setOpacity(1.0)
        self.sb = None
        rr(p, QRectF(0, 0, w, vh), 10 * s, BG)
        p.setClipRect(QRectF(0, 0, w, vh), Qt.IntersectClip if ct > 0 else Qt.ReplaceClip)
        self.content_alpha = ease_out(clamp((age - T_BEAT) / 0.14)) if opening else 1.0
        self.open_age = age if opening else 99
        p.setOpacity(self.content_alpha)
        self.tips, self.hits = [], []
        draw_icon(p, self.KEY, 11 * s, 8 * s, 14 * s, LIT)
        if self.TABS:
            x = 32 * s
            spots = []
            for i, name in enumerate(self.TABS):
                f = font(12.5 * s, 600, True)
                tw_ = tw(name, f)
                hov = self.hover == ("tab", i)
                col = TEXT if i == self.tab else (SOFT if hov else SUB)
                text(p, x, 20 * s, name, f, col)
                spots.append((x, tw_))
                self.hits.append((QRectF(x - 6 * s, 0, tw_ + 12 * s, 28 * s), lambda i=i: self.set_tab(i), ("tab", i)))
                x += tw_ + 16 * s
            self.tab_x.to(float(self.tab))
            v = self.tab_x.get()
            i0 = int(math.floor(v)); i1 = min(len(spots) - 1, i0 + 1); fr = v - i0
            ux = spots[i0][0] + (spots[i1][0] - spots[i0][0]) * fr
            uw = spots[i0][1] + (spots[i1][1] - spots[i0][1]) * fr
            rr(p, QRectF(ux, 25 * s, uw, 2 * s), 1 * s, LIT)
        else:
            text(p, 32 * s, 20 * s, self.TITLE, font(12.5 * s, 600, True), TEXT)
        self.paint_header(p, s, w)
        top = 30 * s
        p.save()
        p.setClipRect(QRectF(0, top, w, vh - top), Qt.IntersectClip)
        self.paint_body(p, s, top, w)
        p.restore()

    def paint_header(self, p, s, w):
        pass

    def paint_body(self, p, s, top, w):
        pass

    def _hit_at(self, pos):
        for rect, fn, tag in self.hits:
            if rect.contains(pos):
                return fn, tag
        return None, None

    def on_right(self, pos):
        pass

    def mousePressEvent(self, e):
        self.touch_t = now()
        if e.button() == Qt.RightButton:
            self.on_right(e.position())
            return
        if e.button() == Qt.LeftButton and not self._hit_at(e.position())[0]:
            for rect, payload in self.tips:              # a row with a map: pin it open
                if isinstance(payload, tuple) and payload[0] == "map" and rect.contains(e.position()):
                    self.ui.ov.open_pin(payload, self)
                    return
        if e.button() == Qt.LeftButton:
            sb = getattr(self, "sb", None)
            if sb and sb[0].adjusted(-8 * self.s, 0, 4 * self.s, 0).contains(e.position()):
                self._sb_drag = True
                self._sb_to(e.position().y())
                return
            fn, _ = self._hit_at(e.position())
            if fn:
                fn()
                UI.kick()
                self.update()

    def _sb_to(self, y):
        track, total, shown, setter = self.sb
        k = clamp((y - track.y()) / max(1, track.height()))
        setter(int(round(k * max(0, total - shown))))
        UI.kick()
        self.update()

    def mouseReleaseEvent(self, e):
        self._sb_drag = False

    def mouseMoveEvent(self, e):
        self.touch_t = now()
        if getattr(self, "_sb_drag", False):
            self._sb_to(e.position().y())
            return
        fn, tag = self._hit_at(e.position())
        self.setCursor(Qt.PointingHandCursor if fn else Qt.ArrowCursor)
        if tag != self.hover:
            self.hover = tag
            self.update()

    def leaveEvent(self, _):
        self.hover = None
        self.update()

    def wheelEvent(self, e):
        self.touch_t = now()
        a, px = e.angleDelta(), e.pixelDelta()
        d = a.y() or a.x() or px.y() * 4 or px.x() * 4
        UI.last_wheel = f"{time.strftime('%H:%M:%S')} {self.KEY} angle={a.x()},{a.y()} pixel={px.x()},{px.y()}"
        self._wheel = getattr(self, "_wheel", 0) + d
        head = e.position().y() < 30 * self.s
        while abs(self._wheel) >= 60:                  # one row per half notch, either direction
            step = -1 if self._wheel > 0 else 1
            self._wheel += 60 * step
            before = (getattr(self, "first", None), self.tab)
            if not head and getattr(self, "sb", None):
                self.on_wheel(step)
            if head or not getattr(self, "sb", None) or before == (getattr(self, "first", None), self.tab):
                self.ui.scroll_stack(step)             # nothing (more) to scroll in here: move the column
        e.accept()

    def on_wheel(self, d):
        pass


def stagger(panel, i):
    """Extra fade for row i while its panel opens (rows land one after another)."""
    a = getattr(panel, "open_age", 99)
    return ease_out(clamp((a - T_BEAT - i * T_STAGGER) / 0.16))


class RowAnim:
    """Enter / leave / flash bookkeeping for a list of keyed rows."""

    def __init__(self):
        self.born, self.gone = {}, {}

    def update(self, keys, snapshot):
        t = now()
        keys = list(keys)
        for k in list(self.born):
            if k not in keys and k not in self.gone:
                self.gone[k] = (t, snapshot.get(k))
        for k in keys:
            self.born.setdefault(k, t)
            self.gone.pop(k, None)
        for k in list(self.gone):
            if t - self.gone[k][0] > T_ROW:
                self.gone.pop(k)
                self.born.pop(k, None)

    def busy(self):
        t = now()
        return bool(self.gone) or any(t - b < T_ROW for b in self.born.values())

    def enter(self, k):
        e = ease_out(clamp((now() - self.born.get(k, 0)) / T_ROW))
        return e, -(1 - e) * 8

    def leave(self, k):
        e = ease_out(clamp((now() - self.gone[k][0]) / T_ROW))
        return 1 - e, e * 14


ART_GRADE = {"Rare": "#1A2B45", "Epic": "#2D2240", "Unique": "#3A3219", "Heroic": "#3E2614", "Legendary": "#3E2614"}
ART_RING = {"Unique": "#F2C94C", "Heroic": "#F2994A", "Legendary": "#F2994A"}


ART_OVERRIDE = {}
COLOSSUS = {"Guardian Lord Nahma": 514330003, "Enraged Guardian Lord Nahma": 514330003}   # its statue drop


def art_tile(p, ui, s, rect, boss):
    """The boss's Artwork picture (falls back to a frame glyph while it downloads)."""
    item = ui.items.artwork(boss)
    grade = ART_OVERRIDE.get(boss) or (ui.items.grade(item) if item else "")
    rr(p, rect, 6 * s, QColor(ART_GRADE.get(grade, "#262C39")))
    if grade in ART_RING:
        p.setPen(QPen(QColor(ART_RING[grade]), 1.4 * s))
        p.setBrush(Qt.NoBrush)
        p.drawRoundedRect(rect.adjusted(0.7 * s, 0.7 * s, -0.7 * s, -0.7 * s), 6 * s, 6 * s)
        p.setPen(Qt.NoPen)
    ip = ui.items.icon_path(item) if item else None
    pix = ui.pix(ip) if ip else None
    if pix is not None and not pix.isNull():
        p.drawPixmap(rect.adjusted(1.5 * s, 1.5 * s, -1.5 * s, -1.5 * s), pix, QRectF(pix.rect()))
    else:
        d = rect.width() * 0.2
        draw_icon(p, "art", rect.x() + d, rect.y() + d, rect.width() - 2 * d, QColor("#F2C94C"))
    col = COLOSSUS.get(boss)
    if col:                                          # small statue badge in the corner
        ci = ui.items.icon_path(col)
        if ci is None:
            ui.items.prefetch([col])
        cp = ui.pix(ci) if ci else None
        if cp is not None and not cp.isNull():
            b = QRectF(rect.right() - rect.width() * 0.5, rect.bottom() - rect.height() * 0.5,
                       rect.width() * 0.56, rect.height() * 0.56)
            rr(p, b, 4 * s, QColor("#3E2614"))
            p.drawPixmap(b.adjusted(1 * s, 1 * s, -1 * s, -1 * s), cp, QRectF(cp.rect()))


EVENT_TINT = {"rift": "#1A2B45", "shugo": "#3A3219", "invasion": "#2D2240", "siege": "#3A1C1C"}
EVENT_COL = {"rift": "#8FC3FF", "shugo": "#F2C94C", "invasion": "#C08CF2", "siege": "#FF8A7A"}


# the game's own item pictures for each event (Shugo key, Spacetime Rift Ticket, Dimensional Merit Chest,
# Artifact of Eternity statue)
# Spacetime Rift Ticket · Rift Fragment (the game has no Invasion item; a dimensional shard) · Artifact of Eternity
EVENT_ITEM = {}
EVENT_UI = {"shugo": "shugo", "rift": "rift", "invasion": "invasion", "siege": "artifact"}   # the game's own icons


def ui_icon(ui, name):
    """One of the game's own icons (cut out, upscaled and centred to the same size), as a pixmap."""
    return ui.pix(Path(ui.app_dir) / "ui_icons" / f"{name}.png")


def draw_ui_icon(p, ui, name, rect):
    """Every borrowed icon drawn the same way: same inset, centred, smooth."""
    pix = ui_icon(ui, name)
    if pix is None or pix.isNull():
        return False
    d = rect.width() * 0.06
    p.save()
    p.setRenderHint(QPainter.SmoothPixmapTransform)
    p.drawPixmap(rect.adjusted(d, d, -d, -d), pix, QRectF(pix.rect()))
    p.restore()
    return True


TAB_UI = {"pets": "tab_pets", "session": "tab_session", "gather": "tab_gather", "bosses": "tab_bosses", "events": "tab_events"}
_SIL = {}


def draw_tab_icon(p, ui, key, rect, lit):
    """A dock button's game icon. When the button is lit (light background) it fades into a dark
    silhouette of the same icon so it stays readable."""
    pix = ui_icon(ui, TAB_UI[key]) if key in TAB_UI else None
    if pix is None or pix.isNull():
        return False
    sil = _SIL.get(TAB_UI[key])
    if sil is None:
        sil = QPixmap(pix.size())
        sil.fill(Qt.transparent)
        q = QPainter(sil)
        q.drawPixmap(0, 0, pix)
        q.setCompositionMode(QPainter.CompositionMode_SourceIn)
        q.fillRect(sil.rect(), INK)
        q.end()
        _SIL[TAB_UI[key]] = sil
    p.save()
    p.setRenderHint(QPainter.SmoothPixmapTransform)
    p.setOpacity(p.opacity() * (1 - lit))
    p.drawPixmap(rect, pix, QRectF(pix.rect()))
    p.restore()
    if lit > 0:
        p.save()
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        p.setOpacity(p.opacity() * lit)
        p.drawPixmap(rect, sil, QRectF(sil.rect()))
        p.restore()
    return True


def event_tile(p, ui, s, rect, key):
    rr(p, rect, 6 * s, QColor(EVENT_TINT.get(key, "#262C39")))
    d = rect.width() * 0.2
    if key in EVENT_UI and draw_ui_icon(p, ui, EVENT_UI[key], rect):
        return
    item = EVENT_ITEM.get(key)
    if item:
        ip = ui.items.icon_path(item)
        if ip is None:
            ui.items.prefetch([item])
        pix = ui.pix(ip) if ip else None
        if pix is not None and not pix.isNull():
            p.drawPixmap(rect.adjusted(1.5 * s, 1.5 * s, -1.5 * s, -1.5 * s), pix, QRectF(pix.rect()))
            return
    draw_icon(p, "key" if key == "shugo" else key, rect.x() + d, rect.y() + d, rect.width() - 2 * d,
              QColor(EVENT_COL.get(key, "#D7DCE6")))


def pet_pic(p, ui, s, x, y, sz, pet_key, cat):
    rr(p, QRectF(x, y, sz, sz), 8 * s, QColor(GENUS_TINT.get(cat, "#262C39")))
    pix = ui.data.icon(pet_key) if pet_key else None
    if pix is not None and not pix.isNull():
        clip = QPainterPath()
        clip.addRoundedRect(QRectF(x, y, sz, sz), 8 * s, 8 * s)
        p.save()
        p.setClipPath(clip)
        p.drawPixmap(QRectF(x, y, sz, sz), pix, QRectF(pix.rect()))
        p.restore()


def flash_bg(p, s, y, w, h, age):
    if age < T_FLASH:
        rr(p, QRectF(5 * s, y + 1 * s, w - 10 * s, h - 2 * s), 7 * s, alpha(FLASH, 1 - age / T_FLASH))


def float_text(p, s, x, y, txt, col, age):
    if age < T_FLOAT:
        k = age / T_FLOAT
        text(p, x, y - k * 14 * s, txt, font(11 * s, 700, True), alpha(col, min(1, k / 0.15) * (1 - k)), align="r")


def segmented(panel, p, s, x, y, options, current, tag, on_pick):
    """Small ELY / ABY / ASM style switch. Returns its width."""
    f = font(9.5 * s, 600)
    segw = [tw(lbl, f) + 12 * s for _, lbl in options]
    rr(p, QRectF(x, y, sum(segw) + 4 * s, 22 * s), 6 * s, TILE)
    cx = x + 2 * s
    for (k, lbl), sw in zip(options, segw):
        r = QRectF(cx, y + 2 * s, sw, 18 * s)
        on = k == current
        if on:
            rr(p, r, 5 * s, LIT)
        elif panel.hover == (tag, k):
            rr(p, r, 5 * s, TILE_HI)
        text(p, r.center().x(), r.y() + 12.5 * s, lbl, f, INK if on else SUB, align="c")
        panel.hits.append((r, lambda k=k: on_pick(k), (tag, k)))
        cx += sw
    return sum(segw) + 4 * s


def kib_line(p, s, x, y, right, kib, extra=""):
    """'◆ 3 Kibelisk name ... 114 m' like the Farm list."""
    sf = font(9.5 * s)
    if not kib:
        text(p, x, y, "No Kibelisk nearby" + extra, sf, SUB, w=right - x)
        return
    num, name, dist = kib[0], kib[1], kib[2]
    dw = text(p, right, y, f"{int(dist)} m", sf, SUB, align="r") if dist is not None else 0
    diamond(p, x + 3 * s, y - 3 * s, 3 * s, LIT)
    nx = x + 10 * s
    if num is not None:
        nx += text(p, nx, y, str(num), font(9.5 * s, 700), TEXT) + 4 * s
    text(p, nx, y, name + extra, sf, SUB, w=right - dw - 8 * s - nx)


def scrollbar(p, s, x, top, h, first, shown, total, panel=None, setter=None):
    if total <= shown or h <= 0:
        if panel is not None:
            panel.sb = None
        return
    hov = panel is not None and panel.underMouse() and \
        QRectF(x - 8 * s, top, 14 * s, h).contains(QPointF(panel.mapFromGlobal(QCursor.pos())))
    wd = 5 * s if hov or getattr(panel, "_sb_drag", False) else 3 * s
    rr(p, QRectF(x + 3 * s - wd, top, wd, h), wd / 2, TILE)
    bh = max(14 * s, h * shown / total)
    by = top + (h - bh) * (first / max(1, total - shown))
    rr(p, QRectF(x + 3 * s - wd, by, wd, bh), wd / 2, QColor("#6A7488") if hov else QColor("#4A5366"))
    if panel is not None and setter is not None:
        panel.sb = (QRectF(x - 2 * s, top, 8 * s, h), total, shown, setter)


# ------------------------------------------------------------ pets panel ---- #
class PetsPanel(Panel):
    KEY, TABS, W = "pets", ("Recent", "Farm"), 300
    COUNTS, ROW, FILTER, FROW = 24, 48, 26, 46
    GROUPS = (("elyos", "ELY"), ("abyss", "ABY"), ("asmo", "ASM"), ("special", "SPC"))

    def __init__(self, ui):
        self.rows, self.ra, self.bars = [], RowAnim(), {}
        self.farm_rows, self.first, self.scroll = [], 0, Tween(0.0, 0.12)
        self.fst = ui.state.setdefault("farm", {})
        self.fst.setdefault("categories", {"cogni": True, "fera": True, "natura": True, "varian": True})
        g = self.fst.setdefault("groups", {"elyos": True})
        if sum(1 for v in g.values() if v) != 1:          # one region at a time
            self.fst["groups"] = {"elyos": True}
        super().__init__(ui)

    def n_rows(self):
        return int(self.ui.cfg.get("max_rows", 5))

    def n_farm(self):
        return int(self.fst.get("rows", 6))

    def content_h(self):
        if self.tab == 1:
            return self.FILTER + max(1, min(self.n_farm(), len(self.farm_rows))) * self.FROW
        return self.COUNTS + max(1, len(self.rows) + len(self.ra.gone)) * self.ROW

    def refresh(self, rows):
        rows = rows[: self.n_rows()]
        self.ra.update([r.name for r in rows], {r.name: r for r in self.rows})
        for r in rows:
            self.bars.setdefault(r.name, Tween(0.0)).to(1.0 if r.maxed else (r.cur / r.need if r.need else 0))
        self.rows = rows
        if self.tab == 1 or not self.farm_rows:
            self.refresh_farm()
        self.relayout()

    def refresh_farm(self):
        fd = self.ui.fd
        fd.refresh()
        self.farm_rows = fd.rows(self.fst["categories"], self.fst["groups"])
        self.first = int(clamp(self.first, 0, max(0, len(self.farm_rows) - self.n_farm())))

    def animating(self):
        t = now()
        return (super().animating() or self.ra.busy() or self.scroll.moving()
                or any(b.moving() for b in self.bars.values())
                or any(r.flash_at and t - r.flash_at < T_FLOAT for r in self.rows))

    def on_wheel(self, d):
        if self.tab == 1:
            self._set_first(self.first + d)

    def _set_first(self, f):
        self.first = int(clamp(f, 0, max(0, len(self.farm_rows) - self.n_farm())))
        self.scroll.to(float(self.first))
        UI.kick()
        self.update()

    def paint_body(self, p, s, top, w):
        if self.tab == 1:
            self.paint_farm(p, s, top, w)
        else:
            self.paint_recent(p, s, top, w)

    # Recent
    def paint_recent(self, p, s, top, w):
        ui, t = self.ui, now()
        counts = ui.ov.counts or {}
        cw = (w - 16 * s) / 4
        for i, num in enumerate((1, 2, 3, 4)):
            x = 10 * s + i * cw
            c = counts.get(num)
            diamond(p, x + 4 * s, top + 11 * s, 3.4 * s, ui.cat_colour(num))
            text(p, x + 12 * s, top + 15 * s, f"{c[2]}/{c[3]}" if c else "-", font(12 * s, 700, True), TEXT)
            self.tips.append((QRectF(x, top, cw, 22 * s), num))
        y = top + self.COUNTS * s
        items = [(r, False) for r in self.rows] + [(g[1], True) for g in self.ra.gone.values() if g[1]]
        if not items:
            text(p, 12 * s, y + 26 * s, "Kill something with a soul and it shows up here.", font(11 * s), SUB, w=w - 24 * s)
            return
        for i, (r, gone) in enumerate(items):
            op, dx = self.ra.leave(r.name) if gone else (1, 0)
            e, dy = self.ra.enter(r.name) if not gone else (1, 0)
            p.save()
            p.setOpacity(op * e * stagger(self, i) * self.content_alpha * (0.5 if r.maxed else 1.0))
            p.translate(dx * s, dy * s)
            self._pet_row(p, s, r, y, w, t)
            p.restore()
            y += self.ROW * s

    def _pet_row(self, p, s, r, y, w, t):
        ui = self.ui
        col = ui.cat_colour(r.category)
        age = t - r.flash_at if r.flash_at else 99
        flash_bg(p, s, y, w, self.ROW * s, age)
        sz = 34 * s * pop(age)
        px, py = 10 * s + 17 * s - sz / 2, y + (self.ROW * s - sz) / 2
        pet_pic(p, ui, s, px, py, sz, r.pet_key, r.category)
        self.tips.append((QRectF(px, py, sz, sz), r.category))
        spots = self.pet_spots(type("Row", (), {"name": r.name, "area": ""}))
        if spots:                                        # rest on the row: its map; click: pin it
            self.tips.append((QRectF(0, y, w, self.ROW * s),
                              ("map", spots[0][0], spots[0][1], spots[0][2], r.name, spots, 0)))
        if not r.maxed:
            float_text(p, s, px + sz + 2 * s, py + 2 * s, "+1", col, age)
        x, right = 54 * s, w - 12 * s
        self._progress(p, s, r, x, right, y, age, col)
        b = self.bars.get(r.name)
        frac = b.get() if b else 0
        rr(p, QRectF(x, y + 24 * s, right - x, 3.5 * s), 1.75 * s, TILE)
        if frac > 0.003:
            rr(p, QRectF(x, y + 24 * s, max(3.5 * s, (right - x) * frac), 3.5 * s), 1.75 * s, col)
        seen = (datetime.now() - r.last_seen).total_seconds() if r.last_seen else 0
        text(p, x, y + 40 * s, ago(seen), font(10 * s), SUB)

    def _progress(self, p, s, r, x, right, y, age, col):
        diamond(p, x + 3.3 * s, y + 14 * s, 3.3 * s, col)
        lvl = "MAX" if r.maxed else f"Lv{r.level}"
        if r.maxed:
            rw = text(p, right, y + 18 * s, "MAXED", font(9.5 * s, 700), SUB, align="r")
        else:
            rw = text(p, right, y + 18 * s, f"/{r.need}", font(10 * s, 500, True), SUB, align="r")
            rw += text(p, right - rw, y + 18 * s, str(r.cur), font(13 * s * pop(age, amt=0.16), 700, True), TEXT, align="r")
        bf = font(8.5 * s, 600)
        bw = tw(lvl, bf) + 8 * s
        nw = text(p, x + 10 * s, y + 18 * s, r.name, font(12 * s, 600), TEXT, w=right - rw - 16 * s - x - bw)
        bx = x + 10 * s + nw + 5 * s
        rr(p, QRectF(bx, y + 9 * s, bw, 12 * s), 3.5 * s, TILE)
        text(p, bx + 4 * s, y + 18 * s, lvl, bf, SOFT)

    # Farm
    def _toggle_cat(self, k):
        c = self.fst["categories"]
        c[k] = not c.get(k, True)
        if not any(c.values()):
            c[k] = True
        self.refresh_farm(); self.relayout(); self.ui.save()

    def _pick_group(self, k):
        self.fst["groups"] = {k: True}
        self.first = 0
        self.scroll = Tween(0.0, 0.12)
        self.refresh_farm(); self.relayout(); self.ui.save()

    def paint_farm(self, p, s, top, w):
        ui = self.ui
        # region switch
        cur = next((k for k, v in self.fst["groups"].items() if v), "elyos")
        segmented(self, p, s, 10 * s, top + 3 * s, self.GROUPS, cur, "grp", self._pick_group)
        # family toggles
        dx = w - 12 * s
        for num in (4, 3, 2, 1):
            key = ui.cat_keys[num]
            on = self.fst["categories"].get(key, True)
            r = QRectF(dx - 16 * s, top + 4 * s, 16 * s, 20 * s)
            if self.hover == ("cat", key):
                rr(p, r, 5 * s, TILE_HI)
            diamond(p, r.center().x(), r.center().y(), 4 * s, alpha(ui.cat_colour(num), 1 if on else 0.3))
            self.hits.append((r, lambda k=key: self._toggle_cat(k), ("cat", key)))
            dx -= 18 * s
        y0 = top + self.FILTER * s
        if not self.farm_rows:
            text(p, 12 * s, y0 + 24 * s, "No pets match these filters.", font(11 * s), SUB)
            return
        n = self.n_farm()
        v = self.scroll.get()
        first = int(v)
        off = (v - first) * self.FROW * s
        p.save()
        p.setClipRect(QRectF(0, y0, w, n * self.FROW * s))
        y = y0 - off
        for r in self.farm_rows[first: first + n + 1]:
            self._farm_row(p, s, r, y, w)
            y += self.FROW * s
        p.restore()
        scrollbar(p, s, w - 5 * s, y0 + 4 * s, n * self.FROW * s - 8 * s, v, n, len(self.farm_rows),
                  self, self._set_first)

    def _farm_row(self, p, s, r, y, w):
        ui = self.ui
        col = ui.cat_colour(r.category)
        rect = QRectF(5 * s, y + 1 * s, w - 14 * s, self.FROW * s - 2 * s)
        hov = rect.contains(QPointF(self.mapFromGlobal(QCursor.pos()))) and self.underMouse()
        if hov:
            rr(p, rect, 7 * s, QColor("#161B26"))
        p.save()
        p.setOpacity(0.5 if r.maxed else 1.0)
        sz = 32 * s
        pet_pic(p, ui, s, 10 * s, y + (self.FROW * s - sz) / 2, sz, r.pet_key, r.category)
        x, right = 50 * s, w - 14 * s
        self._progress(p, s, r, x, right, y - 1 * s, 99, col)
        frac = 1.0 if r.maxed else (r.cur / r.need if r.need else 0)
        rr(p, QRectF(x, y + 22 * s, right - x, 3 * s), 1.5 * s, TILE)
        if frac > 0.003:
            rr(p, QRectF(x, y + 22 * s, max(3 * s, (right - x) * frac), 3 * s), 1.5 * s, col)
        if r.special:
            text(p, x, y + 38 * s, r.boss or "Shop, chests, achievements", font(9.5 * s), SUB, w=right - x)
        else:
            kib_line(p, s, x, y + 38 * s, right, r.kib)
        p.restore()
        if not r.special:
            spots = self.pet_spots(r)
            idx = next((i for i, sp in enumerate(spots) if sp[1] == r.world and sp[0] == r.name), 0)
            sub = spots[idx][2] if spots else r.area
            self.tips.append((rect, ("map", r.name, r.world, sub, r.name, spots, idx)))
            if len(spots) > 1:
                text(p, right, y + 38 * s - 13 * s, f"{len(spots)} spots", font(8.5 * s), SUB, align="r")

    def pet_spots(self, r):
        """Every map of this pet in the current region: [(key, world, subtitle, title)]."""
        maps = getattr(self.ui.ov, "maps", None)
        if not maps:
            return []
        cur = next((k for k, v in self.fst["groups"].items() if v), "elyos")
        inside = self.ui.world_groups.get(cur, set())
        out = []
        for k in [r.name] + [f"{r.name}#{i}" for i in range(2, 5)]:
            for w, e in maps.index.get(k, {}).items():
                if w in inside or not inside:
                    kib = e.get("kib")
                    where = e.get("label") or (r.area if k == r.name else "")
                    bits = [b for b in (where, f"◆{kib[0]} {kib[1]}" if kib and kib[0] else (kib[1] if kib else ""),
                                        f"{kib[2]} m" if kib and kib[2] is not None else "") if b]
                    out.append((k, w, " · ".join(bits), r.name))
        order = self.ui.world_order
        out.sort(key=lambda x: (order.get(x[1], 99), x[0]))
        return out

    def mouseMoveEvent(self, e):
        super().mouseMoveEvent(e)
        if self.tab == 1:
            self.update()


# --------------------------------------------------------- gather panel ---- #
class GatherPanel(Panel):
    KEY, TABS, W = "gather", ("Recent", "Spots"), 300
    ROW, SROW, FILTER, LIFE = 86, 42, 28, 600.0
    REGIONS = (("elyos", "ELY"), ("abyss", "ABY"), ("asmo", "ASM"))

    def __init__(self, ui):
        self.recent = {}          # item id -> {"last", "bump", "amt"}
        self.groups, self.ra = [], RowAnim()
        self.first, self.scroll = 0, Tween(0.0, 0.12)
        super().__init__(ui)

    def region(self):
        return self.st.get("region", "elyos")

    def n_spots(self):
        return int(self.st.get("rows", 7))

    def content_h(self):
        if self.tab == 1:
            from items import GATHER
            return self.FILTER + min(self.n_spots(), len(GATHER)) * self.SROW + 2
        return max(1, len(self.groups) + len(self.ra.gone)) * self.ROW

    def poll(self):
        q = getattr(self.ui.data, "gathered", None)
        while q:
            item, amt, t = q.popleft()
            r = self.recent.setdefault(item, {})
            r.update(last=t, bump=t, amt=amt)
        self._regroup()
        self._check_goals()

    # material goals: right-click a material to set one
    def goals(self):
        return self.st.setdefault("goals", {})

    def totals(self):
        mats = self.ui.data.materials() if hasattr(self.ui.data, "materials") else {}
        out = {}
        for item, cnt in mats.items():
            base, _ = self._names(item)
            if base:
                out[base] = out.get(base, 0) + cnt
        return out

    def _check_goals(self):
        g = self.goals()
        if not g:
            return
        done = self.st.setdefault("goal_done", {})
        tot = self.totals()
        for name, goal in list(g.items()):
            have = tot.get(name, 0)
            if have >= goal and done.get(name) != goal:
                done[name] = goal
                self.ui.save()
                self.ui.goal_reached(name, goal)
            elif have < goal and done.get(name) == goal and have < goal * 0.9:
                done.pop(name, None)                  # used some up: it can tell you again

    def set_goal(self, name, goal):
        g = self.goals()
        if goal:
            g[name] = goal
        else:
            g.pop(name, None)
        self.st.setdefault("goal_done", {}).pop(name, None)
        if goal and self.totals().get(name, 0) >= goal:
            self.st["goal_done"][name] = goal       # already there: no chime
        self.ui.save()
        self.update()

    def on_right(self, pos):
        name = None
        for rect, payload in self.tips:
            if isinstance(payload, tuple) and payload[0] == "map" and rect.contains(pos):
                name = payload[4]
        if not name:
            return
        cur = self.goals().get(name)
        m = QMenu()
        m.setStyleSheet("QMenu{background:#0E1118;color:#D7DCE6;border:1px solid #262C3A;padding:4px;"
                        "font-family:'%s';font-size:%dpx}QMenu::item{padding:4px 18px}"
                        "QMenu::item:selected{background:#262C3A;color:white}"
                        "QMenu::item:disabled{color:#A9B1C2}" % (BODY, max(11, int(16 * self.s))))
        head = m.addAction(f"{name} goal" + (f" (now {cur:,})" if cur else ""))
        head.setEnabled(False)
        have = self.totals().get(name, 0)
        for v in (50, 100, 200, 300, 500, 1000, 2000, 5000):
            a = m.addAction(f"{v:,}" + ("  ✓" if v == cur else ""))
            a.triggered.connect(lambda _=False, v=v: self.set_goal(name, v))
            if v <= have and v != cur:
                a.setText(f"{v:,}   (have it)")
        if cur:
            m.addSeparator()
            m.addAction("Clear goal").triggered.connect(lambda: self.set_goal(name, None))
        m.exec(QCursor.pos())

    def _goal_bar(self, p, s, name, total, x, y, wd):
        goal = self.goals().get(name)
        if not goal:
            return False
        from items import craft_of
        k = clamp(total / goal)
        col = QColor("#5FD38A") if k >= 1 else QColor(craft_of(name)[1])
        rr(p, QRectF(x, y, wd, 2 * s), 1 * s, TILE)
        rr(p, QRectF(x, y, wd * k, 2 * s), 1 * s, col)
        return True

    def _names(self, item):
        from items import base_name
        n = self.ui.items.name(item)
        return base_name(n) if n else (None, "")

    def _regroup(self):
        from items import grade_info, KIND
        t = now()
        mats = self.ui.data.materials() if hasattr(self.ui.data, "materials") else {}
        groups = {}
        for item, r in self.recent.items():
            base, _ = self._names(item)
            if base and t - r["last"] <= self.LIFE:
                g = groups.setdefault(base, {"last": 0, "items": {}})
                g["last"] = max(g["last"], r["last"])
        for item, cnt in mats.items():
            base, grade = self._names(item)
            if base in groups and cnt > 0:
                groups[base]["items"][item] = (grade, cnt)
        out = []
        for base, g in groups.items():
            tiles = sorted(((grade_info(gr)[0], item, gr, c) for item, (gr, c) in g["items"].items()),
                           key=lambda x: x[0])
            out.append({"name": base, "last": g["last"], "kind": KIND.get(base, "Food"),
                        "total": sum(x[3] for x in tiles), "tiles": tiles})
        out.sort(key=lambda g: -g["last"])
        for item in [i for i, r in self.recent.items() if t - r["last"] > self.LIFE + 5]:
            self.recent.pop(item)
        self.ra.update([g["name"] for g in out], {g["name"]: g for g in self.groups})
        self.groups = out
        self.relayout()

    def animating(self):
        t = now()
        return (super().animating() or self.ra.busy() or self.scroll.moving()
                or any(t - r.get("bump", 0) < T_FLOAT for r in self.recent.values()))

    def on_wheel(self, d):
        if self.tab == 1:
            self._set_first(self.first + d)

    def _set_first(self, f):
        n = len(self._spot_list())
        self.first = int(clamp(f, 0, max(0, n - self.n_spots())))
        self.scroll.to(float(self.first))
        UI.kick()
        self.update()

    def _pick_region(self, k):
        self.st["region"] = k
        self.first = 0
        self.scroll = Tween(0.0, 0.12)
        self.ui.save()
        self.update()

    def spots_of(self, name, region=None):
        """Every gathering spot of a material: [(map key, world, entry)], best region first."""
        maps = getattr(self.ui.ov, "maps", None)
        if not maps:
            return []
        out = []
        for k in ["res:" + name] + [f"res:{name}#{i}" for i in range(2, 5)]:
            for w, e in maps.index.get(k, {}).items():
                out.append((k, w, e))
        inside = self.ui.world_groups.get(region or self.region(), set())
        out = [x for x in out if x[1] in inside]          # only maps of the region tab you're on
        order = self.ui.world_order
        out.sort(key=lambda x: (order.get(x[1], 99), x[0]))
        return out

    def spot(self, name, region=None):
        lst = self.spots_of(name, region)
        if not lst:
            return None, None
        i = int(self.st.get("pick", {}).get(name, 0)) % len(lst)
        return lst[i][1], lst[i][2]

    def flick(self, name, d):
        n = len(self.spots_of(name, self.region()))
        if n:
            pk = self.st.setdefault("pick", {})
            pk[name] = (int(pk.get(name, 0)) + d) % n
            self.ui.save()
            self.update()

    def _map_tip(self, name, kind, rect, region=None):
        from items import craft_of
        lst = self.spots_of(name, region)
        if not lst:
            return None, None
        i = int(self.st.get("pick", {}).get(name, 0)) % len(lst)
        k, w, e = lst[i]
        spots = []
        for kk, ww, ee in lst:
            kib = ee.get("kib")
            bits = [craft_of(name)[0]] + ([f"◆{kib[0]} {kib[1]}" if kib[0] else kib[1]] if kib else []) + \
                ([f"{kib[2]} m"] if kib and kib[2] is not None else [])
            spots.append((kk, ww, " · ".join(bits), name))
        self.tips.append((rect, ("map", k, w, spots[i][2], name, spots, i)))
        return w, e

    def paint_body(self, p, s, top, w):
        if self.tab == 1:
            self.paint_spots(p, s, top, w)
            return
        t = now()
        y = top
        items = [(g, False) for g in self.groups] + [(v[1], True) for v in self.ra.gone.values() if v[1]]
        if not items:
            text(p, 12 * s, y + 26 * s, "Gather something and it shows up here.", font(11 * s), SUB, w=w - 24 * s)
            return
        for i, (g, gone) in enumerate(items):
            op, dx = self.ra.leave(g["name"]) if gone else (1, 0)
            e, dy = self.ra.enter(g["name"]) if not gone else (1, 0)
            p.save()
            p.setOpacity(op * e * stagger(self, i) * self.content_alpha)
            p.translate(dx * s, dy * s)
            self._row(p, s, g, y, w, t)
            p.restore()
            y += self.ROW * s

    def _tile(self, p, s, rect, item, grade, order, cnt, kind, age, amt):
        from items import grade_info
        gcol = QColor(grade_info(grade)[1])
        rr(p, rect, 7 * s, QColor(GRADE_TILE.get(order, GRADE_TILE[4])))
        ip = self.ui.items.icon_path(item) if item else None
        pix = self.ui.pix(ip) if ip else None
        inner = rect.adjusted(rect.width() * 0.1, rect.width() * 0.07, -rect.width() * 0.1, -rect.width() * 0.13)
        if pix is not None and not pix.isNull():
            p.drawPixmap(inner, pix, QRectF(pix.rect()))
        else:
            d = inner.width() * 0.1
            draw_icon(p, kind, inner.x() + d, inner.y() + d, inner.width() - 2 * d, gcol)
        rr(p, QRectF(rect.x() + rect.width() * 0.16, rect.bottom() - 2.5 * s, rect.width() * 0.68, 2.5 * s), 1.2 * s, gcol)
        if cnt is not None:
            cf = font(10.5 * s, 700, True)
            text(p, rect.right() - 3 * s + 1, rect.bottom() - 4.5 * s + 1, str(cnt), cf, QColor(0, 0, 0, 210), align="r")
            text(p, rect.right() - 3 * s, rect.bottom() - 4.5 * s, str(cnt), cf, TEXT, align="r")
        if amt:
            float_text(p, s, rect.right() + 3 * s, rect.y() + 1 * s, f"+{amt}", gcol, age)

    def _row(self, p, s, g, y, w, t):
        from items import craft_of
        bump = max((self.recent.get(x[1], {}).get("bump", 0) for x in g["tiles"]), default=0)
        age = t - bump
        flash_bg(p, s, y, w, self.ROW * s, age)
        x, right = 12 * s, w - 12 * s
        goal = self.goals().get(g["name"])
        gw = text(p, right, y + 17 * s, f"/{goal:,}", font(10 * s, 600), SUB, align="r") if goal else 0
        totw = gw + text(p, right - gw, y + 17 * s, f"{g['total']:,}", font(14 * s * pop(age), 700, True),
                         QColor("#5FD38A") if goal and g["total"] >= goal else TEXT, align="r")
        cname, ccol = craft_of(g["name"])
        diamond(p, x + 3 * s, y + 13 * s, 3 * s, QColor(ccol))
        nw = text(p, x + 10 * s, y + 17 * s, g["name"], font(12 * s, 600), TEXT, w=right - totw - 60 * s - x)
        text(p, x + 10 * s + nw + 6 * s, y + 17 * s, ago(t - g["last"]), font(9.5 * s), SUB)
        _w, e = self._map_tip(g["name"], g["kind"], QRectF(0, y, w, self.ROW * s))
        kib_line(p, s, x, y + 31 * s, right, e.get("kib") if e else None)
        tx, ts = x, 38 * s
        for order, item, grade, cnt in g["tiles"]:
            if tx + ts > right + 1:
                break
            r = self.recent.get(item, {})
            a = t - r.get("bump", -99)
            sz = ts * pop(a, amt=0.16)
            rect = QRectF(tx + (ts - sz) / 2, y + 37 * s + (ts - sz) / 2, sz, sz)
            self._tile(p, s, rect, item, grade, order, cnt, g["kind"], a, r.get("amt"))
            tx += ts + 5 * s
        if not self._goal_bar(p, s, g["name"], g["total"], x, y + 80 * s, right - x):
            life = clamp(1 - (t - g["last"]) / self.LIFE)
            rr(p, QRectF(x, y + 80 * s, right - x, 2 * s), 1 * s, TILE)
            rr(p, QRectF(x, y + 80 * s, (right - x) * life, 2 * s), 1 * s, QColor("#3A4456"))

    def _spot_list(self):
        from items import GATHER
        have = [(n, k) for n, k in GATHER if self.spot(n, self.region())[0]]
        return have or list(GATHER)

    def paint_spots(self, p, s, top, w):
        from items import base_name, craft_of
        segmented(self, p, s, 10 * s, top + 3 * s, self.REGIONS, self.region(), "reg", self._pick_region)
        names = self.ui.items.names
        split = self.ui.data.materials_split() if hasattr(self.ui.data, "materials_split") else {}
        ids, where = {}, {}
        for item, n in names.items():
            b, gr = base_name(n)
            if gr == "" and b not in ids:
                ids[b] = item
        for item, conts in split.items():
            n = names.get(item)
            if n:
                d = where.setdefault(base_name(n)[0], {})
                for c, cnt in conts.items():
                    d[c] = d.get(c, 0) + cnt
        lst = self._spot_list()
        n = self.n_spots()
        v = self.scroll.get()
        first = int(v)
        off = (v - first) * self.SROW * s
        y0 = top + self.FILTER * s
        p.save()
        p.setClipRect(QRectF(0, y0, w, n * self.SROW * s + 2 * s))
        y = y0 - off
        mouse = QPointF(self.mapFromGlobal(QCursor.pos()))
        for name, kind in lst[first: first + n + 1]:
            rect = QRectF(5 * s, y, w - 14 * s, self.SROW * s)
            wld, e = self._map_tip(name, kind, rect, self.region())
            if wld and self.underMouse() and rect.contains(mouse):
                rr(p, rect, 7 * s, QColor("#161B26"))
            p.save()
            p.setOpacity(1.0 if wld else 0.45)
            ts = 30 * s
            self._tile(p, s, QRectF(10 * s, y + (self.SROW * s - ts) / 2, ts, ts), ids.get(name), "", 0, None, kind, 99, 0)
            x, right = 48 * s, w - 14 * s
            d = where.get(name, {})
            total = sum(d.values())
            goal = self.goals().get(name)
            gw = text(p, right, y + 17 * s, f"/{goal:,}", font(9.5 * s, 600), SUB, align="r") if goal else 0
            tw_ = gw + text(p, right - gw, y + 17 * s, f"{total:,}", font(12 * s, 700, True),
                            QColor("#5FD38A") if goal and total >= goal else (TEXT if total else SUB), align="r")
            self._goal_bar(p, s, name, total, x, y + self.SROW * s - 4 * s, right - x)
            cname, ccol = craft_of(name)
            nw = text(p, x, y + 17 * s, name, font(11.5 * s, 600), TEXT, w=right - tw_ - x - 70 * s)
            text(p, x + nw + 6 * s, y + 17 * s, cname, font(9 * s, 600), QColor(ccol), w=right - tw_ - x - nw - 12 * s)
            if wld:
                parts = [f"{lbl} {d[c]}" for c, lbl in ((1, "bag"), (15, "chest"), (2, "server")) if d.get(c)]
                other = sum(v for c, v in d.items() if c not in (1, 2, 15))
                if other:
                    parts.append(f"other {other}")
                split_txt = " · ".join(parts)
                sw = text(p, right, y + 32 * s, split_txt, font(8.5 * s), SUB, align="r") if split_txt else 0
                nsp = len(self.spots_of(name, self.region()))
                kx = x
                if nsp > 1:
                    sw += text(p, right - sw - (6 * s if sw else 0), y + 32 * s, f"{nsp} spots",
                               font(8.5 * s), SUB, align="r") + 6 * s
                if False:
                    i = int(self.st.get("pick", {}).get(name, 0)) % nsp
                    pf = font(9 * s, 700)
                    lab = f"{i + 1}/{nsp}"
                    lw2 = tw(lab, pf)
                    lr = QRectF(x - 2 * s, y + 23 * s, 12 * s, 12 * s)
                    rr2 = QRectF(x + 10 * s + lw2 + 2 * s, y + 23 * s, 12 * s, 12 * s)
                    for r_, d_, tag in ((lr, -1, "prev"), (rr2, 1, "next")):
                        hov = self.hover == (tag, name)
                        if hov:
                            rr(p, r_, 3 * s, TILE_HI)
                        cx_, cy_ = r_.center().x(), r_.center().y()
                        pts = [(cx_ - 2 * s * d_, cy_ - 3 * s), (cx_ + 2 * s * d_, cy_), (cx_ - 2 * s * d_, cy_ + 3 * s)]
                        p.setPen(QPen(LIT if hov else SUB, 1.4 * s, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
                        p.setBrush(Qt.NoBrush)
                        p.drawPolyline([QPointF(*q) for q in pts])
                        self.hits.append((r_, lambda n=name, dd=d_: self.flick(n, dd), (tag, name)))
                    text(p, x + 10 * s + 1 * s, y + 32 * s, lab, pf, SOFT)
                    kx = rr2.right() + 4 * s
                kib_line(p, s, kx, y + 32 * s, right - sw - 8 * s, e.get("kib") if e else None)
            else:
                text(p, x, y + 32 * s, "Not in this region", font(9.5 * s), SUB)
            p.restore()
            y += self.SROW * s
        p.restore()
        scrollbar(p, s, w - 5 * s, y0 + 4 * s, n * self.SROW * s - 6 * s, v, n, len(lst), self, self._set_first)

    def mouseMoveEvent(self, e):
        super().mouseMoveEvent(e)
        if self.tab == 1:
            self.update()


# ----------------------------------------------------------- boss panel ---- #
DAY = ("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")


def local_when(sp):
    lt = sp.astimezone()
    t = lt.strftime("%I:%M %p").lstrip("0")
    return t if lt.date() == datetime.now().date() else f"{DAY[lt.weekday()]} {t}"


def coarse(secs):
    m = int(math.ceil(secs / 60)) if secs > 0 else 0        # round up, like the game's own counters
    if m < 1:
        return "now"
    if m < 60:
        return f"in {m}m"
    if m < 1440:
        return f"in {m // 60}h {m % 60}m"
    return f"in {m // 1440}d {(m % 1440) // 60}h"


def mins_text(secs):
    m = int(math.ceil(max(0, secs) / 60))
    if m >= 60:
        return f"{m // 60}h {m % 60}m" if m % 60 else f"{m // 60}h"
    return f"{m}m"


class BossPanel(Panel):
    """World bosses (Reshanta, on a clock) and field bosses (respawn after a kill), by region."""
    KEY, TITLE, W, ROW = "bosses", "Bosses", 300, 40
    TABS = ("Elyos", "Abyss", "Asmodian")
    REG = ("elyos", "abyss", "asmo")

    def __init__(self, ui):
        self.first, self.scroll = 0, Tween(0.0, 0.12)
        super().__init__(ui)
        if "tab" not in self.st:
            self.tab = 0

    def n_rows(self):
        return int(self.st.get("rows", 7))

    def _list(self):
        from bosses import BOSSES, FIELD
        reg = self.REG[min(self.tab, 2)]
        if reg == "abyss":
            return [("world", b) for b in sorted(BOSSES, key=lambda b: bool(b.get("last")))]
        return [("field", f) for f in FIELD if f["region"] == reg]

    def content_h(self):
        lst = self._list()
        return 24 + min(self.n_rows(), len(lst)) * self.ROW

    def set_tab(self, i):
        self.first, self.scroll = 0, Tween(0.0, 0.12)
        super().set_tab(i)

    def on_wheel(self, d):
        self._set_first(self.first + d)

    def _set_first(self, f):
        self.first = int(clamp(f, 0, max(0, len(self._list()) - self.n_rows())))
        self.scroll.to(float(self.first))
        UI.kick()
        self.update()

    def animating(self):
        return super().animating() or self.scroll.moving()

    def _kill(self, f):
        al = self.ui.bosses
        if al.field_spawn(f) and datetime.now(timezone.utc) >= al.field_spawn(f):
            al.mark_killed(f)                    # it was up and died again
        elif al.field_spawn(f):
            al.clear_kill(f)                     # second click cancels the timer
        else:
            al.mark_killed(f)
        self.ui.save()

    def paint_body(self, p, s, top, w):
        from bosses import next_spawn, SERVER_TZ
        al = self.ui.bosses
        tnow = datetime.now(timezone.utc)
        lst = self._list()
        reg = self.REG[min(self.tab, 2)]
        note = ("Picture = the Artwork it drops. Middle Reshanta isn't confirmed on Global (muted)."
                if reg == "abyss" else "Picture = the Artwork it drops. Timers update when you open M > Field Boss.")
        text(p, 12 * s, top + 15 * s, note, font(9.5 * s), SUB, w=w - 24 * s)
        y0 = top + 24 * s
        n = self.n_rows()
        v = self.scroll.get()
        first = int(v)
        p.save()
        p.setClipRect(QRectF(0, y0, w, n * self.ROW * s))
        y = y0 - (v - first) * self.ROW * s
        for kind, b in lst[first: first + n + 1]:
            key = b.get("key", b["name"])
            off = al.muted(key) if al else False
            right = w - 12 * s
            bell = QRectF(right - 20 * s, y + 9 * s, 20 * s, 20 * s)
            chip_right = bell.x() - 5 * s
            p.save()
            p.setOpacity(0.45 if off else 1.0)
            if kind == "world":
                sp = next_spawn(b, tnow)
                left = coarse((sp - tnow).total_seconds()) if sp else ""
                lw = text(p, chip_right, y + 23 * s, left, font(10.5 * s, 500), SOFT, align="r")
                h0, m0 = map(int, b["times"][0].split(":"))
                days = "Every 3 h" if len(b["days"]) == 7 else ", ".join(DAY[d] for d in sorted(
                    {datetime(2024, 1, 1 + d, h0, m0, tzinfo=SERVER_TZ).astimezone().weekday() for d in b["days"]}))
                sub = f"{days} · {local_when(sp)}" if sp else days
            else:
                st = al.field_state(b) if al else None
                f = font(9.5 * s, 600)
                label = None
                if st:
                    alive, t_ms, _seen = st
                    secs = t_ms / 1000 - time.time()
                    if alive:
                        label, bg, fg = "Up", QColor("#F2C94C"), INK
                        sub = f"Up for {mins_text(-secs)}"
                    elif secs > 0:
                        label, bg, fg = mins_text(secs), TILE_HI, TEXT
                        sub = f"Back at {local_when(datetime.fromtimestamp(t_ms / 1000, timezone.utc))}"
                    else:
                        label, bg, fg = "Up", QColor("#F2C94C"), INK
                        sub = "Should be up"
                else:
                    sub = f"Respawns {mins_text(b['every'] * 60)} after a kill"
                lw = 0
                if label:
                    cw = tw(label, f) + 14 * s
                    chip = QRectF(chip_right - cw, y + 10 * s, cw, 18 * s)
                    rr(p, chip, 9 * s, bg)
                    text(p, chip.center().x(), chip.y() + 12.5 * s, label, f, fg, align="c")
                    lw = cw
                maps = getattr(self.ui.ov, "maps", None)
                worlds = maps.index.get("boss:" + b["name"], {}) if maps else {}
                wsel = [w for w in worlds if w in self.ui.world_groups.get(b["region"], set())]
                if wsel:
                    self.tips.append((QRectF(0, y, bell.x() - 4 * s, self.ROW * s),
                                      ("map", "boss:" + b["name"], wsel[0], b["map"], b["name"])))
            art_tile(p, self.ui, s, QRectF(9 * s, y + 6 * s, 28 * s, 28 * s), b["name"])
            text(p, 44 * s, y + 17 * s, b.get("short", b["name"]), font(11.5 * s, 600), TEXT,
                 w=chip_right - lw - 52 * s)
            text(p, 44 * s, y + 30 * s, sub, font(9 * s), SUB, w=chip_right - lw - 52 * s)
            p.restore()
            hov = self.hover == ("bell", key)
            if hov:
                rr(p, bell, 6 * s, TILE)
            draw_icon(p, "bell", bell.x() + 4 * s, bell.y() + 4 * s, 12 * s,
                      QColor("#5A6275") if off else (LIT if hov else SUB))
            if al:
                self.hits.append((bell, lambda k=key: (al.toggle_mute(k), self.ui.save()), ("bell", key)))
            y += self.ROW * s
        p.restore()
        scrollbar(p, s, w - 5 * s, y0 + 3 * s, n * self.ROW * s - 6 * s, v, n, len(lst), self, self._set_first)

    def step(self):
        busy = super().step()
        if self.isVisible() and self.ui._n % 30 == 0:
            self.update()
        return busy


class EventsPanel(Panel):
    KEY, TITLE, W, ROW = "events", "Events", 300, 40

    def content_h(self):
        from bosses import EVENTS
        return len(EVENTS) * self.ROW + 26

    def paint_body(self, p, s, top, w):
        from bosses import EVENTS, next_event, next_reset, SERVER_TZ
        al = self.ui.bosses
        tnow = datetime.now(timezone.utc)
        rs = next_reset(tnow)                                            # daily reset 16:00 server time
        text(p, 12 * s, top + 15 * s, f"{SERVER_TZ.tzname(None)} server · daily reset "
                                      f"{coarse((rs - tnow).total_seconds())} · {local_when(rs)}",
             font(9.5 * s), SUB, w=w - 24 * s)
        y = top + 24 * s
        for e in EVENTS:
            st, open_now = next_event(e, tnow)
            key = "event:" + e["key"]
            off = al.muted(key) if al else False
            right = w - 12 * s
            bell = QRectF(right - 20 * s, y + 9 * s, 20 * s, 20 * s)
            p.save()
            p.setOpacity(0.45 if off else 1.0)
            f = font(9.5 * s, 600)
            if open_now:
                left = (st + timedelta(minutes=e["window"]) - tnow).total_seconds() if st else 0
                label = f"Open · {int(left // 60)}:{int(left % 60):02d}" if e["key"] == "shugo" else "Open"
                bg, fg = (QColor("#F2C94C"), INK) if e["key"] == "shugo" and left <= 60 else (QColor("#5FD38A"), INK)
            else:
                secs = (st - tnow).total_seconds() if st else 0
                label = (f"0:{int(secs):02d}" if secs < 60 else coarse(secs)[3:]) if st else ""
                soon = min(e["lead"]) * 60 if e["lead"] else 0
                bg, fg = (QColor("#F2C94C"), INK) if st and secs <= soon else (TILE_HI, TEXT)
            cw = tw(label, f) + 14 * s
            chip = QRectF(bell.x() - 5 * s - cw, y + 10 * s, cw, 18 * s)
            rr(p, chip, 9 * s, bg)
            text(p, chip.center().x(), chip.y() + 12.5 * s, label, f, fg, align="c")
            event_tile(p, self.ui, s, QRectF(9 * s, y + 6 * s, 28 * s, 28 * s), e["key"])
            text(p, 44 * s, y + 17 * s, e["name"], font(11.5 * s, 600), TEXT, w=chip.x() - 52 * s)
            sub = e["sub"] + (f" · {local_when(st)}" if st else "")
            text(p, 44 * s, y + 30 * s, sub, font(9 * s), SUB, w=chip.x() - 52 * s)
            p.restore()
            hov = self.hover == ("bell", key)
            if hov:
                rr(p, bell, 6 * s, TILE)
            draw_icon(p, "bell", bell.x() + 4 * s, bell.y() + 4 * s, 12 * s,
                      QColor("#5A6275") if off else (LIT if hov else SUB))
            if al:
                self.hits.append((bell, lambda k=key: (al.toggle_mute(k), self.ui.save()), ("bell", key)))
            y += self.ROW * s

    def step(self):
        busy = super().step()
        if self.isVisible() and self.ui._n % 30 == 0:
            self.update()
        return busy


def short(n):
    n = int(n)
    if abs(n) >= 1_000_000:
        return f"{n / 1_000_000:.2f}M".replace(".00M", "M")
    if abs(n) >= 10_000:
        return f"{n / 1000:.1f}K".replace(".0K", "K")
    return f"{n:,}"


class SessionPanel(Panel):
    """This session: souls, materials, Kinah and loot, each one opening up into the full list."""
    KEY, TITLE, W = "session", "Session", 300
    ROW, SUBROW = 28, 21
    KINAH, BKINAH = 930100031, 930100001

    def __init__(self, ui):
        self.t_sec = {}
        super().__init__(ui)
        ui.items.prefetch([self.KINAH, self.BKINAH, 533700182])

    def _open(self):
        return self.st.setdefault("expanded", [])

    def _toggle(self, k):
        o = self._open()
        if k in o:
            o.remove(k)
        else:
            o.append(k)
        self.t_sec[k] = now()
        self.ui.save()
        self.relayout()

    def _pet(self, name):
        for r in getattr(self.ui.pets, "farm_rows", []):
            if r.name == name:
                return r.pet_key, r.category
        return getattr(self.ui.data, "name_map", {}).get(name), None

    def _sections(self):
        d = getattr(self.ui.data, "session", None)
        if not d:
            return []
        from items import base_name, grade_info
        hrs = max(1 / 60, (time.time() - d["start"]) / 3600)
        names = self.ui.items
        pets = sorted(d["pets"].items(), key=lambda kv: -kv[1])
        mats = sorted(d.get("mats", {}).items(), key=lambda kv: -kv[1])
        loot = sorted(d.get("loot", {}).items(), key=lambda kv: -kv[1])

        def item_row(item, cnt):
            n = names.name(item) or "Loading…"
            col = QColor(grade_info(base_name(n)[1])[1]) if n else SOFT
            return (("item", item), n, f"{cnt:,}", col)

        def net(a, b):
            v = a - b
            return ("+" if v >= 0 else "−") + short(abs(v))
        out = [
            {"key": "souls", "label": "Souls", "icon": ("pet", pets[0][0]) if pets else ("glyph", "pets"),
             "value": short(d["souls"]), "rate": f"{short(d['souls'] / hrs)}/hr",
             "subs": [(("pet", n), n, f"{c:,}", SOFT) for n, c in pets]},
            {"key": "mats", "label": "Materials", "icon": ("ui", "materials"),
             "value": short(d["materials"]), "rate": f"{short(d['materials'] / hrs)}/hr",
             "subs": [item_row(i, c) for i, c in mats]},
            {"key": "kinah", "label": "Kinah", "icon": ("item", self.KINAH),
             "pair": ((self.KINAH, net(d["kinah_in"], d["kinah_out"])),
                      (self.BKINAH, net(d["bkinah_in"], d["bkinah_out"]))),
             "subs": [(("item", self.KINAH), "Kinah", f"+{short(d['kinah_in'])}   −{short(d['kinah_out'])}", SOFT),
                      (("item", self.BKINAH), "Bound Kinah", f"+{short(d['bkinah_in'])}   −{short(d['bkinah_out'])}",
                       SOFT)]},
            {"key": "loot", "label": "Items", "icon": ("ui", "items"),
             "value": short(sum(c for _, c in loot)), "rate": "",
             "subs": [item_row(i, c) for i, c in loot]},
        ]
        order = {"kinah": 0, "mats": 1, "loot": 2, "souls": 3}
        out.sort(key=lambda sec: order.get(sec["key"], 9))
        hist = []
        for t, kind, what, amt in reversed(d.get("log", [])[-60:]):
            when = datetime.fromtimestamp(t).strftime("%H:%M")
            if kind == "soul":
                hist.append((("pet", what), what, f"+{amt}", SOFT, when))
            elif kind in ("kinah", "bkinah"):
                hist.append((("item", what), "Kinah" if kind == "kinah" else "Bound Kinah",
                             ("+" if amt >= 0 else "−") + short(abs(amt)), SOFT if amt >= 0 else SUB, when))
            else:
                r = item_row(what, amt)
                hist.append((r[0], r[1], f"+{amt:,}", r[3], when))
        out.append({"key": "log", "label": "History", "icon": ("ui", "journal"),
                    "value": str(len(d.get("log", []))), "rate": "", "subs": hist})
        return out

    def content_h(self):
        n = 0
        for sec in self._sections():
            n += self.ROW
            if sec["key"] in self._open():
                n += max(1, len(sec["subs"])) * self.SUBROW + 4
        return max(self.ROW, n) + 6

    def paint_header(self, p, s, w):
        d = getattr(self.ui.data, "session", None)
        if d:
            text(p, w - 12 * s, 20 * s, mins_text(time.time() - d["start"]), font(10 * s), SUB, align="r")

    def _pic(self, p, s, rect, what):
        kind, v = what
        if kind == "pet":
            key, cat = self._pet(v)
            pet_pic(p, self.ui, s, rect.x(), rect.y(), rect.width(), key, cat)
            return
        rr(p, rect, 5 * s, TILE)
        if kind == "ui":
            if draw_ui_icon(p, self.ui, v, rect):
                return
            v = "gather"
        if kind == "item":
            ip = self.ui.items.icon_path(v)
            pix = self.ui.pix(ip) if ip else None
            if pix is not None and not pix.isNull():
                p.drawPixmap(rect.adjusted(1 * s, 1 * s, -1 * s, -1 * s), pix, QRectF(pix.rect()))
                return
            v = "gather"
        d = rect.width() * 0.2
        draw_icon(p, v, rect.x() + d, rect.y() + d, rect.width() - 2 * d, SOFT)

    def _chev(self, p, s, x, y, k):
        p.save()
        p.translate(x, y)
        p.rotate(90 * k)
        p.setPen(QPen(SUB, 1.4 * s, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        p.setBrush(Qt.NoBrush)
        p.drawPolyline([QPointF(-1.5 * s, -3 * s), QPointF(1.5 * s, 0), QPointF(-1.5 * s, 3 * s)])
        p.restore()

    def paint_body(self, p, s, top, w):
        secs = self._sections()
        if not secs:
            text(p, 12 * s, top + 20 * s, "Game data not available.", font(11 * s), SUB)
            return
        y, t = top + 2 * s, now()
        right = w - 12 * s
        for i, sec in enumerate(secs):
            k = sec["key"]
            opened = k in self._open()
            rect = QRectF(5 * s, y, w - 10 * s, self.ROW * s)
            p.save()
            p.setOpacity(stagger(self, i) * self.content_alpha)
            if self.hover == ("sec", k):
                rr(p, rect, 7 * s, QColor("#161B26"))
            self.hits.append((rect, lambda k=k: self._toggle(k), ("sec", k)))
            cy = y + self.ROW * s / 2
            self._pic(p, s, QRectF(11 * s, cy - 10 * s, 20 * s, 20 * s), sec["icon"])
            text(p, 38 * s, cy + 4.2 * s, sec["label"], font(11.5 * s, 600), TEXT)
            age = clamp((t - self.t_sec.get(k, 0)) / 0.16)
            self._chev(p, s, right - 1 * s, cy, ease_out(age) if opened else 1 - ease_out(age))
            vx = right - 12 * s
            if "pair" in sec:
                for item, val in reversed(sec["pair"]):
                    vx -= text(p, vx, cy + 4.2 * s, val, font(11.5 * s, 700, True), TEXT, align="r") + 3 * s
                    self._pic(p, s, QRectF(vx - 15 * s, cy - 7.5 * s, 15 * s, 15 * s), ("item", item))
                    vx -= 15 * s + 10 * s
            else:
                vx -= text(p, vx, cy + 4.2 * s, sec["value"], font(11.5 * s, 700, True), TEXT, align="r") + 6 * s
                if sec["rate"]:
                    text(p, vx, cy + 4 * s, sec["rate"], font(9 * s), SUB, align="r")
            p.restore()
            y += self.ROW * s
            if not opened:
                continue
            fade = ease_out(clamp((t - self.t_sec.get(k, 0) - 0.04) / 0.18))
            subs = sec["subs"] or [None]
            for j, row in enumerate(subs):
                p.save()
                p.setOpacity(self.content_alpha * clamp(fade * 1.6 - j * 0.04))
                sy = y + self.SUBROW * s / 2
                if row is None:
                    text(p, 38 * s, sy + 4 * s, "Nothing yet this session", font(10 * s), SUB)
                else:
                    what, name, val, col = row[:4]
                    x = 38 * s
                    if len(row) > 4:
                        x += text(p, x, sy + 3.8 * s, row[4], font(9 * s), SUB) + 7 * s
                    self._pic(p, s, QRectF(x, sy - 7.5 * s, 15 * s, 15 * s), what)
                    vw = text(p, right - 12 * s, sy + 4 * s, val, font(10.5 * s, 700, True), SOFT, align="r")
                    text(p, x + 21 * s, sy + 4 * s, name, font(10.5 * s), col, w=right - 12 * s - vw - x - 30 * s)
                p.restore()
                y += self.SUBROW * s
            y += 4 * s

    def step(self):
        busy = super().step()
        if self.isVisible() and self.ui._n % 30 == 0:
            self.relayout()
        if any(now() - v < 0.4 for v in self.t_sec.values()):
            self.update()
            busy = True
        return busy


# ----------------------------------------------------------------- pill ---- #
class Pill(QWidget, Fader):
    """Quiet, click-through note that fades away by itself."""

    def __init__(self, ui, anchor="top"):
        super().__init__()
        self.ui, self.anchor = ui, anchor
        _setup(self, click_through=True)
        self.fade_init()
        self.until, self.parts, self.icon = 0, [], "bosses"

    def show_msg(self, icon, parts, secs=6, tile=None):
        s = self.ui.S
        self.icon, self.parts, self.tile = icon, parts, tile
        w = (44 if tile else 34) * s + sum(tw(t, font(12 * s, 600 if b else 500)) + 5 * s for t, b in parts) + 8 * s
        w, h = int(w), int((34 if tile else 28) * s)
        self.resize(w, h)
        scr = QGuiApplication.primaryScreen().availableGeometry()
        if self.anchor == "top":
            self.move(scr.x() + (scr.width() - w) // 2, scr.y() + int(16 * s))
        else:
            self.move(scr.right() - w - int(20 * s), scr.y() + int(20 * s))
        self.until = now() + secs
        self.set_want(True)
        self.update()
        keep_on_top(self)

    def step(self):
        if self.target and now() > self.until:
            self.set_want(False)
        return self.fade_step() or bool(self.target)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        s = self.ui.S
        p.translate(0, -(1 - self.op) * 6 * s)
        h = self.height()
        rr(p, QRectF(0, 0, self.width(), h), h / 2, QColor(14, 17, 24, 210))
        tile = getattr(self, "tile", None)
        if tile:
            r = QRectF(5 * s, (h - 24 * s) / 2, 24 * s, 24 * s)
            if tile[0] == "boss":
                art_tile(p, self.ui, s, r, tile[1])
            else:
                event_tile(p, self.ui, s, r, tile[1])
            x = 36 * s
        else:
            draw_icon(p, self.icon, 11 * s, h / 2 - 6.5 * s, 13 * s, SOFT)
            x = 31 * s
        for t, b in self.parts:
            x += text(p, x, h / 2 + 4.3 * s, t, font(12 * s, 600 if b else 500), TEXT if b else SOFT) + 5 * s


# --------------------------------------------------------- flight glow ---- #
class FlightGlow(QWidget, Fader):
    """Flight energy full: the game's flight gauge drawn full right where it sits beside your
    character, sweeping up, glowing softly for a moment, then fading away. Click-through."""
    DUR = 3.6

    def __init__(self, ui):
        super().__init__()
        self.ui = ui
        _setup(self, click_through=True)
        self.fade_init()
        self.t0, self.geo = -99.0, None

    def start(self, rect):
        x0, y0, w, h = rect
        s = min(w / 1920, h / 1080)
        ox, oy, R = x0 + w / 2 - 25 * s, y0 + h / 2 + 31 * s, 123 * s
        left, top = int(ox - R - 150 * s), int(oy - R * 0.85)
        self.geo = (ox - left, oy - top, R, s)
        self.setGeometry(left, top, int(R * 0.45 + 175 * s), int(R * 1.7))
        self.t0 = now()
        self.set_want(True)
        keep_on_top(self)
        UI.kick()

    def step(self):
        age = now() - self.t0
        if self.target and age > self.DUR:
            self.set_want(False)
        busy = self.fade_step()
        if self.isVisible() and age < self.DUR + 0.5:
            self.update()
            busy = True
        return busy

    def paintEvent(self, _):
        if not self.geo:
            return
        from flight import T0, T1
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        ox, oy, R, s = self.geo
        age = now() - self.t0
        sweep = ease_out(clamp(age / 0.7))
        out = 1 - ease_out(clamp((age - (self.DUR - 0.8)) / 0.8))
        breathe = 0.75 + 0.25 * math.sin(clamp((age - 0.7) / 2.0) * math.pi)
        p.setOpacity(out)
        cyan = QColor("#7FEAF0")
        n = 48
        pts = []
        for k in range(n + 1):                     # fills from the bottom up, like the game's gauge
            t = T1 + (T0 - T1) * sweep * k / n
            pts.append(QPointF(ox + R * math.cos(t), oy + R * math.sin(t)))
        for wd, al in ((16 * s, 0.10 * breathe), (8 * s, 0.22 * breathe), (3.2 * s, 0.95)):
            p.setPen(QPen(alpha(cyan, al), wd, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
            p.drawPolyline(pts)
        # little wing and "Full" beside the gauge's middle
        la = ease_out(clamp((age - 0.45) / 0.35))
        p.setOpacity(out * la)
        mid = (T0 + T1) / 2
        mx, my = ox + R * math.cos(mid) - 14 * s, oy + R * math.sin(mid)
        f = font(15 * s, 700, True)
        tw_ = tw("Full", f)
        text(p, mx - tw_ + 1 * s, my + 6 * s + 1 * s, "Full", f, QColor(0, 0, 0, 160))
        text(p, mx - tw_, my + 6 * s, "Full", f, QColor(235, 252, 253))
        draw_icon(p, "flight", mx - tw_ - 26 * s, my - 10 * s, 20 * s, cyan)


# ------------------------------------------------------------- launcher ---- #
class Dock(QWidget, Fader):
    ITEMS = (("session", "Session"), ("pets", "Pets"), ("gather", "Gathering"), ("bosses", "Bosses"),
             ("events", "Events"))
    LOGO, ICON, GAP, PAD, TIP = 40, 32, 5, 4, 28

    def __init__(self, ui):
        super().__init__()
        self.ui = ui
        _setup(self)
        self.fade_init()
        self.st = ui.state.setdefault("dock", {})
        exp = self.st.get("expanded", True)
        self.prog_from, self.prog_to, self.prog_t0 = (1.0, 1.0, 0) if exp else (0.0, 0.0, 0)
        self.lit = {k: Tween(1.0 if ui.open.get(k) else 0.0, 0.12) for k, _ in self.ITEMS}
        self.hover, self.press, self.drag = None, None, None
        self.top = 0
        self.resize_to_scale()

    # geometry: the window is a fixed strip; the logo sits at its left or right end
    def resize_to_scale(self):
        s = self.ui.S
        n = len(self.ITEMS)
        self.full_w = (self.PAD * 2 + self.LOGO + self.GAP + n * (self.GAP + self.ICON)) * s
        self.resize(int(self.full_w + 2), int((self.PAD * 2 + self.LOGO + self.TIP) * s))
        self.top = self.TIP * s
        self.place()

    def right_side(self):
        x, _ = self.logo_pos()
        g = QGuiApplication.primaryScreen().availableGeometry()
        return x > g.center().x()

    def logo_pos(self):
        x, y = self.st.get("lx"), self.st.get("ly")
        if x is None or y is None:
            x, y = self.ui.default_logo()
        return int(x), int(y)

    def logo_size(self):
        return (self.PAD * 2 + self.LOGO) * self.ui.S

    def place(self):
        x, y = self.logo_pos()
        y -= int(self.TIP * self.ui.S)
        if self.right_side():
            x = x + self.logo_size() - self.width()
        if (x, y) != (self.x(), self.y()):
            self.move(x, y)

    def prog(self):
        k = ease_out(clamp((now() - self.prog_t0) / T_DOCK))
        return self.prog_from + (self.prog_to - self.prog_from) * k

    def expanded(self):
        return bool(self.st.get("expanded", True))

    def refold(self):
        fold = self.ui.auto_fold and not self.ui.fold_override
        to = 0.0 if fold or not self.expanded() else 1.0
        if to != self.prog_to:
            self.prog_from, self.prog_to, self.prog_t0 = self.prog(), to, now()
            UI.kick()

    def set_expanded(self, on):
        self.prog_from, self.prog_to, self.prog_t0 = self.prog(), 1.0 if on else 0.0, now()
        self.st["expanded"] = on
        self.ui.save()
        UI.kick()

    def _centres(self):
        """(logo centre x, icon centre xs) in window coords."""
        s = self.ui.S
        ls = self.logo_size()
        right = self.right_side()
        lcx = self.width() - ls / 2 if right else ls / 2
        xs = []
        for i in range(len(self.ITEMS)):
            d = ls / 2 + (self.GAP + self.ICON / 2 + i * (self.GAP + self.ICON)) * s
            xs.append(lcx - d if right else lcx + d)
        return lcx, xs

    def _hit(self, pos):
        s = self.ui.S
        cy = self.top + self.logo_size() / 2
        lcx, xs = self._centres()
        if math.hypot(pos.x() - lcx, pos.y() - cy) <= self.LOGO / 2 * s:
            return "logo"
        if self.prog() > 0.6:
            for (k, _), cx in zip(self.ITEMS, xs):
                if abs(pos.x() - cx) <= self.ICON / 2 * s and abs(pos.y() - cy) <= self.ICON / 2 * s:
                    return k
        return None

    def step(self):
        busy = self.fade_step()
        for k, _ in self.ITEMS:
            self.lit[k].to(1.0 if self.ui.open.get(k) else 0.0)
        if now() - self.prog_t0 < T_DOCK * 2.2 or any(t.moving() for t in self.lit.values()):
            busy = True
            if self.isVisible():
                self.update()
        fl = self.ui.flight
        ring = fl.ring() if fl else None
        if ring and ring[1] == "full":                  # the glow: smooth while it plays
            busy = True
            self.update()
        elif (ring or getattr(self, "_ring_on", False)) and self.ui._n % 15 == 0:
            self.update()
        return busy

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        s, n = self.ui.S, len(self.ITEMS)
        ls = self.logo_size()
        top = self.top
        cy = top + ls / 2
        right = self.right_side()
        lcx, xs = self._centres()
        pr = self.prog()
        if pr > 0.001:
            w = ls + (self.full_w - ls) * clamp(pr)
            x0 = self.width() - w if right else 0
            rr(p, QRectF(x0, top, w, ls), ls / 2, alpha(BG, clamp(pr * 2)))
        if self.drag and self.drag[2]:
            rr(p, QRectF(lcx - ls / 2, top, ls, ls), ls / 2, QColor("#3A4456"))
        k = 0.9 if self.press == "logo" else (1.05 if self.hover == "logo" else 1.0)
        lr = self.LOGO / 2 * s * k
        rr(p, QRectF(lcx - lr, cy - lr, lr * 2, lr * 2), lr, INK)
        p.save()
        p.translate(lcx, cy)
        p.rotate(45 * clamp(pr, 0, 1.2))
        draw_icon(p, "logo", -11 * s * k, -11 * s * k, 22 * s * k, LIT)
        p.restore()
        self._flight_ring(p, s, lcx, cy, lr)
        for i, ((key, label), cx) in enumerate(zip(self.ITEMS, xs)):
            t = clamp(pr * (1 + 0.15 * n) - i * 0.15)
            if t <= 0:
                continue
            e = ease_back(t)
            cx = cx + (1 - e) * 10 * s * (1 if right else -1)
            sz = self.ICON * s * (0.6 + 0.4 * e) * (0.88 if self.press == key else 1.0)
            p.setOpacity(clamp(t * 2))
            lit = clamp(self.lit[key].get())
            bg = _mix(TILE_HI if self.hover == key else TILE, LIT, lit)
            rr(p, QRectF(cx - sz / 2, cy - sz / 2, sz, sz), sz / 2, bg)
            if not draw_tab_icon(p, self.ui, key, QRectF(cx - sz * 0.34, cy - sz * 0.34, sz * 0.68, sz * 0.68), lit):
                draw_icon(p, key, cx - sz * 0.27, cy - sz * 0.27, sz * 0.54, _mix(SOFT, INK, lit), bg)
            badge = self.ui.badge(key)
            if badge:
                bf = font(9 * s, 700, True)
                bw = tw(badge, bf) + 7 * s
                bx, by = cx + sz / 2 - bw + 6 * s, cy - sz / 2 - 5 * s
                rr(p, QRectF(bx, by, bw, 13 * s), 6.5 * s, QColor("#F2C94C"))
                text(p, bx + 3.5 * s, by + 9.8 * s, badge, bf, INK)
            if self.hover == key and not (self.drag and self.drag[2]):
                f = font(10.5 * s, 500)
                lw = tw(label, f) + 12 * s
                r = QRectF(clamp(cx - lw / 2, 0, self.width() - lw), top - 22 * s, lw, 18 * s)
                rr(p, r, 5 * s, INK)
                text(p, r.center().x(), r.y() + 12.8 * s, label, f, LIT, align="c")
            p.setOpacity(1.0)

    def _flight_ring(self, p, s, cx, cy, lr):
        """Flight energy refilling after you land: a tiny wing badge with the % on the circle's edge,
        glowing softly once and fading away when it's full."""
        self._ring_on = False
        return
        fl = self.ui.flight
        ring = fl.ring() if fl else None
        if not ring:
            return
        fill, st = ring
        self._ring_on = True
        # a tiny wing badge on the circle's lower edge: % while it refills, a soft glow once when full
        cyan = QColor("#6FE0E8")
        f = font(8.5 * s, 700, True)
        label = "Full" if st == "full" else f"{int(fill * 100)}%"
        bw = tw(label, f) + 19 * s
        r = QRectF(cx + lr * 0.15, min(cy + lr * 0.45, self.height() - 15 * s), bw, 14 * s)
        if r.right() > self.width() - 1:
            r.moveRight(self.width() - 1)
        a = 1.0
        if st == "full":
            age = time.time() - fl.told_at
            a = clamp(1 - (age - 3) / 2)                      # stays 3 s, then fades
            glow = 0.5 + 0.5 * math.sin(clamp(age / 1.4) * math.pi)
            p.setOpacity(a * 0.35 * glow)
            rr(p, r.adjusted(-3 * s, -3 * s, 3 * s, 3 * s), 9 * s, cyan)
        p.setOpacity(a)
        rr(p, r, 7 * s, QColor(14, 17, 24, 235))
        p.setPen(QPen(alpha(cyan, 0.7), 1 * s))
        p.setBrush(Qt.NoBrush)
        p.drawRoundedRect(r, 7 * s, 7 * s)
        p.setPen(Qt.NoPen)
        draw_icon(p, "flight", r.x() + 3 * s, r.y() + 1.5 * s, 11 * s, cyan)
        text(p, r.x() + 15 * s, r.y() + 10.4 * s, label, f, QColor(235, 252, 253))
        p.setOpacity(1.0)
        if self.hover == "logo" and not (self.drag and self.drag[2]):
            label = "Flight energy full" if st == "full" else f"Flight energy {int(fill * 100)}%  ·  full in {fl.badge or '…'}"
            f = font(10.5 * s, 500)
            lw = tw(label, f) + 12 * s
            r = QRectF(clamp(cx - lw / 2, 0, self.width() - lw), self.top - 22 * s, lw, 18 * s)
            rr(p, r, 5 * s, INK)
            text(p, r.center().x(), r.y() + 12.8 * s, label, f, LIT, align="c")

    def mousePressEvent(self, e):
        if e.button() != Qt.LeftButton:
            return
        self.press = self._hit(e.position())
        if self.press == "logo":
            self.drag = (e.globalPosition().toPoint(), self.logo_pos(), False)
        self.update()

    def mouseMoveEvent(self, e):
        if self.drag:
            g0, (lx, ly), moved = self.drag
            d = e.globalPosition().toPoint() - g0
            if moved or abs(d.x()) + abs(d.y()) > 5:      # a drag, not a click: move everything with it
                self.drag = (g0, (lx, ly), True)
                self.st["lx"], self.st["ly"] = lx + d.x(), ly + d.y()
                self.place()
                self.ui.layout()
        h = self._hit(e.position())
        if h != self.hover:
            self.hover = h
            self.setCursor(Qt.PointingHandCursor if h else Qt.ArrowCursor)
            UI.kick()
            self.update()

    def mouseReleaseEvent(self, e):
        hit = self._hit(e.position())
        if self.drag and self.drag[2]:
            self.drag = None
            self.press = None
            self.ui.save()
            self.update()
            return
        self.drag = None
        if hit and hit == self.press:
            if hit == "logo":
                if self.ui.auto_fold and not self.ui.fold_override:   # folded by a window: open anyway
                    self.ui.fold_override = True
                    self.st["expanded"] = True
                    self.refold()
                else:
                    self.set_expanded(not self.expanded())
            else:
                self.ui.toggle(hit)
        self.press = None
        UI.kick()
        self.update()

    def leaveEvent(self, _):
        self.hover = None
        self.update()


# ----------------------------------------------------------- controller ---- #
class UI:
    _inst = None
    last_wheel = "none yet"

    def __init__(self, ov, cfg, state, data, app_dir, fd):
        UI._inst = self
        self.ov, self.cfg, self.state, self.data, self.fd = ov, cfg, state, data, fd
        self.open = state.setdefault("open", {})
        for k, v in (("pets", True), ("gather", True), ("bosses", False), ("events", False), ("session", False)):
            self.open.setdefault(k, v)
        for k in [k for k in self.open if k not in ("pets", "gather", "bosses", "events", "session")]:
            self.open.pop(k)
        self.colours = {k: QColor(v) for k, v in cfg["colours"].items()}
        self.world_groups, self.world_order = {}, {}
        self.cat_keys = {1: "cogni", 2: "fera", 3: "natura", 4: "varian"}
        if hasattr(data, "items"):
            self.items = data.items
        else:
            from items import ItemInfo
            self.items = ItemInfo(Path(app_dir) / "maps")
        self.S = float(state.get("ui_scale", DEFAULT_SCALE))
        self.sound_dir = Path(app_dir) / "sounds"
        self.app_dir = Path(app_dir)
        try:
            import sounds
            sounds.make(self.sound_dir)
        except Exception:
            pass
        self.moving = False
        self.auto_fold, self.fold_override, self._fold_last = False, False, False
        self._want_last = False
        self.os_notify = None
        self.bosses = self.flight = None
        self._pix = {}
        self.layout_needed = True
        self.stack_off, self.clip_y, self.reveal = 0, 0, None
        self.timer = QTimer()
        self.timer.setInterval(15)
        self.timer.timeout.connect(self.frame)
        try:                                   # all material icons, every grade, from the start
            from items import ALL_MATERIAL_IDS
            self.items.prefetch(ALL_MATERIAL_IDS)
        except Exception:
            pass
        self._preload = None
        self._rec_done = {}
        try:
            self.items.find_artworks()
        except Exception:
            pass
        self.pets = PetsPanel(self)
        self.gather = GatherPanel(self)
        self.boss = BossPanel(self)
        self.events = EventsPanel(self)
        self.session = SessionPanel(self)
        self.dock = Dock(self)
        self.pill = Pill(self, "top")
        self.glow = FlightGlow(self)
        self.toast = Pill(self, "topright")
        self._n = 0

    @classmethod
    def kick(cls):
        if cls._inst and not cls._inst.timer.isActive():
            cls._inst.timer.start()

    def widgets(self):
        return (self.dock, self.session, self.pets, self.gather, self.boss, self.events, self.pill, self.toast,
                self.glow)

    def _record_events(self):
        """Save the game data for 30 s when Shugo / Dimensional Invasion opens, to learn where key counts live."""
        if self._n % 30:
            return
        from bosses import EVENTS, next_event
        rd = getattr(self.data, "reader", None)
        if not rd:
            return
        for e in EVENTS:
            if e["key"] not in ("shugo", "invasion"):
                continue
            st, open_now = next_event(e)
            if open_now and st and (datetime.now(timezone.utc) - st).total_seconds() < 40:
                folder = Path(self.sound_dir).parent
                n = len(list(folder.glob(f"event_{e['key']}_*.jsonl")))
                if n < 3 and self._rec_done.get(e["key"]) != st:
                    self._rec_done[e["key"]] = st
                    rd.record(30, str(folder / f"event_{e['key']}_{n + 1}.jsonl"))

    def _raise_all(self):
        for w in (self.dock, *self.panels()):
            if w.isVisible():
                w.raise_()
                keep_on_top(w)

    def preload(self):
        """Load every picture into memory a few at a time, so nothing pops in later."""
        if self._preload is None:
            self._preload = [("item", f) for f in (Path(self.items.icon_dir).glob("*.png")
                                                   if Path(self.items.icon_dir).exists() else [])]
            self._preload += [("pet", k) for k in getattr(self.data, "name_map", {}).values()]
        for _ in range(6):
            if not self._preload:
                return
            kind, v = self._preload.pop()
            if kind == "item":
                self.pix(v)
            else:
                try:
                    self.data.icon(v)
                except Exception:
                    pass

    def frame(self):
        busy = False
        for w in self.widgets():
            busy |= bool(w.step())
        if self.layout_needed:
            self.layout()
        if not busy:
            self.timer.stop()

    def default_logo(self):
        scr = QGuiApplication.primaryScreen().availableGeometry()
        x, y = self.state.get("x"), self.state.get("y")
        if x is None or y is None:
            return scr.right() - 70, scr.top() + 160
        return int(x) + int(self.state.get("width", 300)) - 50, max(scr.top() + 8, int(y) - 60)

    def layout(self):
        """Open panels stack under the launcher, lined up with its side of the screen."""
        self.layout_needed = False
        lx, ly = self.dock.logo_pos()
        ls = self.dock.logo_size()
        right = self.dock.right_side()
        y0 = ly + ls + 8 * self.S
        self.clip_y = int(ly + ls + 3 * self.S)
        # how tall the open column is, and how far it may scroll so the last panel fits on screen
        spans, y = {}, y0
        for pnl in self.panels():
            if pnl.target > 0:
                hb = pnl.h_tw.b if hasattr(pnl, "h_tw") else pnl.height()
                spans[pnl.KEY] = (y, y + hb)
                y += int(hb + 0.5) + 6 * self.S
        scr = QGuiApplication.screenAt(QPoint(int(lx), int(ly))) or QGuiApplication.primaryScreen()
        bottom = scr.availableGeometry().bottom() - 8 * self.S
        max_off = max(0, int(y - 6 * self.S - bottom))
        if self.reveal in spans:                    # just opened: bring it into view
            a, b = spans[self.reveal]
            self.stack_off = max(self.stack_off, int(b - bottom))
            self.stack_off = min(self.stack_off, int(a - y0))
        self.reveal = None
        self.stack_off = int(clamp(self.stack_off, 0, max_off))
        y = y0 - self.stack_off
        for pnl in self.panels():
            if pnl.target <= 0 and not pnl.isVisible():
                continue
            x = lx + ls - pnl.width() if right else lx
            pnl.glide_to(int(x), int(y), snap=pnl.op < 0.05 or self.dock.drag is not None)
            if pnl.target > 0:
                hb = pnl.h_tw.b if hasattr(pnl, "h_tw") else pnl.height()
                y += int(hb + 0.5) + 6 * self.S

    def scroll_stack(self, step):
        """Mouse wheel over a panel that has nothing more to scroll: move the whole column."""
        old = self.stack_off
        self.stack_off = max(0, self.stack_off + int(step * 60 * self.S))
        self.layout()
        if self.stack_off != old:
            for pnl in self.panels():
                pnl.update()
            UI.kick()

    def set_scale(self, v):
        self.S = v
        self.state["ui_scale"] = v
        for p in self.panels():
            p.relayout()
        self.dock.resize_to_scale()
        self.layout()
        self.save()
        for w in self.widgets():
            w.update()

    def set_moving(self, on):
        self.moving = on
        self.dock.update()

    def cat_colour(self, cat):
        return self.colours.get(self.cat_keys.get(cat), SOFT)

    def pix(self, path):
        k = str(path)
        pm = self._pix.get(k)
        if pm is None or pm.isNull():           # never keep a half-downloaded picture
            pm = QPixmap(k)
            if not pm.isNull():
                self._pix[k] = pm
        return pm

    def panels(self):
        return [self.session, self.pets, self.gather, self.boss, self.events]

    def toggle(self, key):
        self.open[key] = not self.open.get(key)
        if self.open[key]:
            self.reveal = key
        self.layout_needed = True
        self.save()

    def save(self):
        self.ov._queue_save()

    def badge(self, key):
        if key == "bosses" and self.bosses:
            tnow = datetime.now(timezone.utc)
            for sp, b in self.bosses.upcoming():
                if not self.bosses.muted(b.get("key", b["name"])):
                    m = (sp - tnow).total_seconds() / 60
                    return f"{max(0, int(m))}m" if m <= 15 else None
        return None

    def boss_alert(self, b, lead, sp):
        if "sound" in b:                                   # an event
            parts = [(b["name"], True), (f"{-lead:g} min left to join" if lead < 0 else
                                         "open now" if lead == 0 else f"starts in {lead:g} min", False)]
            keys = self.data.event_keys().get(b["key"]) if hasattr(self.data, "event_keys") else None
            if keys is not None:
                parts.append((f"· {keys} key{'s' if keys != 1 else ''}" if keys else "· no keys", False))
            self.pill.show_msg("events", parts, tile=("event", b["key"]))
            self.play(b["sound"])
            if self.os_notify:
                self.os_notify(b["name"], " ".join(t for t, _ in parts[1:]))
        else:
            self.pill.show_msg("bosses", [(b["name"], True), (f"in {lead} min", False), (f"· {b.get('map', '')}", False)],
                               tile=("boss", b["name"]))
            self.play("boss")
            if self.os_notify:
                self.os_notify(b["name"], f"Spawns in {lead} min · {b.get('map', '')}")
        UI.kick()

    def goal_reached(self, name, goal):
        self.pill.show_msg("gather", [(f"{name} goal reached", True), (f"{goal:,}", False)], secs=6)
        self.play("shugo")
        if self.os_notify:
            self.os_notify(f"{name} goal reached", f"You have {goal:,}")
        UI.kick()

    def play(self, name):
        vol = float(self.state.get("volume", 0.5)) if self.state.get("sounds", True) else 0.0
        if vol > 0:
            import sounds
            sounds.play(self.sound_dir, name, vol)

    def flight_full(self):
        self.play("flight")
        rect = getattr(self.flight, "rect", None)
        try:
            in_game = self.ov.game.info()[0]
        except Exception:
            in_game = True
        if rect and in_game and not self.auto_fold:     # not over a full-screen window or in a dungeon
            self.glow.start(rect)
        if self.os_notify:
            self.os_notify("Flight energy full", "Ready to fly")
        UI.kick()

    def tick(self, want, rows):
        """Called by the main loop (about 30 times a second)."""
        self._n += 1
        if want and not self._want_last:
            for delay in (0, 150, 500, 1200):
                QTimer.singleShot(delay, self._raise_all)
        self._want_last = want
        self.dock.set_want(want)
        if not self.auto_fold:                          # "open anyway" only lasts until that window closes
            self.fold_override = False
        fold = self.auto_fold and not self.fold_override
        if fold != self._fold_last:                     # full-screen window / dungeon: fold to the circle
            self._fold_last = fold
            self.dock.refold()
            if not fold:                                # back from a full-screen window: make sure we're on top
                for delay in (0, 120, 400, 1000):
                    QTimer.singleShot(delay, self._raise_all)
        shown = want and self.dock.expanded() and not fold   # collapsing the launcher hides every panel
        for pnl in self.panels():
            pnl.set_want(shown and self.open.get(pnl.KEY, False))
        self._record_events()
        if self._n % 10 == 1:
            self.pets.refresh(rows)
            self.gather.poll()
            self.layout_needed = True
        if self._n % 600 == 3:
            self.boss.update()
        if self.layout_needed:
            self.layout()
        self.preload()
        if self._n % 900 == 450:              # pick up pictures downloaded since
            self._preload = None
        if self._n % 20 == 0:
            for w in (self.dock, *self.panels()):
                if w.isVisible():
                    keep_on_top(w)
        self.frame()
