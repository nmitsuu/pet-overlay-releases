"""
Makes one small map picture per farmable pet (per region), the first time it runs.

It downloads guildmanager.app's public map data and the region map images once,
crops a square around the pet's main spawn area, marks every spawn and Kibelisk,
saves small PNGs in the "maps" folder, then deletes the big region images.
Nothing here touches the game.
"""
import json
import threading
import traceback
import urllib.request
from pathlib import Path

from PySide6.QtCore import QPointF, QRectF, QSize, Qt
from PySide6.QtGui import (QColor, QFont, QFontMetricsF, QImage, QImageReader,
                           QLinearGradient, QPainter, QPainterPath, QPen, QPolygonF,
                           QRadialGradient)

MAP_VERSION = 14
OUT = 640                  # saved picture size (px), shown at half size for sharpness
MAX_DECODE = 0             # 0 = keep the region map at full resolution
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                    "(KHTML, like Gecko) Chrome/130.0 Safari/537.36"}
GENUS_KEY = {"C": "cogni", "F": "fera", "N": "natura", "V": "varian"}


def _get(url, timeout=180):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def spots(P, r=12000, most=4, others=()):
    """Where a pet is farmed: groups of spawn points about 120 m across, busiest first. Each group starts
    with its densest real spawn point (so an icon sits where they really spawn, not in an empty middle of a
    spread). At least three groups whenever the points allow it."""
    left = [tuple(p) for p in P]
    out = []
    while left and len(out) < 8:
        dens = [(sum(1 for q in left if (q[0] - p[0]) ** 2 + (q[1] - p[1]) ** 2 < r * r), p) for p in left]
        n, c = max(dens)
        if len(out) >= 3 and n < 3:                  # (up to 8 found, the best `most` are kept)
            break
        near = [q for q in left if (q[0] - c[0]) ** 2 + (q[1] - c[1]) ** 2 < r * r]
        mx = sum(q[0] for q in near) / len(near)
        my = sum(q[1] for q in near) / len(near)
        head = min(near, key=lambda q: (q[0] - mx) ** 2 + (q[1] - my) ** 2)     # the real point nearest the middle
        out.append([head] + [q for q in near if q != head])
        gone = set(q for q in left if (q[0] - c[0]) ** 2 + (q[1] - c[1]) ** 2 < (1.25 * r) ** 2)
        left = [q for q in left if q not in gone]
    while 0 < len(out) < 3:                  # a pet in one or two camps: show where in the camp, too
        big = max(out, key=len)
        if len(big) < 4:
            break
        a = max(big, key=lambda q: (q[0] - big[0][0]) ** 2 + (q[1] - big[0][1]) ** 2)
        b = max(big, key=lambda q: (q[0] - a[0]) ** 2 + (q[1] - a[1]) ** 2)
        for _ in range(8):                   # two-way split of the camp
            A = [q for q in big if (q[0] - a[0]) ** 2 + (q[1] - a[1]) ** 2 <= (q[0] - b[0]) ** 2 + (q[1] - b[1]) ** 2]
            B = [q for q in big if q not in A]
            if not A or not B:
                break
            a = (sum(q[0] for q in A) / len(A), sum(q[1] for q in A) / len(A))
            b = (sum(q[0] for q in B) / len(B), sum(q[1] for q in B) / len(B))
        if not A or not B or (a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 < 6000 ** 2:
            break
        ha = min(A, key=lambda q: (q[0] - a[0]) ** 2 + (q[1] - a[1]) ** 2)
        hb = min(B, key=lambda q: (q[0] - b[0]) ** 2 + (q[1] - b[1]) ** 2)
        i = out.index(big)
        out[i:i + 1] = sorted([[ha] + [q for q in A if q != ha], [hb] + [q for q in B if q != hb]], key=len, reverse=True)
    if others:
        # best farming first: the most of this pet close together, with the fewest other pets mixed in
        def score(grp):
            mx = sum(q[0] for q in grp) / len(grp)
            my = sum(q[1] for q in grp) / len(grp)
            mixed = sum(1 for q in others if (q[0] - mx) ** 2 + (q[1] - my) ** 2 < r * r)
            return len(grp) * len(grp) / (len(grp) + mixed)
        out.sort(key=score, reverse=True)
    return out[:most]


def safe_name(name):
    return "".join(c if c.isalnum() else "_" for c in name)


def _font(px, bold=False):
    f = QFont("Segoe UI")
    f.setPixelSize(px)
    f.setWeight(QFont.DemiBold if bold else QFont.Normal)
    return f


def _diamond(c, r):
    return QPolygonF([QPointF(c.x(), c.y() - r), QPointF(c.x() + r, c.y()),
                      QPointF(c.x(), c.y() + r), QPointF(c.x() - r, c.y())])


def _crystal(c, w, h):
    """Kibelisk marker: a tall gem, same shape language as the overlay's diamonds."""
    return QPolygonF([QPointF(c.x(), c.y() - h), QPointF(c.x() + w, c.y() - h * 0.25),
                      QPointF(c.x() + w * 0.55, c.y() + h * 0.75), QPointF(c.x(), c.y() + h),
                      QPointF(c.x() - w * 0.55, c.y() + h * 0.75), QPointF(c.x() - w, c.y() - h * 0.25)])


def _glow(p, c, r, color, alpha):
    g = QRadialGradient(c, r)
    a = QColor(color)
    a.setAlpha(alpha)
    b = QColor(color)
    b.setAlpha(0)
    g.setColorAt(0, a)
    g.setColorAt(1, b)
    p.setPen(Qt.NoPen)
    p.setBrush(g)
    p.drawEllipse(c, r, r)


def _pill(p, anchor, text, font, accent=None, align="left", size=640):
    """Dark rounded label like the overlay's panels. anchor = left-middle (or centre-bottom)."""
    fm = QFontMetricsF(font)
    pad_x, h = 9, fm.height() + 8
    w = fm.horizontalAdvance(text) + pad_x * 2 + (8 if accent else 0)
    if align == "center":
        x, y = anchor.x() - w / 2, anchor.y() - h
    else:
        x, y = anchor.x(), anchor.y() - h / 2
    x = min(max(4, x), size - w - 4)
    y = min(max(4, y), size - h - 4)
    r = QRectF(x, y, w, h)
    path = QPainterPath()
    path.addRoundedRect(r, h / 2.6, h / 2.6)
    p.setPen(QPen(QColor(255, 255, 255, 40), 1.2))
    p.setBrush(QColor(9, 11, 17, 225))
    p.drawPath(path)
    tx = x + pad_x
    if accent:
        p.setPen(Qt.NoPen)
        p.setBrush(accent)
        p.drawPolygon(_diamond(QPointF(x + pad_x + 2, y + h / 2), 4))
        tx += 9
    p.setFont(font)
    p.setPen(QColor(255, 255, 255, 240))
    p.drawText(QPointF(tx, y + h / 2 + fm.ascent() / 2 - 1.5), text)


def _label(p, pos, text, color, font):
    p.setFont(font)
    p.setPen(QColor(0, 0, 0, 200))
    for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1), (1, 1)):
        p.drawText(QPointF(pos.x() + dx, pos.y() + dy), text)
    p.setPen(color)
    p.drawText(pos, text)


class MapStore:
    def __init__(self, app_dir, spawns_path, colours, log_error=print):
        self.dir = Path(app_dir) / "maps"
        self.index_path = self.dir / "index.json"
        self.spawns_path = Path(spawns_path)
        self.colours = colours
        self.log_error = log_error
        self.status = "idle"        # idle / building / ready / failed
        self.progress = ""
        self.index = {}
        try:
            d = json.loads(self.index_path.read_text(encoding="utf-8"))
            if d.get("version") == MAP_VERSION:
                self.index = d.get("pets", {})
                self.status = "ready"
        except (OSError, ValueError):
            pass

    def start(self):
        if self.status in ("ready", "building"):
            return
        self.status = "building"
        self.progress = "Downloading map data..."
        threading.Thread(target=self._build, daemon=True, name="map_builder build").start()

    def entry(self, name, world):
        e = self.index.get(name, {}).get(str(world))
        return e if isinstance(e, dict) else None

    def path_for(self, name, world):
        e = self.entry(name, world)
        return self.dir / e["png"] if e else None

    # ------------------------------------------------------------------ #
    def _build(self):
        try:
            self._build_inner()
        except Exception as e:      # keep the overlay running whatever happens
            self.status = "failed"
            self.progress = f"Map download failed: {e}"
            self.log_error("Map build failed:\n" + traceback.format_exc())

    def _build_inner(self):
        d = json.loads(self.spawns_path.read_text(encoding="utf-8"))
        mons, src, numbers = d["monsters"], d["map_source"], d.get("kib_numbers", {})
        need = {m for ids in mons.values() for m in ids}

        raw = json.loads(_get(src["api"]))
        worlds = {w["id"]: w for w in raw["worlds"]}
        pts, kibs = {}, {}
        try:
            from bosses import FIELD, BOSSES
            boss_names = {f["name"] for f in FIELD} | {b["name"] for b in BOSSES} | \
                {"Executor Argo", "Executor Kaira", "Executor Tamasa", "Executioner Dramos", "Ravager Marakha",
                 "Turncoat Ducal"}
        except Exception:
            boss_names = set()
        boss_found = {}                       # name -> {"ids": [...], "spots": {world: [(x, y)]}}
        for m in raw["markers"]:
            if m.get("category") == "teleport-artifact" and m.get("points"):
                try:
                    kid = int(str(m["id"]).split("-")[1])
                except (IndexError, ValueError):
                    continue
                x, y = m["points"][0][:2]
                kibs.setdefault(m["worldId"], []).append((kid, m["name"], x, y))
            elif m.get("type") == "monster" and m.get("db"):
                try:
                    mid = int(m["db"]["id"])
                except (KeyError, ValueError, TypeError):
                    continue
                if mid in need:
                    pts.setdefault(mid, []).extend((m["worldId"], q[0], q[1]) for q in m["points"])
                if m.get("name") in boss_names:
                    bf = boss_found.setdefault(m["name"], {"ids": [], "spots": {}})
                    if mid not in bf["ids"]:
                        bf["ids"].append(mid)
                    bf["spots"].setdefault(m["worldId"], []).extend((q[0], q[1]) for q in m["points"])
        from items import KIND
        gather = {}
        for m in raw["markers"]:
            if m.get("category") in ("herb", "metal", "jewelry", "od", "berry", "shellfish", "tree", "vegetable"):
                if m["name"] in KIND:                    # only materials on our list (Global ones)
                    gather.setdefault((m["name"], m["worldId"]), []).extend((q[0], q[1]) for q in m["points"])
        del raw

        jobs, live = {}, {}               # live: spawn points for the overlay on the game's own big map
        by_world = {}                     # every pet's spawn points per world (to see how mixed a spot is)
        for pid, name, g, areas in d["pets"]:
            for mid in mons.get(name, []):
                for ww, x, y in pts.get(mid, []):
                    by_world.setdefault(ww, {}).setdefault(name, []).append((x, y))
        for pid, name, g, areas in d["pets"]:
            if name not in mons or not areas:
                continue
            for w in sorted({a[1] for a in areas}):
                first = next(a for a in areas if a[1] == w)
                P = [(x, y) for mid in mons[name] for (ww, x, y) in pts.get(mid, []) if ww == w]
                if P:
                    live.setdefault(w, {}).setdefault("pets", {})[name] = {"g": g, "p": [[int(x), int(y)] for x, y in P],
                                                                           "c": []}
                others = [q for n2, qs in by_world.get(w, {}).items() if n2 != name for q in qs]
                for rank, near in enumerate(spots(P, others=others)):
                    wk = kibs.get(w, [])
                    mx, my = near[0]                        # a real spawn point, never an empty middle
                    kid = min(wk, key=lambda k: (k[2] - mx) ** 2 + (k[3] - my) ** 2)[0] if wk else first[2]
                    label = next((a[0] for a in areas if a[1] == w and a[2] == kid), "")
                    if rank < 4:                            # hover maps for the first four
                        key = name if rank == 0 else f"{name}#{rank + 1}"
                        jobs.setdefault(w, []).append((key, g, [label, w, kid, None, len(near)], near))
                    live[w]["pets"][name]["c"].append([int(mx), int(my), len(near)])

        # resource maps: the same spots as the big map (items.gather_groups), each with its closest Kibelisk
        from items import gather_groups
        for (rname, w), P in gather.items():
            live.setdefault(w, {}).setdefault("res", {})[rname] = [[int(x), int(y)] for x, y in P]
            wk = kibs.get(w, [])
            for rank, (mx, my, near) in enumerate(gather_groups(P)):
                kid = min(wk, key=lambda k: (k[2] - mx) ** 2 + (k[3] - my) ** 2)[0] if wk else None
                key = "res:" + rname + ("" if rank == 0 else f"#{rank + 1}")
                jobs.setdefault(w, []).append((key, "R", [rname, w, kid, None, len(near)], near))

        # boss spawn spots (hover a boss for its map), and the ids the game uses for them
        for bname, bf in boss_found.items():
            for w, P in bf["spots"].items():
                wk = kibs.get(w, [])
                mx = sum(x for x, y in P) / len(P)
                my = sum(y for x, y in P) / len(P)
                kid = min(wk, key=lambda k: (k[2] - mx) ** 2 + (k[3] - my) ** 2)[0] if wk else None
                jobs.setdefault(w, []).append(("boss:" + bname, "B", [bname, w, kid, None, len(P)], P))
        self.dir.mkdir(exist_ok=True)
        (self.dir / "bosses.json").write_text(json.dumps(
            {n: {"ids": bf["ids"], "worlds": list(bf["spots"])} for n, bf in boss_found.items()}), encoding="utf-8")
        index = {}
        for n, (w, items) in enumerate(jobs.items(), 1):
            wi = worlds.get(w)
            if not wi:
                continue
            self.progress = f"Preparing maps {n}/{len(jobs)} ({wi.get('name', w)})..."
            tmp = self.dir / f"_{w}.webp"
            tmp.write_bytes(_get(src["images"] + f"{w}.webp", 600))
            reader = QImageReader(str(tmp))
            full = reader.size()
            if MAX_DECODE and full.width() > MAX_DECODE:
                k = MAX_DECODE / full.width()
                reader.setScaledSize(QSize(int(full.width() * k), int(full.height() * k)))
            img = reader.read()
            if img.isNull():
                raise RuntimeError(f"could not read the {wi.get('name', w)} map ({reader.errorString()})")
            for job in items:
                name, g, a = job[:3]
                explicit = job[3] if len(job) > 3 else None
                e = self._render(img, wi, kibs.get(w, []), numbers, mons.get(name, []), pts, name, g, a, w, explicit)
                if e:
                    index.setdefault(name, {})[w] = e
            del img, reader                    # let go of the file, or Windows keeps it locked
            try:                               # kept for the overlay on the game's big map
                tmp.replace(self.dir / f"world_{w}.webp")
            except OSError:
                pass

        for w in live:
            wi = worlds.get(w)
            if wi:
                live[w]["bounds"] = [wi["gameMinX"], wi["gameMaxX"], wi["gameMinY"], wi["gameMaxY"]]
                live[w]["kibs"] = [[k[0], k[1], int(k[2]), int(k[3])] for k in kibs.get(w, [])]
        (self.dir / "live_points.json").write_text(json.dumps({k: v for k, v in live.items() if "bounds" in v}),
                                                   encoding="utf-8")
        self.index_path.write_text(json.dumps({"version": MAP_VERSION, "pets": index}), encoding="utf-8")
        self.index = index
        self.status = "ready"
        self.progress = ""

    def _render(self, img, wi, wkibs, numbers, mon_ids, pts, name, g, area, w, explicit=None):
        P = explicit if explicit is not None else \
            [(x, y) for mid in mon_ids for (ww, x, y) in pts.get(mid, []) if ww == w]
        if not P:
            return None
        W, H = img.width(), img.height()
        gx0, gx1, gy0, gy1 = wi["gameMinX"], wi["gameMaxX"], wi["gameMinY"], wi["gameMaxY"]

        def proj(x, y):
            return (x - gx0) / (gx1 - gx0) * W, (y - gy0) / (gy1 - gy0) * H

        main = area[2]

        def nearest(x, y):
            return min(wkibs, key=lambda k: (k[2] - x) ** 2 + (k[3] - y) ** 2)[0] if wkibs else None

        cluster = [p for p in P if main and nearest(*p) == main] or P
        mk = next((k for k in wkibs if k[0] == main), None)
        xs = [p[0] for p in cluster] + ([mk[2]] if mk else [])
        ys = [p[1] for p in cluster] + ([mk[3]] if mk else [])
        cx, cy = (min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2
        half = max(max(xs) - min(xs), max(ys) - min(ys)) / 2 * 1.2 + 2500
        half = max(half, 20000)                        # at least ~400 m across
        px, py = proj(cx, cy)
        pr = half / abs(gx1 - gx0) * W
        crop = QRectF(px - pr, py - pr, 2 * pr, 2 * pr)
        k = OUT / (2 * pr)

        def to(x, y):
            X, Y = proj(x, y)
            return QPointF((X - crop.x()) * k, (Y - crop.y()) * k)

        def inside(q, m=0):
            return -m <= q.x() <= OUT + m and -m <= q.y() <= OUT + m

        out = QImage(OUT, OUT, QImage.Format_ARGB32_Premultiplied)
        out.fill(QColor(12, 14, 20))
        p = QPainter(out)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        p.drawImage(QRectF(0, 0, OUT, OUT), img, crop)       # clean map, no dimming
        p.end()
        fn = f"{safe_name(name)}_{w}.png"
        out.save(str(self.dir / fn))
        # marker positions (0..OUT); the overlay draws them, so styles can change without a rebuild
        dots = [[round(q.x(), 1), round(q.y(), 1)] for q in (to(x, y) for x, y in P) if inside(q, 10)]
        marks = []
        for kid, kname, kx, ky in wkibs:
            q = to(kx, ky)
            if inside(q, 6):
                marks.append([round(q.x(), 1), round(q.y(), 1), numbers.get(str(kid)), kid == main])
        e = {"png": fn, "size": OUT, "genus": g, "dots": dots, "kibs": marks}
        if mk:                       # resource maps: closest Kibelisk to the main cluster
            mx = sum(p[0] for p in cluster) / len(cluster)
            my = sum(p[1] for p in cluster) / len(cluster)
            dist = ((mk[2] - mx) ** 2 + (mk[3] - my) ** 2) ** 0.5 / 100
            e["kib"] = [numbers.get(str(main)), mk[1], round(dist)]
            e["nodes"] = len(P)
            e["label"] = area[0] if isinstance(area[0], str) else ""
        return e



def fetch_boss_spots(spawns_path, out_path, log_error=print):
    """Where each boss stands (game coordinates), so the overlay can tell field bosses apart."""
    try:
        from bosses import FIELD, BOSSES
        names = {f["name"] for f in FIELD} | {b["name"] for b in BOSSES}
        d = json.loads(Path(spawns_path).read_text(encoding="utf-8"))
        raw = json.loads(_get(d["map_source"]["api"]))
        out = {}
        for m in raw["markers"]:
            if m.get("type") == "monster" and m.get("name") in names and m.get("points"):
                out.setdefault(m["name"], {}).setdefault(str(m["worldId"]), []).extend(
                    [round(q[0]), round(q[1])] for q in m["points"])
        Path(out_path).write_text(json.dumps(out), encoding="utf-8")
        kinds = {}                                       # what else the map data has (for gathering spots)
        for m in raw["markers"]:
            k = kinds.setdefault(str(m.get("type")), {"count": 0, "names": [], "keys": sorted(m.keys()),
                                                      "example": {a: (b if not isinstance(b, list) else b[:2])
                                                                  for a, b in m.items()}})
            k["count"] += 1
            if m.get("name") not in k["names"] and len(k["names"]) < 300:
                k["names"].append(m.get("name"))
        (Path(out_path).parent / "marker_kinds.json").write_text(json.dumps(kinds, indent=1), encoding="utf-8")
    except Exception as e:
        log_error(f"boss spots download failed: {e}")


def download_icons(spawns_path, out_dir, log_error=print):
    """Pet pictures from aion2pets.app, saved as icons/<petId>.png (64 px). One time."""
    try:
        out_dir = Path(out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        d = json.loads(Path(spawns_path).read_text(encoding="utf-8"))
        ids = {name: pid for pid, name, g, a in d["pets"]}
        pets = json.loads(_get("https://aion2pets.app/pets.json"))
        for p in pets:
            pid = ids.get(p.get("name"))
            img = p.get("image")
            if not pid or not img or (out_dir / f"{pid}.png").exists():
                continue
            try:
                data = _get("https://aion2pets.app" + img, 60)
                im = QImage.fromData(data)
                if not im.isNull():
                    im.scaled(64, 64, Qt.KeepAspectRatio, Qt.SmoothTransformation).save(str(out_dir / f"{pid}.png"))
            except Exception:
                continue
    except Exception:
        log_error("Icon download failed:\n" + traceback.format_exc())
