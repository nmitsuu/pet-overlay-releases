"""
World boss alerts (Global schedule, in the server's local time; region found automatically). Only bosses that drop Artwork.
Sources: aion2hub.com/tools/world-bosses, expcarry.com/aion-2-timers (schedules),
allthings.how (artwork drops). Edit BOSSES if the game changes the schedule.
"""
import math
from datetime import datetime, timedelta, timezone


from region import SERVER as SERVER_TZ   # the detected region's server clock
# weekday: 0 = Monday ... 6 = Sunday (server time)
BOSSES = [
    {"name": "Watcher Kaira", "map": "Lower Reshanta",
     "days": [0, 1, 2, 3, 4, 5, 6], "times": ["01:00", "04:00", "07:00", "10:00", "13:00", "16:00", "19:00", "22:00"]},
    {"name": "Executors Argo, Kaira & Tamasa", "short": "Executors Argo, Kaira, Tamasa", "last": True, "map": "Lower Reshanta",
     "days": [0, 3, 5], "times": ["21:30"]},
    {"name": "Guardian Lord Nahma", "map": "Lower Reshanta", "days": [4, 6], "times": ["21:00"]},
    # Middle Reshanta: listed for Global by expcarry.com, but aion2hub.com lists it as Korea/Taiwan only.
    # Alerts start muted; ring the bell to turn one on.
    {"name": "Enraged Guardian Lord Nahma", "map": "Middle Reshanta", "days": [4, 6], "times": ["21:00"],
     "unconfirmed": True},
    {"name": "Dramos, Marakha & Ducal", "map": "Middle Reshanta", "days": [0, 3, 5], "times": ["21:30"],
     "unconfirmed": True},
]
# Field bosses respawn a set time after they die (no fixed clock). Every one drops its own Artwork.
# Respawn times are the Korean service's (halved on 2025-12-17); NCsoft hasn't published Global ones.
# Source: thegameswiki.com/aion-2/wiki/field-bosses
_V = [("Kernon of the West", "Cantas Valley", 30), ("Neikel of the East", "Cantas Valley", 30),
      ("Rotten Kutar", "Ellun River Marsh", 30), ("Blooming Korin", "Ellun River Midstream", 60),
      ("Bodyguard Teegant", "Verteron Fortress Ruins", 90), ("Kusan the Mad", "Verteron Fortress Ruins", 120),
      ("Ritualist Garshim", "Verteron Fortress Ruins", 120), ("Bloodfang Pnyn", "Tolbas Forest", 180),
      ("Furious Saursus", "Tolbas Forest", 180), ("Scholar Aulla", "Aullaeu Village", 120),
      ("Chaser Taulo", "Aullaeu Village", 120), ("Forest Warrior Aullamu", "Aullaeu Village", 240),
      ("Heretic Layla", "Altamia Highland", 180), ("Black Tentacle Lawa", "Altamia Canyon", 240),
      ("Centurion Demiros", "Altamia Highland", 240), ("Divine Ansas", "Altamia Highland", 360),
      ("Harvest Manager Moshav", "Drana Plantation", 180), ("Sentinel K'nash", "Drana Plantation", 240),
      ("Researcher Setram", "Nahid Brigade Fortress", 360), ("Phantasm Kasia", "Garden of the Illusion God", 360),
      ("Silent Dartan", "Southern Altamia Highland", 360), ("Soul Ruler Kashapa", "Eastern Altamia Highland", 360),
      ("High Commander Lagta", "Scarlet Forest", 720), ("Eternal Gartua", "Eternal Isle", 720)]
_A = [("Melted Danar", "Dredgion Crash Site", 30), ("Black Warrior Aed", "Nameless Graveyard", 30),
      ("Faithful Rajit", "Sanctuary Watch Post", 30), ("Berserker Vargor", "Sanctuary Watch Post", 60),
      ("Blood Warrior Lannar", "Moslan Forest", 90), ("Predator Garsan", "Moslan Forest", 120),
      ("Deceiver Trid", "Urtumheim", 120), ("Blue Wave Kelpina", "Purifying Forest", 120),
      ("Advisor Resana", "Dranactus", 180), ("High Overseer Nutah", "Dranactus", 120),
      ("Special Operations Leader Linx", "Basfelt Ruins", 180), ("Desecrator Newbold", "Basfelt Ruins", 240),
      ("Specter Archon Axios", "Basfelt Ruins", 240), ("Addicted Hardirun", "Fafnite Deposit", 180),
      ("Executioner Barthien", "Griabade Gorge (west)", 240),
      ("Drakan Battalion Weapon Guruta", "Griabade Gorge (east)", 360),
      ("Veteran Shujakan", "Black Claw Village", 180), ("Visionary Karuka", "Black Claw Village", 240),
      ("Dark Shadow Vishwada", "Lagta Fortress", 360), ("Sharp Shylak", "Impetusium Square", 360),
      ("Silent Dartan", "Purifying Forest", 360), ("Soul Ruler Kashapa", "Fafnite Deposit", 360),
      ("High Commander Lagta", "Lagta Fortress", 720), ("Immortal Gartua", "Immortal Isle", 720)]
FIELD = [{"key": f"elyos:{n}", "name": n, "region": "elyos", "map": a, "every": m} for n, a, m in _V] + \
        [{"key": f"asmo:{n}", "name": n, "region": "asmo", "map": a, "every": m} for n, a, m in _A]
# the game's own ids for field bosses (from the map's Field Boss list); more are learned by position
FIELD_IDS = {101001: "elyos:Neikel of the East", 101002: "elyos:Rotten Kutar", 101003: "elyos:Kernon of the West",
             101007: "elyos:Blooming Korin", 101017: "elyos:Scholar Aulla", 101004: "elyos:Kusan the Mad", 101005: "elyos:Ritualist Garshim", 101006: "elyos:Bodyguard Teegant",
             101008: "elyos:Furious Saursus", 101009: "elyos:Bloodfang Pnyn", 101010: "elyos:Heretic Layla",
             101011: "elyos:Black Tentacle Lawa", 101012: "elyos:Phantasm Kasia", 101013: "elyos:Centurion Demiros",
             101014: "elyos:Divine Ansas", 101015: "elyos:Harvest Manager Moshav", 101016: "elyos:Sentinel K'nash",
             101018: "elyos:Forest Warrior Aullamu", 101019: "elyos:Chaser Taulo", 101020: "elyos:Researcher Setram",
             101021: "elyos:Eternal Gartua", 101022: "elyos:Silent Dartan", 101023: "elyos:Soul Ruler Kashapa",
             101024: "elyos:High Commander Lagta"}
WORLD_REGION = {1010: "elyos", 1011: "elyos", 1000: "elyos", 1110: "asmo", 1111: "asmo", 1100: "asmo"}
UP_WINDOW = 30

# Recurring events, in the server's local time (Asia = Seoul time, Europe = CET/CEST, NA = ET/PT).
# Rift: 02:00, 05:00 ... 23:00 server time (aion2-rift-timer.com, 6sword.com, daevaguides.com).
EVENTS = [
    {"key": "rift", "name": "Spacetime Rift", "every": 180, "at": 120, "window": 10, "lead": (2,), "sound": "rift",
     "sub": "Every 3 h"},
    {"key": "shugo", "name": "Shugo Festival", "every": 60, "at": 0, "window": 3, "lead": (), "after": 2,
     "sound": "shugo", "sub": "Every hour · 3 min to join"},
    {"key": "invasion", "name": "Dimensional Invasion", "every": 60, "at": 30, "window": 15, "lead": (2,),
     "sound": "space", "sub": "Every hour at :30"},
    {"key": "siege", "name": "Artifact Siege", "days": (0, 3, 5), "time": "21:00", "window": 30, "lead": (10, 2),
     "sound": "siege", "sub": "Abyss"},
]


# when each event can alert you (minutes from when it opens; negative = before). Chosen in the tray menu.
EVENT_OPTIONS = {
    "shugo": [(-2, "2 min before"), (0, "When it opens"), (1.5, "Halfway"), (2, "1 min left")],
    "rift": [(-10, "10 min before"), (-2, "2 min before"), (0, "When it opens"), (8, "2 min left")],
    "invasion": [(-10, "10 min before"), (-2, "2 min before"), (0, "When it opens"), (7.5, "Halfway"),
                 (13, "2 min left")],
    "siege": [(-30, "30 min before"), (-10, "10 min before"), (-2, "2 min before"), (0, "When it starts")],
}
EVENT_DEFAULTS = {"shugo": [2], "rift": [-2], "invasion": [-2], "siege": [-10, -2]}


def event_alerts(state, key):
    return state.get("event_alerts", {}).get(key, EVENT_DEFAULTS.get(key, []))


def next_event(e, now=None):
    """(start, is_open_now) for an event, start in UTC. Schedules run on the server's clock."""
    now = now or datetime.now(timezone.utc)
    loc = now.astimezone(SERVER_TZ).replace(tzinfo=None)
    off = loc - now.replace(tzinfo=None)
    to_utc = lambda t: (t - off).replace(tzinfo=timezone.utc)
    if "every" in e:
        day = loc.replace(hour=0, minute=0, second=0, microsecond=0)
        mins = (loc - day).total_seconds() / 60
        k = math.floor((mins - e["at"]) / e["every"])
        cur = to_utc(day + timedelta(minutes=e["at"] + k * e["every"]))
        if now < cur + timedelta(minutes=e["window"]):
            return cur, True
        return cur + timedelta(minutes=e["every"]), False
    h, m = map(int, e["time"].split(":"))
    for add in range(-1, 8):
        d = (loc + timedelta(days=add)).date()
        if d.weekday() in e["days"]:
            st = to_utc(datetime(d.year, d.month, d.day, h, m))
            if now < st + timedelta(minutes=e["window"]):
                return st, now >= st
    return None, False          # minutes a field boss is shown as "up" after its respawn time

LEADS = (10, 5, 2)


def next_reset(now=None, weekly=False):
    """Next daily (or Wednesday weekly) reset, in UTC: 16:00 on the server's clock (metabot.gg, allthings.how)."""
    now = now or datetime.now(timezone.utc)
    loc = now.astimezone(SERVER_TZ).replace(tzinfo=None)
    off = loc - now.replace(tzinfo=None)
    r = loc.replace(hour=16, minute=0, second=0, microsecond=0)
    while r <= loc or (weekly and r.weekday() != 2):
        r += timedelta(days=1)
    return (r - off).replace(tzinfo=timezone.utc)


def next_spawn(boss, now=None):
    now = (now or datetime.now(timezone.utc)).astimezone(SERVER_TZ)
    best = None
    for add in range(0, 8):
        day = (now + timedelta(days=add)).date()
        if day.weekday() not in boss["days"]:
            continue
        for t in boss["times"]:
            h, m = map(int, t.split(":"))
            dt = datetime(day.year, day.month, day.day, h, m, tzinfo=SERVER_TZ)
            if dt > now and (best is None or dt < best):
                best = dt
        if best:
            return best
    return best


class BossAlerts:
    """Fires notify(boss, lead_minutes, spawn_time) 10, 5 and 2 minutes before each spawn."""

    def __init__(self, state, notify):
        self.state = state
        self.notify = notify
        self.sent = set()
        self.started = datetime.now(timezone.utc)
        self.log = []                                  # last alerts, for overlay_status.txt

    def muted(self, name):
        default = next((bool(b.get("unconfirmed")) for b in BOSSES if b["name"] == name), False)
        if ":" in name and not name.startswith("event:"):
            # field bosses: your own side's are on by default, the other side's (seen when you go through
            # a rift) are off unless you turn them on
            default = name.split(":", 1)[0] != self.state.get("faction", "elyos")
        return bool(self.state.get("boss_mute", {}).get(name, default))

    def toggle_mute(self, name):
        m = self.state.setdefault("boss_mute", {})
        m[name] = not self.muted(name)

    def tick(self):
        if not self.state.get("show", {}).get("bosses", True):
            return
        now = datetime.now(timezone.utc)
        for b in BOSSES:
            sp = next_spawn(b, now)
            if not sp or self.muted(b["name"]):
                continue
            mins = (sp - now).total_seconds() / 60
            for lead in LEADS:
                key = (b["name"], sp.isoformat(), lead)
                # a 90 s window so a busy or briefly hidden overlay never misses it,
                # and only the closest lead fires (no stacked alerts after a restart)
                if lead - 1.5 < mins <= lead and key not in self.sent:
                    for other in LEADS:
                        self.sent.add((b["name"], sp.isoformat(), other)) if other >= lead else None
                    self.log = (self.log + [f"{now:%H:%M:%S} {b['name']} {lead}m"])[-5:]
                    self.notify(b, lead, sp)
                    break
        for f in FIELD:
            sp = self.field_spawn(f)
            if not sp or self.muted(f["key"]):
                continue
            mins = (sp - now).total_seconds() / 60
            for lead in LEADS:
                key = (f["key"], sp.isoformat(), lead)
                if lead - 1.5 < mins <= lead and key not in self.sent:
                    for other in LEADS:
                        if other >= lead:
                            self.sent.add((f["key"], sp.isoformat(), other))
                    self.log = (self.log + [f"{now:%H:%M:%S} {f['name']} {lead}m"])[-5:]
                    self.notify(f, lead, sp)
                    break
        for e in EVENTS:
            if self.muted("event:" + e["key"]):
                continue
            st, open_now = next_event(e, now)
            if not st:
                continue
            since = (now - st).total_seconds() / 60          # minutes since it opened (negative: before)
            for off in event_alerts(self.state, e["key"]):
                key = (e["key"], st.isoformat(), off)
                if off <= since < off + 0.5 and key not in self.sent:
                    self.sent.add(key)
                    self.log = (self.log + [f"{now:%H:%M:%S} {e['name']} {off:+g}m"])[-5:]
                    # lead > 0: starts in N min · 0: open now · < 0: N min left to join
                    self.notify(e, -off if off < 0 else (0 if off == 0 else -(e["window"] - off)), st)
                    break
        if len(self.sent) > 500:
            self.sent.clear()

    # field bosses: read from the game's Field Boss list (data.field: key -> (alive, time, seen))
    def field_state(self, f):
        d = getattr(self, "data", None)
        return d.field.get(f["key"]) if d is not None and hasattr(d, "field") else None

    def field_spawn(self, f):
        st = self.field_state(f)
        if not st or st[0]:
            return None
        sp = datetime.fromtimestamp(st[1] / 1000, timezone.utc)
        return sp if datetime.now(timezone.utc) < sp + timedelta(minutes=UP_WINDOW) else None

    def upcoming(self):
        now = datetime.now(timezone.utc)
        out = [(next_spawn(b, now), b) for b in BOSSES] + [(self.field_spawn(f), f) for f in FIELD]
        return sorted([(s, b) for s, b in out if s and s > now], key=lambda x: x[0])
