"""Creates a 'Pet Overlay' shortcut (with icon) on your Desktop and in the Start menu.
Right-click the Desktop one > Show more options > Pin to taskbar."""
import os, subprocess, sys
from pathlib import Path

here = Path(__file__).resolve().parent
pyw = Path(sys.executable).with_name("pythonw.exe")
if not pyw.exists():          # some Python installs have no pythonw; the overlay hides its own console
    pyw = Path(sys.executable)
q = lambda p: "'" + str(p).replace("'", "''") + "'"
places = [Path(os.environ["USERPROFILE"]) / "Desktop",
          Path(os.environ["APPDATA"]) / "Microsoft" / "Windows" / "Start Menu" / "Programs"]
for folder in places:
    lnk = folder / "Pet Overlay.lnk"
    cmd = (f"$s=(New-Object -ComObject WScript.Shell).CreateShortcut({q(lnk)});"
           f"$s.TargetPath={q(pyw)};$s.Arguments={q(chr(34) + str(here / 'pet_overlay.py') + chr(34))};"
           f"$s.WorkingDirectory={q(here)};$s.IconLocation={q(here / 'pet_overlay.ico')};"
           f"$s.Description='Pet Overlay for Aion 2';$s.Save()")
    r = subprocess.run(["powershell", "-NoProfile", "-Command", cmd], capture_output=True, text=True)
    print(("Made " if r.returncode == 0 else "Could not make ") + str(lnk), r.stderr.strip())
