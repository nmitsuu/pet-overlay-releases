"""Names and real in-game icons for items, looked up once from aion2hub.com and cached in maps/."""
import html as _html
import json
import re
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/124.0 Safari/537.36"}
GATHER = [  # node name, kind (from the game's map data)
    ("Odyle", "Odyle"), ("Orichalcum Ore", "Ore"), ("Ruby Gemstone", "Gem"), ("Diamond Gemstone", "Gem"),
    ("Sapphire Gemstone", "Gem"), ("Aria", "Herb"), ("Targena", "Herb"), ("Azpha", "Herb"), ("Calendula", "Herb"),
    ("Yggdrasil Log", "Log"), ("Asvata Log", "Log"), ("Mela", "Food"), ("Raydam", "Food"), ("Kukuru", "Food"),
    ("Coriolus", "Food"), ("Morfa", "Food"), ("Ohkra", "Food"), ("Cypri", "Food"), ("Inina", "Food"),
    ("Conide", "Food"), ("Pujery", "Food"),
]
# grade prefix -> (order, colour). Normal has no prefix.
GRADES = {"": (0, "#D7DCE6"), "Fine": (1, "#5FD38A"), "Fresh": (1, "#5FD38A"), "Pure": (2, "#5AA9FF"),
          "Radiant": (3, "#F2C94C")}
# which crafting system each kind of material feeds (colour used for its map dots and label)
CRAFT = {"Odyle": ("Crafting & Morph", "#6FE0E8"), "Ore": ("Smithing", "#7FA7E8"), "Gem": ("Handicrafting", "#C08CF2"),
         "Log": ("Handicrafting", "#C08CF2"), "Herb": ("Alchemy", "#5FD38A"), "Food": ("Cooking", "#F2A65A")}
KIND = dict(GATHER)


# every gathered material and its grades (ids follow 6106 <family> 00 <number>)
ALL_MATERIAL_IDS = ([610610000 + n for n in range(10, 21)] + [610620000 + n for n in range(10, 21)] +
                    [610650000 + n for n in range(10, 21)] + [610660000 + n for n in range(20, 41)] +
                    [610670000 + n for n in range(40, 61)] + [610680000 + n for n in range(40, 56)])


# reward keys, by item id (they're not named in the public item database)
KEY_IDS = {"shugo": {503700081, 503700035, 532000018, 532000021, 562000005, 562000024, 562000041, 562000058,
                     562000075, 562000099, 562000125, 562000146, 562000182},
           "invasion": {201514496}}


def is_material(item, name):
    if 610_600_000 <= item < 610_700_000:
        return True
    return bool(name) and base_name(name)[0] in KIND


def is_shugo_key(name):
    n = (name or "").lower()
    return "key" in n and ("shugo" in n or "reward key" in n or "festival" in n)


def craft_of(base):
    return CRAFT.get(KIND.get(base, "Food"), CRAFT["Food"])
OTHER_GRADE = (4, "#C08CF2")
PREFIXES = ("Fine ", "Fresh ", "Pure ", "Radiant ", "Superior ", "Refined ", "Flawless ", "Rare ", "High-Quality ")
SOUL_RE = re.compile(r"^Soul:\s*(.+?)(?:\s*\([^)]*\))?\s*$")


_BOUND = re.compile(r"\s*[\(\[](?:Account |Character )?Bound[\)\]]\s*$", re.I)


def base_name(name):
    name = _BOUND.sub("", name or "")
    for p in PREFIXES:
        if name.startswith(p):
            return name[len(p):], p.strip()
    return name, ""


def grade_info(grade):
    return GRADES.get(grade, OTHER_GRADE)


def soul_pet_name(item_name):
    m = SOUL_RE.match(item_name or "")
    return m.group(1).strip() if m else None


class ItemInfo:
    RETRY = 600

    def __init__(self, folder):
        self.dir = Path(folder)
        self.icon_dir = self.dir / "items"
        self.path = self.dir / "items.json"
        try:
            self.names = {int(k): v for k, v in json.loads(self.path.read_text(encoding="utf-8")).items()
                          if not str(v).startswith("Item ")}
        except (OSError, ValueError):
            self.names = {}
        self.queue, self.busy, self.failed = [], False, {}
        try:
            self.grades = {int(k): v for k, v in json.loads((self.dir / "grades.json").read_text(encoding="utf-8")).items()}
        except (OSError, ValueError):
            self.grades = {}
        self.lock = threading.Lock()

    def _want(self, item):
        if time.monotonic() - self.failed.get(item, -1e9) < self.RETRY:
            return
        with self.lock:
            if item not in self.queue:
                self.queue.append(item)
        if not self.busy:
            self.busy = True
            threading.Thread(target=self._work, daemon=True, name="items work").start()

    def name(self, item):
        n = self.names.get(item)
        if n == "":                      # not a real item (checked once)
            return None
        if n is None or not self._has_icon(item):
            self._want(item)
        return n

    def _has_icon(self, item):
        """Whether the item's picture is on disk, checked at most every 30 s per item (checking the disk on
        every call made the gathering list slow down the whole overlay)."""
        have = self.__dict__.setdefault("_icons_have", set())
        if item in have:
            return True
        seen = self.__dict__.setdefault("_icons_checked", {})
        t = time.monotonic()
        if t - seen.get(item, -1e9) < 30:
            return False
        seen[item] = t
        if (self.icon_dir / f"{item}.png").exists():
            have.add(item)
            return True
        return False

    # Artwork pictures for bosses (the game's own artwork icons)
    ART_ALIAS = {"Executors Argo, Kaira & Tamasa": "Argo, the Spirit King", "Dramos, Marakha & Ducal": "Draupnir",
                 "Enraged Guardian Lord Nahma": "Guardian Lord Nahma", "Kusan the Mad": "Kusan the Mad Gladiator"}
    SHUGO_KEY = 562000005

    def find_artworks(self):
        def work():
            ids = set()
            for page in range(1, 6):
                try:
                    html = self._get(f"https://aion2hub.com/database?q=Artwork&page={page}").decode("utf-8", "replace")
                except Exception:
                    break
                found = set(int(x) for x in re.findall(r"/database/items/(51\d{7})", html))
                if not found - ids:
                    break
                ids |= found
            self.prefetch(sorted(ids))
        if not any(str(v).startswith("Artwork:") for v in self.names.values()) or not self.art_scanned():
            threading.Thread(target=work, daemon=True, name="items work").start()
        self.prefetch([self.SHUGO_KEY])

    def art_scanned(self):
        return sum(1 for v in self.names.values() if str(v).startswith("Artwork:")) > 100

    def artwork(self, boss):
        want = "Artwork: " + self.ART_ALIAS.get(boss, boss)
        if not hasattr(self, "_art") or len(self._art_src) != len(self.names):
            self._art = {}
            for k, v in self.names.items():
                if v and v.startswith("Artwork:"):
                    self._art.setdefault(_BOUND.sub("", v).strip(), k)
            self._art_src = dict(self.names)
        return self._art.get(want)

    def grade(self, item):
        return self.grades.get(item, "")

    def prefetch(self, items):
        for i in items:
            if i not in self.names or (self.names[i] and not (self.icon_dir / f"{i}.png").exists()):
                self._want(i)

    def icon_path(self, item):
        f = self.icon_dir / f"{item}.png"
        return f if f.exists() else None

    @staticmethod
    def _get(url):
        return urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=30).read()

    def _work(self):
        try:
            self.icon_dir.mkdir(parents=True, exist_ok=True)
            while True:
                with self.lock:
                    if not self.queue:
                        break
                    item = self.queue.pop(0)
                try:
                    page = self._get(f"https://aion2hub.com/database/items/{item}").decode("utf-8", "replace")
                    t = page.split("<title>", 1)[1].split("</title>", 1)[0]
                    self.names[item] = _html.unescape(t).split(" — ")[0].split(" | ")[0].strip()
                    g = re.search(r'name="description"[^>]*content="[^"]*?\b(Common|Rare|Heroic|Epic|Legendary|Unique|Mythic|Special)\b', page)
                    if g:
                        self.grades[item] = g.group(1)
                    icon = self.icon_dir / f"{item}.png"
                    if not icon.exists():
                        m = re.search(r'property="og:image"\s+content="([^"]+)"', page) or \
                            re.search(r'content="([^"]+)"\s+property="og:image"', page)
                        urls = ([_html.unescape(m.group(1))] if m else []) + [f"https://aion2hub.com/api/icon/items/{item}"]
                        for u in urls:
                            try:
                                data = self._get(u)
                                if data[:4] == b"\x89PNG" or data[:3] == b"\xff\xd8\xff" or data[:4] == b"RIFF":
                                    tmp = icon.with_suffix(".part")
                                    tmp.write_bytes(data)
                                    tmp.replace(icon)          # appears complete, never half-written
                                    break
                            except Exception:
                                continue
                        if not icon.exists():
                            self.failed[item] = time.monotonic()
                    self.path.write_text(json.dumps({str(k): v for k, v in self.names.items()}), encoding="utf-8")
                    (self.dir / "grades.json").write_text(json.dumps({str(k): v for k, v in self.grades.items()}),
                                                         encoding="utf-8")
                except urllib.error.HTTPError as e:
                    if e.code == 404:
                        self.names[item] = ""            # no such item: never ask again
                        self.path.write_text(json.dumps({str(k): v for k, v in self.names.items()}), encoding="utf-8")
                    else:
                        self.failed[item] = time.monotonic()
                except Exception:
                    self.failed[item] = time.monotonic()
                time.sleep(0.3)
        finally:
            self.busy = False
