"""
Tells when a full-screen game window (map, storage, enhancement, attendance...) is open by looking
at the game's own HP / MP bars at the bottom of the screen: bright = normal play, dimmed or gone =
a full-screen window or popup is covering the game. Read-only: it only looks at a few pixels.
"""
import ctypes
import math
import threading
import time

import grab


class _RECT(ctypes.Structure):
    _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long), ("right", ctypes.c_long), ("bottom", ctypes.c_long)]


def client_rect(hwnd):
    """Game window's client area in screen pixels (x, y, w, h), or None."""
    try:
        u = ctypes.windll.user32
        r = _RECT()
        if not u.GetClientRect(hwnd, ctypes.byref(r)):
            return None
        pt = (ctypes.c_long * 2)(0, 0)
        u.ClientToScreen(hwnd, pt)
        return pt[0], pt[1], r.right, r.bottom
    except Exception:
        return None


def _hsv(c):
    r, g, b = c.red() / 255, c.green() / 255, c.blue() / 255
    mx, mn = max(r, g, b), min(r, g, b)
    return mx, (mx - mn) / mx if mx else 0


def _v(img, x, y):
    x, y = int(x), int(y)
    if not (0 <= x < img.width() and 0 <= y < img.height()):
        return 0
    return max(img.rgb(x, y))


def _vmax(img, x, y):
    return max(_v(img, x + a, y + b) for a in (-1, 0, 1) for b in (-1, 0, 1))


def chat_open(img, ox, oy, s):
    """The chat window's header: its X close button with the settings gear next to it (other side
    windows, like Friends, have the X but no gear). img is a grab whose (0, 0) is screen (ox, oy)."""
    cx, cy = 383.5 * s - ox, 40.5 * s - oy
    diag = [_vmax(img, cx + sx * d * s, cy + sy * d * s) for d in (4, 6, 8, 10) for sx in (-1, 1) for sy in (-1, 1)]
    off = [_v(img, cx + a * s, cy + b * s) for a, b in ((0, -9), (0, 9), (-9, 0), (9, 0), (-5, -11), (5, 11))]
    if sum(d > 170 for d in diag) < 13 or max(off) > 160:
        return False
    gx, gy = 327.5 * s - ox, 40.5 * s - oy
    gap = [_v(img, gx + 4.8 * s * math.cos(a), gy + 4.8 * s * math.sin(a)) for a in [k * math.pi / 4 for k in range(8)]]
    ring = [_vmax(img, gx + 8.5 * s * math.cos(a), gy + 8.5 * s * math.sin(a)) for a in [k * math.pi / 4 + 0.2 for k in range(8)]]
    return _vmax(img, gx, gy) > 170 and max(gap) < 130 and sum(r > 170 for r in ring) >= 5


def _exclusive_fullscreen():
    """True while a game owns the screen exclusively (then screen pictures come back black)."""
    try:
        st = ctypes.c_int(0)
        ctypes.windll.shell32.SHQueryUserNotificationState(ctypes.byref(st))
        return st.value == 3
    except Exception:
        return False


def party_frame(img, ox, oy, s):
    """The party list at the top left (in a party / full party / force): your own row's HP / MP bars have a
    dark red line above the HP and a dark teal line under it, there even when the bars are low. Solo, that
    spot is just the game. img is a grab whose (0, 0) is screen (ox, oy). Worked out from her screenshots."""
    def at(x, y):
        x, y = int(x - ox), int(y - oy)
        if not (0 <= x < img.width() and 0 <= y < img.height()):
            return (0, 0, 0)
        v = img.rgb(x, y)
        return v[0], v[1], v[2]
    hits = 0
    xs = [62 + 10 * i for i in range(13)]
    for x in xs:
        red = any(0x30 <= r <= 0x58 and g <= 0x12 and b <= 0x1a for r, g, b in
                  (at(x * s, (168 + d) * s) for d in (-1, 0, 1)))
        teal = any(r <= 0x1c and 0x12 <= g <= 0x38 and 0x24 <= b <= 0x4a for r, g, b in
                   (at(x * s, (174 + d) * s) for d in (-1, 0, 1)))
        hits += red and teal
    return hits >= 10


def limits_panel(img, ox, oy, s, skip=()):
    """The daily limits window (Kina / Abyss Points / Gathering) at the top left: a dark panel with pure
    bright cyan titles. Any one title is enough, so our own dock drawn over part of it doesn't hide it;
    spots under our own windows (skip: client rects) aren't looked at. img is a grab whose (0, 0) is client
    (ox, oy). From her screenshot (13 Nov), 0 cyan pixels there on all her other screenshots."""
    def free(x, y):
        return not any(rx <= x <= rx + rw and ry <= y <= ry + rh for rx, ry, rw, rh in skip)

    def at(x, y):
        x, y = int(x - ox), int(y - oy)
        if not (0 <= x < img.width() and 0 <= y < img.height()):
            return None
        return img.rgb(x, y)
    titles = 0
    for x0, x1, y0, y1, need in ((70, 100, 52, 62, 40), (68, 166, 193, 208, 120), (68, 146, 280, 296, 120)):
        n = 0
        for y in range(y0, y1):
            for x in range(x0, x1, 2):
                c = at(x * s, y * s) if free(x * s, y * s) else None
                if c is not None and c[0] < 40 and c[1] > 200 and c[2] > 200:
                    n += 2
        titles += n >= need
    dark = seen = 0
    for y in (45, 72, 170, 260):
        for x in range(120, 381, 20):
            if not free(x * s, y * s):
                continue
            c = at(x * s, y * s)
            if c is None:
                continue
            seen += 1
            dark += 15 < min(c) and max(c) < 80 and c[2] >= c[0]
    return titles >= 1 and seen >= 8 and dark >= 0.7 * seen


WIN_BLOCKS = 32          # flat panel blocks in one piece = a game window (her screenshots: windows 85+, the world 18 at most)


def window_blocks(a, s, keep=None):
    """Largest piece of game window under our overlay, in blocks of 14 px (at 1080p): game windows are one
    flat blue-grey fill, the world never is (grass, water, rock, sky all have texture). a: BGR(A) array.
    keep(bx, by) -> False for blocks outside our windows. Worked out from her screenshots (13 Nov)."""
    import numpy as np
    import cv2
    B = max(8, int(round(14 * s)))
    h, w = a.shape[0] // B * B, a.shape[1] // B * B
    if h < B or w < B:
        return 0
    c = a[:h, :w, :3].astype(np.float32).reshape(h // B, B, w // B, B, 3).transpose(0, 2, 1, 3, 4) \
        .reshape(h // B, w // B, B * B, 3)
    sd = c.mean(axis=3).std(axis=2)
    m = c.mean(axis=2)
    b, g, r = m[..., 0], m[..., 1], m[..., 2]
    mx, mn = m.max(axis=2), m.min(axis=2)
    ok = (sd < 2.2) & (mx > 12) & (mx < 85) & (mx - mn < 25) & (b >= r) & (b >= g - 3)
    if keep is not None:
        ok &= keep(B, ok.shape)
    if ok.sum() < 3:
        return 0
    n, _, st, _ = cv2.connectedComponentsWithStats(ok.astype(np.uint8), connectivity=4)
    return int(st[1:, cv2.CC_STAT_AREA].max()) if n > 1 else 0


WIN_LINES = 4           # straight 1 px row lines across 160 px+ = a game window's list (friends 7, limits 6, the world 2 at most)


def window_lines(a, s):
    """How many separate thin straight lines run across most of a 160 px stretch: the row lines of a game
    window (friend list, see-through ones too). The world never draws more than 2 in a dock-sized spot,
    not even a castle wall. a: BGR(A) array. From her screenshots (13 Nov)."""
    import numpy as np
    L = a[:, :, :3].astype(np.float32).mean(axis=2)
    span = int(160 * s)
    h, w = L.shape
    if h < 6 or w < span or span < 20:
        return 0
    d = L[2:-2] - 0.5 * (L[:-4] + L[4:])
    best = None
    for sign in (1, -1):
        c = np.cumsum(np.pad((sign * d > 5.0).astype(np.float32), ((0, 0), (1, 0))), axis=1)
        r = ((c[:, span:] - c[:, :-span]) / span).max(axis=1)
        best = r if best is None else np.maximum(best, r)
    n, last = 0, -99
    for y in np.nonzero(best >= 0.9)[0].tolist():
        n += y - last > 3
        last = y
    return n


class HudWatcher:
    """covered() -> True while a full-screen window / popup is over the game. The screen is read on a
    helper thread; update() (drawing thread) only takes the newest reading, so it never waits."""

    def __init__(self):
        self.state = "play"          # "play" or "covered"
        self.votes = 0
        self.last = ""
        self.scale = 1.0
        self.solid = (1.0, 1.0)
        self._hwnd, self._asked = None, 0.0
        self.party, self._party_raw, self._party_votes = False, False, 0
        self.limits, self._limits_raw = False, False
        self.window, self._win_raw, self._win_votes, self._win_n, self._win_pic = False, False, 0, 0, None
        self._win_l = 0
        self._result, self._seen, self._thread = None, None, None

    def _sample(self, rect):
        x0, y0, w, h = rect
        s = min(w / 1920, h / 1080)
        cx = x0 + w / 2
        y = y0 + h - int(117 * s)                     # the HP / MP bars sit ~117 px above the bottom
        sx, width = int(cx - 250 * s), int(500 * s)
        span = int(30 * s)                               # a band, not one line: screens and UI layouts
        pic = grab.screen(sx, int(y - span), width, 2 * span)                                 # differ a bit
        if pic is None or pic.width() < 50:
            return None
        if not getattr(self, "_saved", False) and getattr(self, "debug_dir", None):
            self._saved = True                           # one picture per run, to check the layout
            try:
                import cv2
                cv2.imwrite(str(self.debug_dir / "hud_band.png"), pic.a)
            except Exception:
                pass
        import numpy as np                               # whole band at once
        px = pic.a.astype(np.int16)
        b_, g_, r_ = px[..., 0], px[..., 1], px[..., 2]
        w_ = px.shape[1]
        mx = np.maximum(np.maximum(r_, g_), b_)
        if int(mx.max()) < 14:
            return "black"                               # Windows gave us a black picture (see _judge)
        mn = np.minimum(np.minimum(r_, g_), b_)
        strong = (mx > 115) & ((mx - mn) > 0.45 * np.maximum(mx, 1))
        red = strong & (r_ * 10 > g_ * 18) & (r_ * 10 > b_ * 18)
        cyan = strong & (b_ * 10 > r_ * 16) & (g_ * 10 > r_ * 14)
        mid = w_ // 2
        gap = int(50 * s)
        left, right = slice(0, max(1, mid - gap)), slice(min(w_ - 1, mid + gap), w_)
        nl, nr = max(1, left.stop - left.start), max(1, right.stop - right.start)
        hp = red[:, left].sum(1) / nl
        mp = cyan[:, right].sum(1) / nr
        wrong = (cyan[:, left].sum(1) + red[:, right].sum(1)) / (nl + nr)
        k = int(np.argmax(hp + mp - 4 * wrong))

        def solid(row):                                  # share of the coloured pixels in the longest run
            n = int(row.sum())
            if n == 0:
                return 0.0
            best = cur = 0
            for v in row.tolist():
                cur = cur + 1 if v else 0
                best = max(best, cur)
            return best / n
        self.solid = (solid(red[k, left]), solid(cyan[k, right]))   # real bars are one unbroken stripe
        return float(hp[k]), float(mp[k]), float(wrong[k])

    def check_places(self, rect, areas=()):
        """In a party? The daily limits window open? Both sit under our own dock, and the screen copy DOES
        include our windows, so the caller hides them from screen copies for a frame first (drawing thread,
        a few ms). Sets party (2 readings in a row) and limits (at once)."""
        if not rect or self.state != "play":
            self._party_raw = self._limits_raw = self._win_raw = False
        else:
            x0, y0, w, h = rect
            s = min(w / 1920, h / 1080)
            px_, py_ = int(x0 + 50 * s), int(y0 + 160 * s)
            pp = grab.screen(px_, py_, int(150 * s), int(22 * s))
            self._party_raw = pp is not None and party_frame(pp, px_ - x0, py_ - y0, s)
            lx_, ly_ = int(x0 + 50 * s), int(y0 + 40 * s)
            lp = grab.screen(lx_, ly_, int(350 * s), int(262 * s))
            self._limits_raw = lp is not None and limits_panel(lp, lx_ - x0, ly_ - y0, s)
            self._win_raw = self._check_window(rect, areas, s)
            self._save_checks(pp, lp, x0, y0, w, h)
        self.limits = bool(self._limits_raw)
        if self._win_raw:                               # any game window under our overlay: at once
            self.window, self._win_votes = True, 0
        elif self.window:                               # gone: two readings in a row (1 s)
            self._win_votes += 1
            if self._win_votes >= 2:
                self.window, self._win_votes = False, 0
        if self._party_raw != self.party:
            self._party_votes += 1
            if self._party_votes >= 2:
                self.party, self._party_votes = self._party_raw, 0
        else:
            self._party_votes = 0
        return self.party, self.limits

    def _check_window(self, rect, areas, s):
        """Any game window (friend list, daily limits, anything) under our dock / panels? areas: screen rects
        of our windows. Read from one copy of their bounding box, only blocks inside them count."""
        x0, y0, w, h = rect
        if areas:                                       # the dock: also the spot below it (windows are tall)
            ax, ay, aw, ah = areas[0]
            areas = [(ax, ay, aw, max(ah, int(560 * s))), *areas[1:]]
        rs = [(max(ax, x0), max(ay, y0), min(ax + aw, x0 + w), min(ay + ah, y0 + h)) for ax, ay, aw, ah in areas]
        rs = [r for r in rs if r[2] - r[0] > 20 and r[3] - r[1] > 20]
        if not rs:
            self._win_n, self._win_l, self._win_pic = 0, 0, None
            return False
        bx0, by0 = min(r[0] for r in rs), min(r[1] for r in rs)
        bx1, by1 = max(r[2] for r in rs), max(r[3] for r in rs)
        pic = grab.screen(bx0, by0, bx1 - bx0, by1 - by0)
        if pic is None or pic.isNull():
            return False

        def keep(B, shape):
            import numpy as np
            k = np.zeros(shape, bool)
            for l, t_, r_, b_ in rs:
                k[max(0, (t_ - by0) // B):max(0, (b_ - by0) // B), max(0, (l - bx0) // B):max(0, (r_ - bx0) // B)] = True
            return k
        self._win_n = window_blocks(pic.a, s, keep)
        self._win_l = max(window_lines(pic.a[t_ - by0:b_ - by0, l - bx0:r_ - bx0], s) for l, t_, r_, b_ in rs)
        self._win_pic = pic
        return self._win_n >= WIN_BLOCKS or self._win_l >= WIN_LINES

    def _save_checks(self, pp, lp, x0, y0, w, h):
        """Every 5 s: what the party / limits checks actually see (samples/check_party.png, check_limits.png),
        so a miss can be looked at on her PC."""
        t = time.monotonic()
        d = getattr(self, "debug_dir", None)
        if d is None or t - getattr(self, "_saved_chk", 0) < 5:
            return
        self._saved_chk = t
        try:
            import cv2
            if pp is not None:
                cv2.imwrite(str(d / "check_party.png"), pp.a)
            if lp is not None:
                cv2.imwrite(str(d / "check_limits.png"), lp.a)
            if self._win_pic is not None:
                cv2.imwrite(str(d / "check_window.png"), self._win_pic.a)
            (d / "check_info.txt").write_text(f"client {x0},{y0} {w}x{h}  party {self._party_raw}  "
                                             f"limits {self._limits_raw}  window {self._win_n}/{WIN_BLOCKS} {self._win_l}/{WIN_LINES}\n", encoding="utf-8")
        except Exception:
            pass

    def _judge(self, rect):
        """Helper thread: one reading -> ("play" | "covered" | "keep" | "black", text)."""
        r = self._sample(rect)
        if r is None:
            return None
        if r == "black" and not _exclusive_fullscreen():
            # a black band with the game in front: a window with a black backdrop (stigma, etc.)
            r = (0.0, 0.0, 0.0)
        if r == "black":
            # In full-screen mode Windows sometimes hands screen readers a black picture while nothing
            # of ours is drawn over the game. Treating that as "a window is open" hid the overlay, which
            # kept the picture black: it only came back after clicking around. Unknown = keep showing.
            return "black", "screen picture black (full-screen game): assuming play"
        hp, mp, wrong = r
        # HP red on the left and MP cyan on the right. Both a little, or one clearly: a stray red or cyan
        # icon in a game window (the map has plenty) mustn't count as the bars.
        sl, sr = self.solid
        bars = (hp > 0.05 and sl > 0.85) + (mp > 0.05 and sr > 0.85)     # unbroken red / cyan stripes
        play = wrong < 0.02 and (bars == 2 or (bars == 1 and max(hp, mp) > 0.6))
        chat = False
        if play:
            x0, y0, w, h = rect
            s = min(w / 1920, h / 1080)
            bx, by = int(x0 + 300 * s), int(y0 + 22 * s)
            pic = grab.screen(bx, by, int(105 * s), int(38 * s))
            chat = pic is not None and chat_open(pic, bx - x0, by - y0, s)
            play = not chat

        return ("play" if play else "covered"), \
            f"hp {hp:.2f} mp {mp:.2f} other {wrong:.2f} solid {sl:.2f}/{sr:.2f}{'  chat open' if chat else ''}" \
            f"{'  party' if self.party else ''}{'  limits window' if self.limits else ''}"

    def _loop(self):
        n = 0
        while True:
            hwnd = self._hwnd
            if not hwnd or time.monotonic() - self._asked > 0.5:
                time.sleep(0.05)
                continue
            try:
                rect = client_rect(hwnd)
                res = self._judge(rect) if rect and rect[2] >= 400 else None
            except Exception as e:
                res = None
                self.last = f"window check error: {e}"
            if res is not None:
                n += 1
                self._result = (n,) + res
            time.sleep(0.025)                            # ~30 readings a second

    def update(self, hwnd):
        """Every main-loop step while the game is in front. Returns True when covered."""
        self._hwnd, self._asked = hwnd, time.monotonic()
        if self._thread is None:
            self._thread = threading.Thread(target=self._loop, daemon=True, name="window check")
            self._thread.start()
        res = self._result
        if res is None or res[0] == self._seen:
            return self.state == "covered"

        self._seen = res[0]
        want, self.last = res[1], res[2]
        if want == "black":
            self.state, self.votes = "play", 0
            return False
        if want != self.state:
            self.votes += 1
            # fold after 2 readings (~0.06 s); unfold only once play is steady for 3, so the
            # game's own window fade-out doesn't make the overlay flicker in and out
            if self.votes >= (2 if want == "covered" else 3):
                self.state, self.votes = want, 0
        else:
            self.votes = 0
        return self.state == "covered"
