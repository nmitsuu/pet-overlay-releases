"""
Tells when a full-screen game window (map, storage, enhancement, attendance...) is open by looking
at the game's own HP / MP bars at the bottom of the screen: bright = normal play, dimmed or gone =
a full-screen window or popup is covering the game. Read-only: it only looks at a few pixels.
"""
import ctypes
import math
import time

from PySide6.QtCore import QPoint
from PySide6.QtGui import QGuiApplication, QImage


class _RECT(ctypes.Structure):
    _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long), ("right", ctypes.c_long), ("bottom", ctypes.c_long)]


def client_rect(hwnd):
    """Game window's client area in screen pixels (x, y, w, h), or None."""
    try:
        u = ctypes.windll.user32
        r = _RECT()
        if not u.GetClientRect(hwnd, ctypes.byref(r)):
            return None
        pt = (ctypes.c_long * 2)(0, 0)
        u.ClientToScreen(hwnd, pt)
        return pt[0], pt[1], r.right, r.bottom
    except Exception:
        return None


def _hsv(c):
    r, g, b = c.red() / 255, c.green() / 255, c.blue() / 255
    mx, mn = max(r, g, b), min(r, g, b)
    return mx, (mx - mn) / mx if mx else 0


def _v(img, x, y):
    x, y = int(x), int(y)
    if not (0 <= x < img.width() and 0 <= y < img.height()):
        return 0
    c = img.pixelColor(x, y)
    return max(c.red(), c.green(), c.blue())


def _vmax(img, x, y):
    return max(_v(img, x + a, y + b) for a in (-1, 0, 1) for b in (-1, 0, 1))


def chat_open(img, ox, oy, s):
    """The chat window's header: its X close button with the settings gear next to it (other side
    windows, like Friends, have the X but no gear). img is a grab whose (0, 0) is screen (ox, oy)."""
    cx, cy = 383.5 * s - ox, 40.5 * s - oy
    diag = [_vmax(img, cx + sx * d * s, cy + sy * d * s) for d in (4, 6, 8, 10) for sx in (-1, 1) for sy in (-1, 1)]
    off = [_v(img, cx + a * s, cy + b * s) for a, b in ((0, -9), (0, 9), (-9, 0), (9, 0), (-5, -11), (5, 11))]
    if sum(d > 170 for d in diag) < 13 or max(off) > 160:
        return False
    gx, gy = 327.5 * s - ox, 40.5 * s - oy
    gap = [_v(img, gx + 4.8 * s * math.cos(a), gy + 4.8 * s * math.sin(a)) for a in [k * math.pi / 4 for k in range(8)]]
    ring = [_vmax(img, gx + 8.5 * s * math.cos(a), gy + 8.5 * s * math.sin(a)) for a in [k * math.pi / 4 + 0.2 for k in range(8)]]
    return _vmax(img, gx, gy) > 170 and max(gap) < 130 and sum(r > 170 for r in ring) >= 5


def _exclusive_fullscreen():
    """True while a game owns the screen exclusively (then screen pictures come back black)."""
    try:
        st = ctypes.c_int(0)
        ctypes.windll.shell32.SHQueryUserNotificationState(ctypes.byref(st))
        return st.value == 3
    except Exception:
        return False


class HudWatcher:
    """covered() -> True while a full-screen window / popup is over the game."""

    def __init__(self):
        self.state = "play"          # "play" or "covered"
        self.votes = 0
        self.last = ""
        self.scale = 1.0

    def _sample(self, rect):
        x0, y0, w, h = rect
        s = min(w / 1920, h / 1080)
        cx = x0 + w / 2
        y = y0 + h - int(117 * s)                     # the HP / MP bars sit ~117 px above the bottom
        scr = QGuiApplication.screenAt(QPoint(int(cx), int(y))) or QGuiApplication.primaryScreen()
        g = scr.geometry()
        sx, width = int(cx - 250 * s), int(500 * s)
        span = int(30 * s)                               # a band, not one line: screens and UI layouts
        img = scr.grabWindow(0, sx - g.x(), int(y - span) - g.y(), width, 2 * span).toImage()   # differ a bit
        if img.isNull() or img.width() < 50:
            return None
        if not getattr(self, "_saved", False) and getattr(self, "debug_dir", None):
            self._saved = True                           # one picture per run, to check the layout
            try:
                img.save(str(self.debug_dir / "hud_band.png"))
            except Exception:
                pass
        import numpy as np                               # whole band at once (fast enough to run every frame)
        q = img.convertToFormat(QImage.Format_RGB32)
        h_, w_ = q.height(), q.width()
        arr = np.frombuffer(q.constBits(), np.uint8, q.bytesPerLine() * h_).reshape(h_, q.bytesPerLine())
        px = arr[:, :w_ * 4].reshape(h_, w_, 4).astype(np.int16)
        b_, g_, r_ = px[..., 0], px[..., 1], px[..., 2]
        mx = np.maximum(np.maximum(r_, g_), b_)
        if int(mx.max()) < 14:
            return "black"                               # Windows gave us a black picture (see update)
        mn = np.minimum(np.minimum(r_, g_), b_)
        strong = (mx > 115) & ((mx - mn) > 0.45 * np.maximum(mx, 1))
        red = strong & (r_ * 10 > g_ * 18) & (r_ * 10 > b_ * 18)
        cyan = strong & (b_ * 10 > r_ * 16) & (g_ * 10 > r_ * 14)
        mid = w_ // 2
        gap = int(50 * s)
        left, right = slice(0, max(1, mid - gap)), slice(min(w_ - 1, mid + gap), w_)
        nl, nr = max(1, left.stop - left.start), max(1, right.stop - right.start)
        hp = red[:, left].sum(1) / nl
        mp = cyan[:, right].sum(1) / nr
        wrong = (cyan[:, left].sum(1) + red[:, right].sum(1)) / (nl + nr)
        k = int(np.argmax(hp + mp - 4 * wrong))

        def solid(row):                                  # share of the coloured pixels in the longest run
            n = int(row.sum())
            if n == 0:
                return 0.0
            best = cur = 0
            for v in row:
                cur = cur + 1 if v else 0
                best = max(best, cur)
            return best / n
        self.solid = (solid(red[k, left]), solid(cyan[k, right]))   # real bars are one unbroken stripe
        return float(hp[k]), float(mp[k]), float(wrong[k])

    def update(self, hwnd):
        """Call ~4 times a second while the game is in front. Returns True when covered."""
        rect = client_rect(hwnd) if hwnd else None
        if not rect or rect[2] < 400:
            return self.state == "covered"
        r = self._sample(rect)
        if r is None:
            return self.state == "covered"
        if r == "black" and not _exclusive_fullscreen():
            # a black band with the game in front: a window with a black backdrop (stigma, etc.)
            r = (0.0, 0.0, 0.0)
        if r == "black":
            # In full-screen mode Windows sometimes hands screen readers a black picture while nothing
            # of ours is drawn over the game. Treating that as "a window is open" hid the overlay, which
            # kept the picture black: it only came back after clicking around. Unknown = keep showing.
            self.last = "screen picture black (full-screen game): assuming play"
            self.state, self.votes = "play", 0
            return False
        hp, mp, wrong = r
        # HP red on the left and MP cyan on the right. Both a little, or one clearly: a stray red or cyan
        # icon in a game window (the map has plenty) mustn't count as the bars.
        # (the real bars are clean: nothing of the other colour on either side)
        sl, sr = getattr(self, "solid", (1.0, 1.0))
        bars = (hp > 0.05 and sl > 0.85) + (mp > 0.05 and sr > 0.85)     # unbroken red / cyan stripes
        play = wrong < 0.02 and (bars == 2 or (bars == 1 and max(hp, mp) > 0.6))
        chat = False
        if play:
            x0, y0, w, h = rect
            s = min(w / 1920, h / 1080)
            scr = QGuiApplication.screenAt(QPoint(x0 + 10, y0 + 10)) or QGuiApplication.primaryScreen()
            g = scr.geometry()
            bx, by = int(x0 + 300 * s), int(y0 + 22 * s)
            img = scr.grabWindow(0, bx - g.x(), by - g.y(), int(105 * s), int(38 * s)).toImage()
            chat = not img.isNull() and chat_open(img, bx - x0, by - y0, s)
            play = not chat
        self.last = f"hp {hp:.2f} mp {mp:.2f} other {wrong:.2f} solid {sl:.2f}/{sr:.2f}{'  chat open' if chat else ''}"
        want = "play" if play else "covered"
        if want != self.state:
            self.votes += 1
            # fold after 2 samples (~0.2 s); unfold only once play is steady for 3 (~0.3 s), so the
            # game's own window fade-out doesn't make the overlay flicker in and out
            if self.votes >= (2 if want == "covered" else 3):   # a few frames: quick, without flicker
                self.state, self.votes = want, 0
        else:
            self.votes = 0
        return self.state == "covered"
