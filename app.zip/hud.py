"""
Tells when a full-screen game window (map, storage, enhancement, attendance...) is open by looking
at the game's own HP / MP bars at the bottom of the screen: bright = normal play, dimmed or gone =
a full-screen window or popup is covering the game. Read-only: it only looks at a few pixels.
"""
import ctypes
import math
import time

from PySide6.QtCore import QPoint
from PySide6.QtGui import QGuiApplication


class _RECT(ctypes.Structure):
    _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long), ("right", ctypes.c_long), ("bottom", ctypes.c_long)]


def client_rect(hwnd):
    """Game window's client area in screen pixels (x, y, w, h), or None."""
    try:
        u = ctypes.windll.user32
        r = _RECT()
        if not u.GetClientRect(hwnd, ctypes.byref(r)):
            return None
        pt = (ctypes.c_long * 2)(0, 0)
        u.ClientToScreen(hwnd, pt)
        return pt[0], pt[1], r.right, r.bottom
    except Exception:
        return None


def _hsv(c):
    r, g, b = c.red() / 255, c.green() / 255, c.blue() / 255
    mx, mn = max(r, g, b), min(r, g, b)
    return mx, (mx - mn) / mx if mx else 0


def _v(img, x, y):
    x, y = int(x), int(y)
    if not (0 <= x < img.width() and 0 <= y < img.height()):
        return 0
    c = img.pixelColor(x, y)
    return max(c.red(), c.green(), c.blue())


def _vmax(img, x, y):
    return max(_v(img, x + a, y + b) for a in (-1, 0, 1) for b in (-1, 0, 1))


def chat_open(img, ox, oy, s):
    """The chat window's header: its X close button with the settings gear next to it (other side
    windows, like Friends, have the X but no gear). img is a grab whose (0, 0) is screen (ox, oy)."""
    cx, cy = 383.5 * s - ox, 40.5 * s - oy
    diag = [_vmax(img, cx + sx * d * s, cy + sy * d * s) for d in (4, 6, 8, 10) for sx in (-1, 1) for sy in (-1, 1)]
    off = [_v(img, cx + a * s, cy + b * s) for a, b in ((0, -9), (0, 9), (-9, 0), (9, 0), (-5, -11), (5, 11))]
    if sum(d > 170 for d in diag) < 13 or max(off) > 160:
        return False
    gx, gy = 327.5 * s - ox, 40.5 * s - oy
    gap = [_v(img, gx + 4.8 * s * math.cos(a), gy + 4.8 * s * math.sin(a)) for a in [k * math.pi / 4 for k in range(8)]]
    ring = [_vmax(img, gx + 8.5 * s * math.cos(a), gy + 8.5 * s * math.sin(a)) for a in [k * math.pi / 4 + 0.2 for k in range(8)]]
    return _vmax(img, gx, gy) > 170 and max(gap) < 130 and sum(r > 170 for r in ring) >= 5


class HudWatcher:
    """covered() -> True while a full-screen window / popup is over the game."""

    def __init__(self):
        self.state = "play"          # "play" or "covered"
        self.votes = 0
        self.last = ""
        self.scale = 1.0

    def _sample(self, rect):
        x0, y0, w, h = rect
        s = min(w / 1920, h / 1080)
        cx = x0 + w / 2
        y = y0 + h - int(117 * s)                     # the HP / MP bars sit ~117 px above the bottom
        scr = QGuiApplication.screenAt(QPoint(int(cx), int(y))) or QGuiApplication.primaryScreen()
        g = scr.geometry()
        sx, width = int(cx - 250 * s), int(500 * s)
        img = scr.grabWindow(0, sx - g.x(), int(y - 3 * s) - g.y(), width, max(3, int(6 * s))).toImage()
        if img.isNull() or img.width() < 50:
            return None
        row, mid = img.height() // 2, img.width() / 2
        hp = mp = wrong = nl = nr = 0
        for i in range(0, img.width(), 2):
            if abs(i - mid) < 50 * s:                    # skip the level crest in the middle
                continue
            c = img.pixelColor(i, row)
            v, sat = _hsv(c)
            left = i < mid
            nl += left
            nr += not left
            if sat > 0.45 and v > 0.45:
                is_red = c.red() > c.green() * 1.8 and c.red() > c.blue() * 1.8
                is_cyan = c.blue() > c.red() * 1.6 and c.green() > c.red() * 1.4
                if left:
                    hp += is_red
                    wrong += is_cyan
                else:
                    mp += is_cyan
                    wrong += is_red
        return hp / max(1, nl), mp / max(1, nr), wrong / max(1, nl + nr)

    def update(self, hwnd):
        """Call ~4 times a second while the game is in front. Returns True when covered."""
        rect = client_rect(hwnd) if hwnd else None
        if not rect or rect[2] < 400:
            return self.state == "covered"
        r = self._sample(rect)
        if r is None:
            return self.state == "covered"
        hp, mp, wrong = r
        play = (hp > 0.05 or mp > 0.05) and wrong < 0.05   # HP red on the left / MP cyan on the right
        chat = False
        if play:
            x0, y0, w, h = rect
            s = min(w / 1920, h / 1080)
            scr = QGuiApplication.screenAt(QPoint(x0 + 10, y0 + 10)) or QGuiApplication.primaryScreen()
            g = scr.geometry()
            bx, by = int(x0 + 300 * s), int(y0 + 22 * s)
            img = scr.grabWindow(0, bx - g.x(), by - g.y(), int(105 * s), int(38 * s)).toImage()
            chat = not img.isNull() and chat_open(img, bx - x0, by - y0, s)
            play = not chat
        self.last = f"hp {hp:.2f} mp {mp:.2f} other {wrong:.2f}{'  chat open' if chat else ''}"
        want = "play" if play else "covered"
        if want != self.state:
            self.votes += 1
            # fold after 2 samples (~0.2 s); unfold only once play is steady for 3 (~0.3 s), so the
            # game's own window fade-out doesn't make the overlay flicker in and out
            if self.votes >= (2 if want == "covered" else 3):
                self.state, self.votes = want, 0
        else:
            self.votes = 0
        return self.state == "covered"
