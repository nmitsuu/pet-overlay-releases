"""
Small screen-pixel reads for the window check and the flight gauge, done on helper threads with plain
GDI (Qt's screen grab has to run on the drawing thread and cost ~8 ms a time there, which made the whole
overlay stutter). Read-only: copies a few pixels of the screen, nothing else. Our own overlay windows
aren't included in the copy.
"""
import ctypes
import threading

_lock = threading.Lock()
_api = None


def _setup():
    global _api
    from ctypes import wintypes as W
    u, g = ctypes.windll.user32, ctypes.windll.gdi32
    u.GetDC.restype, u.GetDC.argtypes = W.HDC, [W.HWND]
    u.ReleaseDC.argtypes = [W.HWND, W.HDC]
    g.CreateCompatibleDC.restype, g.CreateCompatibleDC.argtypes = W.HDC, [W.HDC]
    g.CreateCompatibleBitmap.restype = W.HBITMAP
    g.CreateCompatibleBitmap.argtypes = [W.HDC, ctypes.c_int, ctypes.c_int]
    g.SelectObject.restype, g.SelectObject.argtypes = W.HGDIOBJ, [W.HDC, W.HGDIOBJ]
    g.BitBlt.argtypes = [W.HDC] + [ctypes.c_int] * 4 + [W.HDC] + [ctypes.c_int] * 2 + [W.DWORD]
    g.GetDIBits.argtypes = [W.HDC, W.HBITMAP, W.UINT, W.UINT, ctypes.c_void_p, ctypes.c_void_p, W.UINT]
    g.DeleteObject.argtypes, g.DeleteDC.argtypes = [W.HGDIOBJ], [W.HDC]

    class BIH(ctypes.Structure):
        _fields_ = [("biSize", W.DWORD), ("biWidth", W.LONG), ("biHeight", W.LONG), ("biPlanes", W.WORD),
                    ("biBitCount", W.WORD), ("biCompression", W.DWORD), ("biSizeImage", W.DWORD),
                    ("biXPelsPerMeter", W.LONG), ("biYPelsPerMeter", W.LONG), ("biClrUsed", W.DWORD),
                    ("biClrImportant", W.DWORD), ("colors", W.DWORD * 3)]
    _api = (u, g, BIH)


def screen(x, y, w, h):
    """Screen area as a Pic (BGRA), or None."""
    import numpy as np
    w, h = int(w), int(h)
    if w <= 0 or h <= 0:
        return None
    with _lock:
        if _api is None:
            _setup()
    u, g, BIH = _api
    sdc = u.GetDC(None)
    if not sdc:
        return None
    mdc = g.CreateCompatibleDC(sdc)
    bmp = g.CreateCompatibleBitmap(sdc, w, h)
    try:
        old = g.SelectObject(mdc, bmp)
        g.BitBlt(mdc, 0, 0, w, h, sdc, int(x), int(y), 0x00CC0020)
        g.SelectObject(mdc, old)
        bi = BIH()
        bi.biSize, bi.biWidth, bi.biHeight, bi.biPlanes, bi.biBitCount = 40, w, -h, 1, 32
        buf = np.empty((h, w, 4), np.uint8)
        if not g.GetDIBits(mdc, bmp, 0, h, buf.ctypes.data, ctypes.byref(bi), 0):
            return None
        return Pic(buf)
    finally:
        g.DeleteObject(bmp)
        g.DeleteDC(mdc)
        u.ReleaseDC(None, sdc)


class Pic:
    """A grabbed picture: a = height x width x 4 numpy array (blue, green, red, unused)."""

    def __init__(self, a):
        self.a = a

    def width(self):
        return self.a.shape[1]

    def height(self):
        return self.a.shape[0]

    def isNull(self):
        return self.a is None or self.a.size == 0

    def rgb(self, x, y):
        b, g, r = self.a[y, x, :3].tolist()
        return r, g, b
