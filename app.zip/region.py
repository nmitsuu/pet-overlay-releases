"""
Which Global region you play on, found automatically from where the game server you're connected to
is, and that region's server clock (events like Spacetime Rifts follow the server's local time).
Read-only: it only looks up the game server's public address.
"""
import json
import threading
import urllib.request
from datetime import datetime, timedelta, timezone, tzinfo
from pathlib import Path

NAMES = {"asia": "Asia", "europe": "Europe", "na_east": "NA East", "na_west": "NA West", "sa": "South America"}
ASIA = {"KR", "JP", "TW", "HK", "SG", "MY", "TH", "PH", "VN", "ID", "IN", "AU", "NZ", "CN", "MO"}
SA = {"BR", "AR", "CL", "PE", "CO", "UY", "PY", "MX"}
WEST_TZ = ("Los_Angeles", "Vancouver", "Phoenix", "Denver", "Boise", "Edmonton", "Tijuana", "Anchorage")


def _nth_sunday(y, m, n):
    d = datetime(y, m, 1)
    d += timedelta(days=(6 - d.weekday()) % 7)
    return d + timedelta(weeks=n - 1)


def _last_sunday(y, m):
    d = datetime(y, m + 1, 1) - timedelta(days=1) if m < 12 else datetime(y, 12, 31)
    return d - timedelta(days=(d.weekday() + 1) % 7)


def offset(region, utc):
    """Server clock offset from UTC for a region at a UTC moment (naive datetime in UTC)."""
    y = utc.year
    if region == "europe":                                   # CET / CEST
        on = _last_sunday(y, 3) + timedelta(hours=1)
        off = _last_sunday(y, 10) + timedelta(hours=1)
        return timedelta(hours=2 if on <= utc < off else 1)
    if region in ("na_east", "na_west"):                     # ET / PT
        base = -5 if region == "na_east" else -8
        on = _nth_sunday(y, 3, 2) + timedelta(hours=2 - base)
        off = _nth_sunday(y, 11, 1) + timedelta(hours=1 - base)
        return timedelta(hours=base + (1 if on <= utc < off else 0))
    if region == "sa":
        return timedelta(hours=-3)
    return timedelta(hours=9)                                # Asia: Seoul time


class RegionTZ(tzinfo):
    """The server clock of the detected region (changes by itself once the region is known)."""

    def __init__(self):
        self.region = "asia"

    def _off(self, utc_naive):
        return offset(self.region, utc_naive)

    def utcoffset(self, dt):
        if dt is None:
            return self._off(datetime.utcnow())
        naive = dt.replace(tzinfo=None)
        guess = self._off(naive - timedelta(hours=9 if self.region == "asia" else 0))
        return self._off(naive - guess)

    def dst(self, dt):
        return timedelta(0)

    def tzname(self, dt):
        return NAMES.get(self.region, self.region)

    def fromutc(self, dt):
        naive = dt.replace(tzinfo=None)
        return (naive + self._off(naive)).replace(tzinfo=self)


SERVER = RegionTZ()


class RegionFinder:
    """Region of play. Locating the game server by its address said "Europe" for Mitsu's Asia server (the
    servers aren't where their region is), so it's set to Asia, where she and her boyfriend play. The
    server address is still recorded in the status file in case the region ever needs telling apart."""
    FIXED = "asia"

    def __init__(self, folder, log):
        self.path = Path(folder) / "maps" / "region.json"
        self.log = log
        try:
            self.cache = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            self.cache = {}
        self.ip, self.busy = None, False
        SERVER.region = self.FIXED

    def status(self):
        return f"{NAMES.get(SERVER.region, SERVER.region)} (server {self.ip or 'not seen yet'})"

    def update(self, ip):
        if not ip or ip == self.ip or self.busy:
            return
        self.ip = ip
        if self.FIXED:
            return
        if ip in self.cache:
            self._set(self.cache[ip])
            return
        self.busy = True
        threading.Thread(target=self._look, args=(ip,), daemon=True).start()

    def _set(self, region):
        SERVER.region = region
        self.cache["_last"] = region
        try:
            self.path.write_text(json.dumps(self.cache), encoding="utf-8")
        except OSError:
            pass

    def _look(self, ip):
        try:
            req = urllib.request.Request(f"http://ip-api.com/json/{ip}?fields=countryCode,timezone",
                                         headers={"User-Agent": "PetOverlay"})
            d = json.loads(urllib.request.urlopen(req, timeout=15).read())
            cc, tz = d.get("countryCode", ""), d.get("timezone", "")
            if cc in ("US", "CA"):
                region = "na_west" if any(w in tz for w in WEST_TZ) else "na_east"
            elif cc in ASIA:
                region = "asia"
            elif cc in SA:
                region = "sa"
            else:
                region = "europe"
            self.cache[ip] = region
            self._set(region)
        except Exception as e:
            self.log(f"region lookup failed: {e}")
            self.ip = None
        finally:
            self.busy = False
