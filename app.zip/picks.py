"""What shows where: her ticks for the minimap ("mini") and the big map ("big"), per kind ("pets" /
"gather"). Kept as the names she unticked (so new pets / materials show by default). When linked, the big
map uses the minimap's ticks. Saved in state["picks"]."""


import json
import os


class Picks:
    def __init__(self, state, save, all_names, path=None):
        self.state, self._save_state, self.all_names = state, save, all_names   # all_names(kind) -> [names]
        self.path = path                         # her ticks' own file: no other save can overwrite them
        self.ver = 0
        if path is not None:
            try:
                with open(path, encoding="utf-8") as f:
                    v = json.load(f)
                if isinstance(v, dict) and "mini" in v:
                    state["picks"] = v
            except (OSError, ValueError):
                pass
        p = state.get("picks")
        if not isinstance(p, dict):                      # first run: start from what the switches showed
            sh = state.get("show", {})
            v = sh.get("mini_layer")
            if v not in ("pets", "gather", "off"):
                v = sh.get("map_layer") if sh.get("map_layer") in ("pets", "gather", "off") else "pets"
            mini = {"pets": [], "gather": []}
            for kind in ("pets", "gather"):
                if v == "off" or (v != kind):
                    mini[kind] = list(all_names(kind))
            p = state["picks"] = {"mini": mini, "big": {"pets": [], "gather": []}, "link": False}
            save()
        self._sets = {}

    def _src(self, where):
        return "mini" if where == "big" and self.linked() else where

    def linked(self):
        return bool(self.state["picks"].get("link", False))

    def set_link(self, on):
        self.state["picks"]["link"] = bool(on)
        self._changed()

    def hidden(self, where, kind):
        key = (self._src(where), kind)
        s = self._sets.get(key)
        if s is None:
            s = self._sets[key] = set(self.state["picks"].setdefault(key[0], {}).get(kind, []))
        return s

    def shown(self, where, kind, name):
        return name not in self.hidden(where, kind)

    def toggle(self, where, kind, name):
        lst = self.state["picks"].setdefault(self._src(where), {}).setdefault(kind, [])
        if name in lst:
            lst.remove(name)
        else:
            lst.append(name)
        self._changed()

    def set_all(self, where, kind, names, show):
        lst = self.state["picks"].setdefault(self._src(where), {}).setdefault(kind, [])
        names = set(names)
        keep = [n for n in lst if n not in names]
        self.state["picks"][self._src(where)][kind] = keep if show else keep + sorted(names)
        self._changed()

    def state_of(self, where, kind, names):
        """"all" (every one shown), "none" (all hidden) or "mixed" (picked by hand)."""
        hid = self.hidden(where, kind)
        n = sum(1 for x in names if x in hid)
        return "all" if n == 0 else "none" if n == len(names) else "mixed"

    def flip_all(self, where, kind, names):
        """The eye button: all shown -> hide all; hidden or picked by hand -> show all."""
        self.set_all(where, kind, names, self.state_of(where, kind, names) != "all")

    def any_shown(self, where):
        return any(len(self.hidden(where, k)) < len(self.all_names(k)) for k in ("pets", "gather"))

    def save(self):
        if self.path is not None:
            try:
                tmp = str(self.path) + ".tmp"
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(self.state["picks"], f)
                os.replace(tmp, self.path)
            except OSError:
                pass
        self._save_state()

    def _changed(self):
        self._sets = {}
        self.ver += 1
        self.save()
