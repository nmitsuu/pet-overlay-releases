"""Soft notification sounds, made once as small .wav files in sounds/ and played without blocking."""
import math
import struct
import wave
from pathlib import Path

RATE = 44100


def _bell(freqs, dur, decay, amp=0.22, start=0.0):
    out = []
    n = int(dur * RATE)
    for i in range(n):
        t = i / RATE
        v = sum(a * math.sin(2 * math.pi * f * t) for f, a in freqs)
        env = min(1.0, t / 0.03) * math.exp(-t * decay)
        out.append(v * env * amp)
    return [0.0] * int(start * RATE) + out


def _mix(*parts):
    n = max(len(p) for p in parts)
    return [sum(p[i] for p in parts if i < len(p)) for i in range(n)]


def _sweep(f0, f1, dur, amp=0.16):
    out, ph = [], 0.0
    n = int(dur * RATE)
    for i in range(n):
        t = i / RATE
        f = f0 + (f1 - f0) * (t / dur) ** 1.5
        ph += 2 * math.pi * f / RATE
        env = math.sin(math.pi * t / dur) ** 1.5
        out.append(math.sin(ph) * (0.8 + 0.2 * math.sin(2 * math.pi * 9 * t)) * env * amp)
    return out


def _breath(dur=1.1, amp=0.05, lo=0.06, hi=0.22, seed=7):
    """Soft filtered-noise swell, like a quiet exhale."""
    import random
    rnd = random.Random(seed)
    out, a, b = [], 0.0, 0.0
    n = int(dur * RATE)
    for i in range(n):
        t = i / RATE
        x = rnd.uniform(-1, 1)
        a += lo * (x - a)                 # two one-pole filters: keep the soft mid "hhh" band
        b += hi * (a - b)
        env = math.sin(math.pi * min(1.0, t / dur)) ** 2 * (1 - 0.35 * t / dur)
        out.append((a - b * 0.6) * env * amp * 6)
    return out


def _soft(x, delay=0.13, fb=0.28, taps=3):
    """Gentle room: a few quiet echoes so a chime rings out instead of stopping dead."""
    d = int(delay * RATE)
    out = list(x) + [0.0] * d * taps
    for k in range(1, taps + 1):
        g = fb ** k
        for i, v in enumerate(x):
            out[i + d * k] += v * g
    return out


def _airy(f, dur, decay, amp, start=0.0):
    """A soft, slow-blooming note with a faint shimmer (no sharp strike, unlike the chimes)."""
    out = []
    n = int(dur * RATE)
    for i in range(n):
        t = i / RATE
        ph = 2 * math.pi * f * (t + 0.0009 * math.sin(2 * math.pi * 5.5 * t))
        env = min(1.0, t / 0.09) ** 2 * math.exp(-t * decay)
        out.append((math.sin(ph) + 0.08 * math.sin(2 * ph)) * env * amp)
    return [0.0] * int(start * RATE) + out


VERSION = 6          # bump to remake the files
# gentle: quiet, soft start, low overtones only
SOUNDS = {
    # world / field boss: two soft rising chime notes
    "boss": lambda: _mix(_bell([(523, 1), (1046, 0.12)], 0.9, 4.5, 0.09), _bell([(784, 1), (1568, 0.1)], 1.0, 4, 0.08, start=0.2)),
    # Shugo: three light, quick plinks
    "shugo": lambda: _mix(*[_bell([(f, 1)], 0.35, 10, 0.07, start=k * 0.11) for k, f in enumerate((880, 1047, 1319))]),
    # Dimensional Invasion: soft airy rise
    "space": lambda: _mix(_sweep(330, 700, 0.8, 0.06), _bell([(1400, 0.5)], 0.6, 6, 0.04, start=0.6)),
    # Spacetime Rift: one low, warm hum-bell
    "rift": lambda: _bell([(294, 1), (441, 0.3)], 1.3, 3.0, 0.11),
    # flight energy full: a soft breath of wind with three slow, airy notes rising (wind-chime feel);
    # the only sound with a whoosh, so it can't be mixed up with the plinks and bells of the events
    "flight": lambda: _soft(_mix(_breath(1.0, 0.035, 0.05, 0.25, seed=11),
                                 *[_airy(f, 1.5, 2.4, 0.045, start=0.18 + k * 0.17)
                                   for k, f in enumerate((1319, 1661, 1976))]), delay=0.16, fb=0.22),
    # Artifact Siege: two low, round notes
    "siege": lambda: _mix(_bell([(349, 1), (698, 0.2)], 0.7, 3.5, 0.09),
                          _bell([(466, 1), (932, 0.2)], 0.9, 3.0, 0.09, start=0.28)),
}


def make(folder):
    folder = Path(folder)
    folder.mkdir(exist_ok=True)
    for name, fn in SOUNDS.items():
        path = folder / f"{name}_v{VERSION}.wav"
        if path.exists():
            continue
        data = fn()
        with wave.open(str(path), "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(RATE)
            w.writeframes(b"".join(struct.pack("<h", int(max(-1, min(1, v)) * 32767)) for v in data))


LEVEL = {"flight": 0.6}      # some sounds sit lower than the rest


def _scaled(folder, name, vol):
    """The sound at a volume (winsound can't change volume, so a quieter copy is made once)."""
    folder = Path(folder)
    v = int(round(vol * LEVEL.get(name, 1.0) * 100))
    path = folder / f"{name}_v{VERSION}_{v}.wav"
    if not path.exists():
        with wave.open(str(folder / f"{name}_v{VERSION}.wav"), "rb") as r:
            p, raw = r.getparams(), r.readframes(r.getnframes())
        n = len(raw) // 2
        vals = struct.unpack(f"<{n}h", raw)
        with wave.open(str(path), "wb") as w:
            w.setparams(p)
            w.writeframes(struct.pack(f"<{n}h", *(int(x * v / 100) for x in vals)))
    return path


def play(folder, name, vol=0.5):
    if vol <= 0:
        return
    try:
        import winsound
        winsound.PlaySound(str(_scaled(folder, name, vol)),
                           winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_NODEFAULT)
    except Exception:
        pass
