"""
Flight energy: reads the game's own flight gauge (the cyan arc next to your character) while you
fly, learns how fast it refills from what it sees between landing and taking off again, then tells
you quietly when it's full. Read-only: it only looks at the pixels of that arc.
"""
import math
import time

from PySide6.QtCore import QPoint
from PySide6.QtGui import QGuiApplication

R, N = 123, 40                                   # arc radius and samples (1920-wide UI)
T0, T1 = math.atan2(-81, -93), math.atan2(81, -93) - 2 * math.pi


def _cyan(c):
    return c.green() > 215 and c.blue() > 195 and c.green() > c.red() + 15


def _val(c):
    return max(c.red(), c.green(), c.blue()) / 255


def read_arc(img, ox, oy, s):
    """Fill 0..1 if the gauge is at this spot in img (centre of the arc's circle = ox, oy), else None."""
    W, H = img.width(), img.height()
    seq, darker = [], 0
    for k in range(N):
        t = T0 + (T1 - T0) * k / (N - 1)
        ct, st = math.cos(t), math.sin(t)
        hit, inner = False, None
        for dr in (-3, -1, 1):
            x, y = int(ox + (R + dr) * s * ct), int(oy + (R + dr) * s * st)
            if not (0 <= x < W and 0 <= y < H):
                return None
            c = img.pixelColor(x, y)
            hit = hit or _cyan(c)
            if dr == -1:
                inner = c
        seq.append(hit)
        if not hit:
            x, y = int(ox + (R + 6) * s * ct), int(oy + (R + 6) * s * st)
            if 0 <= x < W and 0 <= y < H and _val(inner) < _val(img.pixelColor(x, y)) - 0.05:
                darker += 1
    if sum(seq) < 3:
        return None
    first = seq.index(True)
    if seq[first:].count(False) > 2 or not any(seq[-3:]):
        return None
    nonc = N - sum(seq)
    if nonc and darker < 0.5 * nonc:                 # the empty part must be the gauge's dark track
        return None
    return (N - first) / N


class FlightWatcher:
    def __init__(self, state, notify):
        self.state, self.notify = state, notify
        self.lock = None                             # (dx, dy) where the gauge was last found
        self.visible, self.fill, self.seen_t = False, None, 0.0
        self.landed = None                           # (time, fill) when it disappeared
        self.full_at, self.told = None, False
        self.badge = ""
        self.told_at = 0.0
        self.rect = None
        self.on_takeoff = None
        self.log_until, self.log_path = 0.0, None

    def ring(self):
        """For the circle on screen: (fill 0..1, "refill" | "full") while it refills after landing, else None."""
        now = time.time()
        if self.told and now - self.told_at < 5:
            return 1.0, "full"
        f = None if (self.visible or self.told) else self.predict(now)
        return (f, "refill") if f is not None else None

    def model(self):
        """(rate per second, delay after landing before it refills), learned from your own flights:
        each landing -> take-off gives (seconds on the ground, how much it refilled). Long gaps are left
        out (you may have flown while the game wasn't in front, so they'd teach a far too slow refill)."""
        sm = [x for x in self.state.get("flight_samples", []) if 2 < x[0] <= 240 and x[1] > 0]
        rates = [g / e for e, g in sm if 0.0005 < g / e < 0.2]
        if not rates:
            r = sorted(x for x in self.state.get("flight_rates", []) if 0.0005 < x < 0.2)
            return (r[len(r) // 2], 0.0) if r else None
        if len(sm) < 3 or max(x[0] for x in sm) - min(x[0] for x in sm) < 8:
            rates.sort()
            return rates[len(rates) // 2], 0.0
        slopes = sorted((g2 - g1) / (e2 - e1) for i, (e1, g1) in enumerate(sm) for e2, g2 in sm[i + 1:]
                        if abs(e2 - e1) > 4)                     # robust line fit (median of pair slopes)
        a = slopes[len(slopes) // 2] if slopes else 0
        if not 0.0005 < a < 0.2:
            rates.sort()
            return rates[len(rates) // 2], 0.0
        ds = sorted(e - g / a for e, g in sm)
        d = min(20.0, max(0.0, ds[len(ds) // 2]))
        return a, d

    def rate(self):
        m = self.model()
        return m[0] if m else None

    def predict(self, now):
        m = self.model()
        if not m or not self.landed or self.landed[1] is None:
            return None
        r, d = m
        t1, l1 = self.landed
        return min(1.0, l1 + r * max(0.0, now - t1 - d))

    def _grab(self, rect):
        x0, y0, w, h = rect
        s = min(w / 1920, h / 1080)
        cx, cy = x0 + w / 2, y0 + h / 2
        bx, by, bw, bh = int(cx - 170 * s), int(cy - 100 * s), int(120 * s), int(260 * s)
        scr = QGuiApplication.screenAt(QPoint(int(cx), int(cy))) or QGuiApplication.primaryScreen()
        g = scr.geometry()
        img = scr.grabWindow(0, bx - g.x(), by - g.y(), bw, bh).toImage()
        return img, s, cx - bx, cy - by

    def _find(self, img, s, ccx, ccy):
        spots = [self.lock] if self.lock else [(dx, dy) for dy in range(-36, 37, 4) for dx in (-6, 0, 6)]
        for dx, dy in spots:
            f = read_arc(img, ccx - 25 * s + dx * s, ccy + 31 * s + dy * s, s)
            if f is not None:
                self.lock = (dx, dy)
                return f
        return None

    def tick(self, game_fg, hwnd):
        """~4 times a second."""
        now = time.time()
        if not game_fg and self.landed:
            self.blind = True                        # can't see flights while the game isn't in front
        if game_fg and hwnd and self.state.get("show", {}).get("flight", True):
            from hud import client_rect
            rect = client_rect(hwnd)
            if rect and rect[2] > 400:
                self.rect = rect
                img, s, ccx, ccy = self._grab(rect)
                f = self._find(img, s, ccx, ccy) if not img.isNull() else None
                if f is None and self.lock and now - self.seen_t > 2:
                    self.lock = None                 # search again next time
                if f is not None:
                    if not self.visible and self.landed and now - self.landed[0] > 3:
                        t1, l1 = self.landed      # took off again: how much did it refill meanwhile?
                        if f > l1 + 0.04 and f < 0.97 and not getattr(self, "blind", False):
                            sm = self.state.get("flight_samples", []) + [[round(now - t1, 1), round(f - l1, 3)]]
                            self.state["flight_samples"] = sm[-10:]
                        if self.on_takeoff:
                            self.on_takeoff()
                    self.visible, self.fill, self.seen_t = True, f, now
                    if now < self.log_until and self.log_path:     # gauge readings next to a game-data sample
                        try:
                            with open(self.log_path, "a", encoding="utf-8") as fh:
                                fh.write(f"[{now:.2f}, {f:.3f}]\n")
                        except OSError:
                            pass
                    self.landed, self.full_at, self.told = None, None, False
                elif self.visible and now - self.seen_t > 1.5:
                    self.visible = False             # landed: gauge hidden
                    self.landed = (self.seen_t, self.fill)
                    self.blind = False
        if not self.visible and self.landed and not self.told:
            m = self.model()
            t1, l1 = self.landed
            if m and l1 is not None and l1 < 0.97:
                r, d = m
                self.full_at = t1 + d + (1 - l1) / r
                left = self.full_at - now
                self.badge = f"{int(left) // 60}:{int(left) % 60:02d}" if left > 0 else ""
                if left <= 0:
                    self.told, self.told_at = True, now
                    self.notify("Flight energy full")
            else:
                self.badge = ""
        elif self.visible:
            self.badge = ""

    def status(self):
        m = self.model()
        r = m[0] if m else None
        return (f"delay {m[1]:.1f}s  " if m else "") + (f"gauge {'seen ' + str(round(self.fill, 2)) if self.visible else 'hidden'}  "
                f"refill {'learned ' + str(round(r * 60, 3)) + '/min' if r else 'not learned yet'}  "
                f"full in {self.badge or '-'}")
