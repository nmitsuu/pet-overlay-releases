"""
Pet spawns drawn right on the game's own big map. While a full-screen window is open it looks at the
screen, recognises the region map by matching it against the same map picture the Farm maps use, works
out where it's scrolled and zoomed to, and draws pet icons at their spawn spots. Read-only: it only
looks at screen pixels, nothing is sent to the game.
Needs OpenCV (installed by itself in the background the first time).
"""
import importlib
import json
import math
import os
import site
import subprocess
import sys
import threading
import time
from pathlib import Path

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer
from PySide6.QtGui import QColor, QCursor, QPainter, QPainterPath, QPen, QRegion
from PySide6.QtWidgets import QWidget

MAPRES = 4096                       # map picture size the features are found at
GENUS_COL = {"C": "#5AA9FF", "F": "#FF6B5E", "N": "#5FD38A", "V": "#F2C94C"}


def _cv():
    try:
        import cv2
        import numpy
        return cv2, numpy
    except ImportError:
        return None, None


def ensure_cv(app_dir, log):
    """True when OpenCV can be used; otherwise starts a one-time quiet install and returns False."""
    if _cv()[0]:
        return True
    flag = Path(app_dir) / "maps" / "opencv_install.txt"
    try:
        if time.time() - flag.stat().st_mtime < 6 * 3600:
            return False
    except OSError:
        pass
    try:
        flag.parent.mkdir(exist_ok=True)
        flag.write_text(time.ctime(), encoding="utf-8")
    except OSError:
        return False

    def work():
        exe = Path(sys.executable)
        py = exe.with_name("python.exe") if exe.name.lower() == "pythonw.exe" else exe
        try:
            r = subprocess.run([str(py), "-m", "pip", "install", "--user", "--disable-pip-version-check", "-q",
                                "opencv-python-headless", "numpy", "dxcam"], capture_output=True, text=True, timeout=900,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            if r.returncode:
                log(f"map overlay: installing OpenCV failed: {r.stderr[-400:]}")
            site.addsitedir(site.getusersitepackages())
            importlib.invalidate_caches()
        except Exception as e:
            log(f"map overlay: installing OpenCV failed: {e}")
    threading.Thread(target=work, daemon=True).start()
    return False


class Matcher:
    """Finds where a screenshot of the big map sits on the region's map picture."""

    def __init__(self, maps_dir, log):
        self.dir, self.log = Path(maps_dir), log
        self.feats = {}
        cv2, np = _cv()
        self.cv2, self.np = cv2, np
        self.orb = cv2.ORB_create(nfeatures=1500, scaleFactor=1.25, nlevels=10)
        self.bf = cv2.BFMatcher(cv2.NORM_HAMMING)

    def _src(self, w):
        for n in (f"world_{w}.webp", f"_{w}.webp"):
            if (self.dir / n).exists():
                return self.dir / n
        return None

    def worlds(self):
        out = {p.stem.split("_", 1)[1] for p in self.dir.glob("world_*.webp")}
        out |= {p.stem[1:] for p in self.dir.glob("_*.webp")}
        return sorted(out)

    def feats_for(self, w):
        if w in self.feats:
            return self.feats[w]
        cv2, np = self.cv2, self.np
        src = self._src(w)
        if src is None:
            self.feats[w] = None
            return None
        cache = self.dir / f"feat_{w}.npz"
        try:
            if cache.exists() and cache.stat().st_mtime >= src.stat().st_mtime:
                z = np.load(cache)
                self.feats[w] = (z["p"], z["d"])
                return self.feats[w]
            img = cv2.imread(str(src), cv2.IMREAD_GRAYSCALE)
            if img is None:
                self.feats[w] = None
                return None
            img = cv2.resize(img, (MAPRES, MAPRES), interpolation=cv2.INTER_AREA)
            orb = cv2.ORB_create(nfeatures=40000, scaleFactor=1.25, nlevels=12, fastThreshold=12)
            k, d = orb.detectAndCompute(img, None)
            p = np.float32([q.pt for q in k]) / MAPRES
            np.savez(cache, p=p, d=d)
            self.feats[w] = (p, d)
        except Exception as e:
            self.log(f"map overlay: features for {w} failed: {e}")
            self.feats[w] = None
        return self.feats[w]

    def match(self, gray, w, prev=None):
        """gray: numpy screen image. Returns a 2x3 transform (screen px -> map 0..1) or None."""
        cv2, np = self.cv2, self.np
        f = self.feats_for(w)
        if f is None:
            return None
        P, D = f
        h, wd = gray.shape
        mask = np.zeros_like(gray)
        mask[int(h * 0.07):, int(wd * 0.3):] = 255          # skip the list on the left and the top bar
        ks, ds = self.orb.detectAndCompute(gray, mask)
        if ds is None or len(ks) < 30:
            return None
        idx = None
        if prev is not None:                                  # look only near where it was a moment ago
            c = np.float32([[0, 0], [wd, 0], [0, h], [wd, h]])
            m = (prev[:, :2] @ c.T).T + prev[:, 2]
            (x0, y0), (x1, y1) = m.min(0), m.max(0)
            mx, my = (x1 - x0) * 0.25, (y1 - y0) * 0.25
            sel = (P[:, 0] > x0 - mx) & (P[:, 0] < x1 + mx) & (P[:, 1] > y0 - my) & (P[:, 1] < y1 + my)
            idx = np.nonzero(sel)[0]
            if len(idx) < 50:
                idx = None
        Dm = D if idx is None else D[idx]
        ms = self.bf.knnMatch(ds, Dm, k=2)
        good = [a for a, b in (x for x in ms if len(x) == 2) if a.distance < 0.8 * b.distance]
        if len(good) < 15:
            return None
        src = np.float32([ks[a.queryIdx].pt for a in good])
        ti = np.array([a.trainIdx for a in good])
        dst = (P[ti] if idx is None else P[idx[ti]]) * MAPRES
        H, inl = cv2.estimateAffinePartial2D(src, dst, method=cv2.RANSAC, ransacReprojThreshold=4)
        if H is None or inl is None:
            return None
        n = int(inl.sum())
        rot = math.atan2(H[1, 0], H[0, 0])
        if n < 18 or n < 0.35 * len(good) or abs(rot) > 0.03 or H[0, 0] <= 0:
            return None
        return H / MAPRES


def ensure_dxcam(app_dir, log):
    """Faster screen copies (DXGI, the way recording apps do it). Optional: GDI is used until it's there."""
    try:
        import dxcam  # noqa: F401
        return True
    except Exception:
        pass
    flag = Path(app_dir) / "maps" / "dxcam_install.txt"
    if flag.exists():
        return False
    try:
        flag.write_text(time.ctime(), encoding="utf-8")
    except OSError:
        return False

    def work():
        exe = Path(sys.executable)
        py = exe.with_name("python.exe") if exe.name.lower() == "pythonw.exe" else exe
        try:
            subprocess.run([str(py), "-m", "pip", "install", "--user", "--disable-pip-version-check", "-q", "dxcam"],
                           capture_output=True, text=True, timeout=600,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            site.addsitedir(site.getusersitepackages())
            importlib.invalidate_caches()
        except Exception as e:
            log(f"map overlay: dxcam install failed: {e}")
    threading.Thread(target=work, daemon=True).start()
    return False


class Capture:
    """Grey copies of a screen area. DXGI (dxcam) when it works: it hands over a frame the moment the
    screen changes, in ~2 ms. Otherwise plain GDI. Shared by the big-map and minimap trackers."""

    def __init__(self, app_dir, log):
        self.app_dir, self.log = app_dir, log
        self.lock = threading.Lock()
        self.cam, self.cam_tried, self.gdi = None, 0.0, None
        self.kind = "gdi"

    def _dx(self):
        if self.cam is not None or time.time() < self.cam_tried:
            return self.cam
        self.cam_tried = time.time() + 5
        if not ensure_dxcam(self.app_dir, self.log):
            return None
        try:
            import dxcam
            self.cam = dxcam.create(output_idx=0, output_color="BGRA")
            self.kind = "dxgi"
        except Exception as e:
            self.log(f"map overlay: dxcam unavailable ({e}), using GDI")
            self.cam = None
            self.cam_tried = time.time() + 30
        return self.cam

    def grab(self, rect, np, cv2):
        """Full-resolution grey picture of rect, or None if the screen hasn't changed (DXGI only)."""
        x, y, w, h = rect
        with self.lock:
            cam = self._dx()
            if cam is not None:
                try:
                    W, H = cam.width, cam.height
                    if x >= 0 and y >= 0 and x + w <= W and y + h <= H:
                        f = cam.grab(region=(x, y, x + w, y + h))
                        self.fails = 0
                        self.kind = "dxgi"
                        return None if f is None else cv2.cvtColor(f, cv2.COLOR_BGRA2GRAY)
                except Exception as e:
                    # usually Windows taking the screen copy away for a moment (alt-tab, a full-screen
                    # switch): reconnect instead of giving up; plain GDI meanwhile
                    self.fails = getattr(self, "fails", 0) + 1
                    if self.fails in (1, 50):
                        self.log(f"map overlay: dxcam lost the screen ({e}), reconnecting")
                    try:
                        cam._on_output_change()
                    except Exception:
                        pass
                    if self.fails == 30:                    # still lost: start a brand-new screen copy
                        try:
                            import dxcam
                            cam.release()
                            getattr(dxcam, "__factory")._camera_instances.clear()
                        except Exception:
                            pass
                        self.cam, self.cam_tried = None, 0.0
                    if self.fails > 200:                    # it really doesn't work here: GDI for a while
                        self.cam, self.cam_tried, self.kind, self.fails = None, time.time() + 60, "gdi", 0
                    if self.gdi is None:
                        self.gdi = _Gdi()
                    return self.gdi.grab(rect, np, cv2)
            if self.gdi is None:
                self.gdi = _Gdi()
            return self.gdi.grab(rect, np, cv2)


class _Gdi:
    def __init__(self):
        import ctypes
        from ctypes import wintypes as W
        self.c = ctypes
        u, g = ctypes.windll.user32, ctypes.windll.gdi32
        u.GetDC.restype, u.GetDC.argtypes = W.HDC, [W.HWND]
        u.ReleaseDC.argtypes = [W.HWND, W.HDC]
        g.CreateCompatibleDC.restype, g.CreateCompatibleDC.argtypes = W.HDC, [W.HDC]
        g.CreateCompatibleBitmap.restype = W.HBITMAP
        g.CreateCompatibleBitmap.argtypes = [W.HDC, ctypes.c_int, ctypes.c_int]
        g.SelectObject.restype, g.SelectObject.argtypes = W.HGDIOBJ, [W.HDC, W.HGDIOBJ]
        g.BitBlt.argtypes = [W.HDC] + [ctypes.c_int] * 4 + [W.HDC] + [ctypes.c_int] * 2 + [W.DWORD]
        g.GetDIBits.argtypes = [W.HDC, W.HBITMAP, W.UINT, W.UINT, ctypes.c_void_p, ctypes.c_void_p, W.UINT]
        g.DeleteObject.argtypes, g.DeleteDC.argtypes = [W.HGDIOBJ], [W.HDC]
        self.u, self.g = u, g

        class BIH(ctypes.Structure):
            _fields_ = [("biSize", W.DWORD), ("biWidth", W.LONG), ("biHeight", W.LONG), ("biPlanes", W.WORD),
                        ("biBitCount", W.WORD), ("biCompression", W.DWORD), ("biSizeImage", W.DWORD),
                        ("biXPelsPerMeter", W.LONG), ("biYPelsPerMeter", W.LONG), ("biClrUsed", W.DWORD),
                        ("biClrImportant", W.DWORD), ("colors", W.DWORD * 3)]
        self.BIH = BIH

    def grab(self, rect, np, cv2):
        x, y, w, h = rect
        u, g = self.u, self.g
        sdc = u.GetDC(None)
        mdc = g.CreateCompatibleDC(sdc)
        bmp = g.CreateCompatibleBitmap(sdc, w, h)
        old = g.SelectObject(mdc, bmp)
        g.BitBlt(mdc, 0, 0, w, h, sdc, x, y, 0x00CC0020)       # our layered windows aren't copied
        g.SelectObject(mdc, old)
        bi = self.BIH()
        bi.biSize, bi.biWidth, bi.biHeight, bi.biPlanes, bi.biBitCount = 40, w, -h, 1, 32
        buf = np.empty((h, w, 4), np.uint8)
        g.GetDIBits(mdc, bmp, 0, h, buf.ctypes.data, self.c.byref(bi), 0)
        g.DeleteObject(bmp)
        g.DeleteDC(mdc)
        u.ReleaseDC(None, sdc)
        return cv2.cvtColor(buf, cv2.COLOR_BGRA2GRAY)


class Cursor:
    """Samples the mouse position and left button ~500 times a second (only reads them; nothing is sent
    anywhere). Lets the map layer move with a drag in real time, the same way the game's map does."""

    def __init__(self):
        import collections
        self.hist = collections.deque(maxlen=600)      # (t, x, y, down)
        self.presses = collections.deque(maxlen=20)    # (t, x, y) when the button went down
        self.on = False
        self.ok = True
        self.last_press = None
        self.key0, self.close_key = False, 0.0
        try:
            import ctypes
            from ctypes import wintypes
            self.u = ctypes.windll.user32
            self.pt = wintypes.POINT()
            self.ref = ctypes.byref(self.pt)
        except Exception:
            self.ok = False
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        down0 = False
        while True:
            if not (self.on and self.ok):
                time.sleep(0.05)
                continue
            self.u.GetCursorPos(self.ref)
            down = bool(self.u.GetAsyncKeyState(0x01) & 0x8000)
            t = time.time()
            self.hist.append((t, self.pt.x, self.pt.y, down))
            if down and not down0:
                self.presses.append((t, self.pt.x, self.pt.y))
                self.last_press = (t, self.pt.x, self.pt.y)
            down0 = down
            k = bool(self.u.GetAsyncKeyState(0x4D) & 0x8000) or bool(self.u.GetAsyncKeyState(0x1B) & 0x8000)
            if k and not self.key0:
                self.close_key = t
            self.key0 = k
            time.sleep(0.002)

    def at(self, t):
        """Cursor position at time t (between samples: in between; later than the last: the last)."""
        h = self.hist
        if not h:
            return None
        if t >= h[-1][0]:
            return h[-1][1], h[-1][2]
        for i in range(len(h) - 1, 0, -1):
            a, b = h[i - 1], h[i]
            if a[0] <= t <= b[0]:
                k = (t - a[0]) / max(1e-6, b[0] - a[0])
                return a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k
        return h[0][1], h[0][2]

    def down(self):
        return bool(self.hist) and self.hist[-1][3]


def _m3(m2):
    import numpy as np
    return np.vstack([m2, [0.0, 0.0, 1.0]])


def _exclude_capture(w):
    try:                                   # keep our own icons out of any screen copy
        import ctypes
        ctypes.windll.user32.SetWindowDisplayAffinity(int(w.winId()), 0x11)
    except Exception:
        pass


def ui_panels(small, np, cv2):
    """Game windows on top of the map (Change Map and the like): big, flat, dark boxes. [(x, y, w, h)]
    in small-frame px."""
    g = small.astype(np.float32)
    mu = cv2.blur(g, (10, 10))
    sd = np.sqrt(np.maximum(0, cv2.blur(g * g, (10, 10)) - mu * mu))
    m = ((sd < 5) & (mu < 70)).astype(np.uint8) * 255
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((9, 9), np.uint8))
    n, _lab, st, _c = cv2.connectedComponentsWithStats(m)
    k = small.shape[1] / 480
    out = []
    for i in range(1, n):
        x, y, w, h, a = st[i]
        if a > 2500 * k * k and a > 0.45 * w * h and w < 0.6 * small.shape[1] and h > 40 * k:
            e = 6 * k
            out.append((x - e, y - e, w + 2 * e, h + 2 * e))
    return out


# ------------------------------------------------------------------------------------------ big map ---- #
_SWP = 0x0001 | 0x0004 | 0x0010 | 0x4000          # NOSIZE | NOZORDER | NOACTIVATE | ASYNCWINDOWPOS


class SpriteLayer:
    """Pet icons as plain Windows layered windows, created, owned and moved by one render thread.
    All moves for a frame go in one batch right after the screen refresh, so every icon lands on the
    same frame and nothing waits on the overlay's main thread."""

    def __init__(self, on_click, log):
        import ctypes
        from ctypes import wintypes as W
        self.c, self.W, self.log, self.on_click = ctypes, W, log, on_click
        u, g, k = ctypes.windll.user32, ctypes.windll.gdi32, ctypes.windll.kernel32
        self.u, self.g = u, g
        LRESULT = ctypes.c_ssize_t
        self.WNDPROC = ctypes.WINFUNCTYPE(LRESULT, W.HWND, W.UINT, W.WPARAM, W.LPARAM)
        u.DefWindowProcW.restype = LRESULT
        u.DefWindowProcW.argtypes = [W.HWND, W.UINT, W.WPARAM, W.LPARAM]
        u.CreateWindowExW.restype = W.HWND
        u.CreateWindowExW.argtypes = [W.DWORD, W.LPCWSTR, W.LPCWSTR, W.DWORD, ctypes.c_int, ctypes.c_int,
                                      ctypes.c_int, ctypes.c_int, W.HWND, W.HMENU, W.HINSTANCE, W.LPVOID]
        u.BeginDeferWindowPos.restype = W.HANDLE
        u.DeferWindowPos.restype = W.HANDLE
        u.DeferWindowPos.argtypes = [W.HANDLE, W.HWND, W.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                     ctypes.c_int, W.UINT]
        u.EndDeferWindowPos.argtypes = [W.HANDLE]
        u.UpdateLayeredWindow.argtypes = [W.HWND, W.HDC, ctypes.c_void_p, ctypes.c_void_p, W.HDC,
                                          ctypes.c_void_p, W.DWORD, ctypes.c_void_p, W.DWORD]
        u.GetDC.restype = W.HDC
        g.CreateCompatibleDC.restype = W.HDC
        g.CreateDIBSection.restype = W.HBITMAP
        g.CreateDIBSection.argtypes = [W.HDC, ctypes.c_void_p, W.UINT, ctypes.POINTER(ctypes.c_void_p),
                                       W.HANDLE, W.DWORD]
        g.SelectObject.restype = W.HGDIOBJ
        g.SelectObject.argtypes = [W.HDC, W.HGDIOBJ]
        u.SetWindowDisplayAffinity.argtypes = [W.HWND, W.DWORD]
        u.SetCursor.argtypes = [W.HANDLE]
        u.ShowWindow.argtypes = [W.HWND, ctypes.c_int]
        u.DestroyWindow.argtypes = [W.HWND]
        u.ReleaseDC.argtypes = [W.HWND, W.HDC]
        u.GetDC.argtypes = [W.HWND]
        u.PeekMessageW.argtypes = [ctypes.POINTER(W.MSG), W.HWND, W.UINT, W.UINT, W.UINT]
        u.TranslateMessage.argtypes = [ctypes.POINTER(W.MSG)]
        u.DispatchMessageW.argtypes = [ctypes.POINTER(W.MSG)]
        u.RegisterClassExW.argtypes = [ctypes.c_void_p]
        g.CreateCompatibleDC.argtypes = [W.HDC]
        g.DeleteObject.argtypes = [W.HGDIOBJ]
        g.DeleteDC.argtypes = [W.HDC]
        k.GetModuleHandleW.restype = W.HMODULE
        k.GetModuleHandleW.argtypes = [W.LPCWSTR]
        u.LoadCursorW.restype = W.HANDLE
        u.LoadCursorW.argtypes = [W.HINSTANCE, ctypes.c_void_p]
        self.hand = u.LoadCursorW(None, ctypes.c_void_p(32649))
        self.hinst = k.GetModuleHandleW(None)

        def proc(hwnd, msg, wp, lp):
            if msg == 0x0021:                     # WM_MOUSEACTIVATE: never take focus from the game
                return 3
            if msg == 0x0020:                     # WM_SETCURSOR: a hand over the icon
                u.SetCursor(self.hand)
                return 1
            if msg == 0x0201:                     # left click
                self.on_click(hwnd)
                return 0
            return u.DefWindowProcW(hwnd, msg, wp, lp)
        self._proc = self.WNDPROC(proc)

        class WC(ctypes.Structure):
            _fields_ = [("cbSize", W.UINT), ("style", W.UINT), ("lpfnWndProc", self.WNDPROC), ("cbClsExtra", ctypes.c_int),
                        ("cbWndExtra", ctypes.c_int), ("hInstance", W.HINSTANCE), ("hIcon", W.HANDLE),
                        ("hCursor", W.HANDLE), ("hbrBackground", W.HANDLE), ("lpszMenuName", W.LPCWSTR),
                        ("lpszClassName", W.LPCWSTR), ("hIconSm", W.HANDLE)]
        wc = WC()
        wc.cbSize = ctypes.sizeof(WC)
        wc.lpfnWndProc = self._proc
        wc.hInstance = self.hinst
        wc.lpszClassName = "PetOverlaySprite"
        u.RegisterClassExW(ctypes.byref(wc))
        self.wins = {}                          # key -> (hwnd, w, h)
        self.err = ""
        self.at = {}                            # key -> (x, y) or None

    def pump(self):
        msg = self.W.MSG()
        while self.u.PeekMessageW(self.c.byref(msg), None, 0, 0, 1):
            self.u.TranslateMessage(self.c.byref(msg))
            self.u.DispatchMessageW(self.c.byref(msg))

    def build(self, specs):
        """specs: [(key, w, h, premultiplied BGRA bytes)]."""
        for hwnd, _w, _h in self.wins.values():
            self.u.DestroyWindow(hwnd)
        self.wins, self.at = {}, {}
        c, W, u, g = self.c, self.W, self.u, self.g
        sdc = u.GetDC(None)
        for key, w, h, data in specs:
            hwnd = u.CreateWindowExW(0x80000 | 0x8 | 0x80 | 0x8000000, "PetOverlaySprite", "", 0x80000000,
                                     -4000, -4000, w, h, None, None, self.hinst, None)
            if not hwnd:
                self.err = f"CreateWindow {c.windll.kernel32.GetLastError()}"
                continue
            u.SetWindowDisplayAffinity(hwnd, 0x11)      # never in screen copies (ours or anyone's)
            mdc = g.CreateCompatibleDC(sdc)
            bi = (c.c_byte * 44)()
            c.memmove(bi, c.pointer(c.c_int32(40)), 4)
            hdr = (c.c_int32 * 3)(w, -h, 0)
            c.memmove(c.addressof(bi) + 4, hdr, 8)
            c.memmove(c.addressof(bi) + 12, (c.c_uint16 * 2)(1, 32), 4)
            bits = c.c_void_p()
            bmp = g.CreateDIBSection(mdc, bi, 0, c.byref(bits), None, 0)
            c.memmove(bits, data, w * h * 4)
            old = g.SelectObject(mdc, bmp)
            size = (c.c_int32 * 2)(w, h)
            src = (c.c_int32 * 2)(0, 0)
            pos = (c.c_int32 * 2)(-4000, -4000)
            blend = (c.c_ubyte * 4)(0, 0, 255, 1)        # AC_SRC_OVER, alpha from the pixels
            if not u.UpdateLayeredWindow(hwnd, sdc, pos, size, mdc, src, 0, blend, 2):
                self.err = f"UpdateLayeredWindow {c.windll.kernel32.GetLastError()}"
            g.SelectObject(mdc, old)
            g.DeleteObject(bmp)
            g.DeleteDC(mdc)
            u.ShowWindow(hwnd, 4)                         # SW_SHOWNOACTIVATE
            self.wins[key] = (hwnd, w, h)
            self.at[key] = None
        u.ReleaseDC(None, sdc)

    def alpha(self, a):
        """Opacity of every icon (0-255), only when it changed."""
        if a == getattr(self, "_a", None):
            return
        self._a = a
        blend = (self.c.c_ubyte * 4)(0, 0, a, 1)
        for k, (hwnd, w, h) in self.wins.items():
            if self.at.get(k):
                self.u.UpdateLayeredWindow(hwnd, None, None, None, None, None, 0, blend, 2)

    def move(self, places):
        """places: {key: (x, y) or None}. One batch, applied together."""
        changed = [(k, v) for k, v in places.items() if k in self.wins and self.at.get(k) != v]
        if not changed:
            return
        u = self.u
        hdwp = u.BeginDeferWindowPos(len(changed))
        for k, v in changed:
            hwnd, w, h = self.wins[k]
            x, y = v if v else (-4000, -4000)
            hdwp = u.DeferWindowPos(hdwp, hwnd, None, int(x), int(y), 0, 0, 0x0001 | 0x0004 | 0x0010)
            if v and not self.at.get(k):
                self._a = None                                # re-apply alpha to the newly shown one
            self.at[k] = v
        if hdwp:
            u.EndDeferWindowPos(hdwp)
        else:
            self.err = f"DeferWindowPos {self.c.windll.kernel32.GetLastError()}"


def draw_pin(p, cx, cy, r, col):
    """Small map-pin glyph."""
    path = QPainterPath()
    path.moveTo(cx, cy + r * 1.25)
    path.cubicTo(cx - r * 1.3, cy - r * 0.1, cx - r * 0.9, cy - r * 1.25, cx, cy - r * 1.25)
    path.cubicTo(cx + r * 0.9, cy - r * 1.25, cx + r * 1.3, cy - r * 0.1, cx, cy + r * 1.25)
    p.setPen(Qt.NoPen)
    p.setBrush(col)
    p.drawPath(path)
    p.setBrush(QColor(0, 0, 0, 120))
    p.drawEllipse(QPointF(cx, cy - r * 0.35), r * 0.38, r * 0.38)


def patches(points, cell=7000):
    """Every separate spawn patch of a pet: [(x, y, n)] (spawn points grouped ~70 m apart)."""
    groups = {}
    for x, y in points:
        g = groups.setdefault((int(x // cell), int(y // cell)), [0, 0, 0])
        g[0] += x
        g[1] += y
        g[2] += 1
    return [(gx / n, gy / n, n) for gx, gy, n in groups.values()]


class MapView(QWidget):
    """Layer over the game's big map with pet spawns, kept in sync like this:
    - a worker thread copies the screen as soon as it changes and follows the map's motion frame to frame
      (optical flow: sub-pixel, a few ms);
    - a second thread matches the whole picture against the region map a few times a second, only to
      find it and to cancel any drift;
    - drawing predicts a frame ahead from the current pan / zoom speed, so the icons arrive on screen
      together with the map instead of one frame behind it.
    Click an icon (or a pile of them) for a card with each pet's details."""
    SMALL, BIG, LEAD = 480, 960, 0.016

    def __init__(self, app_dir, data, log, icon_for, want_pets, info_for, enabled, capture):
        super().__init__()
        self.app_dir, self.data, self.log = Path(app_dir), data, log
        self.icon_for, self.want_pets, self.info_for, self.enabled = icon_for, want_pets, info_for, enabled
        self.cap = capture
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool | Qt.WindowDoesNotAcceptFocus)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.setMouseTracking(True)
        self.points, self.points_m, self.kibnum = {}, 0, {}
        self.matcher, self.ready = None, False
        self.state = "off"
        self.active, self.rect = False, None
        self.A, self.world, self.panel, self.panels = None, None, False, []
        self.motion = None                 # (M cur->prev, capture time, frame interval)
        self.ver, self.painted, self.seen_t = 0, -1, 0.0
        self.hint, self.last_world, self.miss = None, None, 0
        self.R, self.pending, self.result = None, False, None
        self.next_match = 0.0
        self.prev, self.fps, self.nframe = None, 0.0, 0
        self.op = 0.0
        self.thread = None
        self.hits, self.card, self.card_hits, self.hover = [], None, [], False
        self.cursor = Cursor()
        self.mode = "smooth"                       # icons as sprite windows (the only mode)
        import collections
        self.sprite_specs, self.sprite_key, self.switch_rect = None, None, None
        self.set_enabled = None
        self.click_q = collections.deque()
        self.hidden_until = 0.0
        threading.Thread(target=self._render, daemon=True).start()
        try:
            self.pin = tuple(json.loads((self.app_dir / "maps" / "pin.json").read_text())) or None
        except (OSError, ValueError, TypeError):
            self.pin = None                        # (world, pet name, x, y) shown on the minimap
        self.lag, self.gain, self.tau = 0.03, 1.0, 0.0   # learned: delay, ratio and smoothing of the game's drag
        self.drag_samples, self.own_press = [], False
        self.base_t = 0.0
        self.timer = QTimer(self)
        self.timer.setTimerType(Qt.PreciseTimer)
        self.timer.setInterval(7)
        self.timer.timeout.connect(self._frame)

    def showEvent(self, e):
        super().showEvent(e)
        _exclude_capture(self)

    def _load_points(self):
        p = self.app_dir / "maps" / "live_points.json"
        try:
            m = p.stat().st_mtime
            if m != self.points_m:
                self.points, self.points_m = json.loads(p.read_text(encoding="utf-8")), m
            if not self.kibnum:
                d = json.loads((self.app_dir / "pet_spawns.json").read_text(encoding="utf-8"))
                self.kibnum = d.get("kib_numbers", {})
        except (OSError, ValueError):
            pass

    def status(self):
        z = self._zoom(self.A) if self.A is not None else 0
        extra = f"  world {self.world}  zoom {z:.2f}  {self.fps:.0f} fps  {self.cap.kind}  " \
                f"drag lag {self.lag * 1000:.0f} ms x{self.gain:.2f}" \
            if self.state == "showing" else ""
        layer = getattr(self, "layer", None)
        n = len(layer.wins) if layer else 0
        vis = sum(1 for v in layer.at.values() if v) if layer else 0
        return self.state + extra + f"  icons {vis}/{n}" + (f"  layer error {layer.err}" if layer and layer.err else "")

    def _zoom(self, A):
        r = self.rect
        if A is None or not r:
            return 0
        return 1 / max(1e-12, math.hypot(A[0, 0], A[1, 0])) / max(1, r[2])

    # ---------------------------------------------------- main thread ---- #
    def setup(self):
        if self.ready:
            return True
        if not ensure_cv(self.app_dir, self.log):
            self.state = "no opencv"
            return False
        self._load_points()
        try:
            self.matcher = Matcher(self.app_dir / "maps", self.log)
        except Exception as e:
            self.log(f"map overlay: {e}")
            self.state = "no opencv"
            return False
        self.ready = True
        return True

    def tick(self, game_fg, hwnd, covered, rect):
        """~10 times a second from the main loop: whether to run, and where the game is."""
        on = bool(game_fg and covered and rect and rect[2] > 400) and self.setup()
        if on and (not self.points or not self.matcher.worlds()):
            self._load_points()
            self.state = "no maps"
            on = False
        if on:
            self.rect = tuple(rect)
            if not self.active:
                self.active, self.next_match = True, 0.0
                self.wake_t = time.time()               # back (alt-tab): trust the map until it changes
                if self.thread is None or not self.thread.is_alive():
                    self.thread = threading.Thread(target=self._run, daemon=True)
                    self.thread.start()
            if not self.timer.isActive():
                self.timer.start()
        elif self.active:
            self.active, self.card = False, None
            if self.state == "showing":
                self.state = "idle"

    def _outside_clicks(self):
        """A click anywhere that isn't the card or a pet icon closes the card."""
        pr, r = self.cursor.presses, self.rect
        while pr:
            _t, x, y = pr.popleft()
            if self.card and r:
                lx, ly = x - r[0], y - r[1]
                on_card = self.card.get("rect") is not None and self.card["rect"].contains(QPointF(lx, ly))
                on_icon = any(math.hypot(h[0] - lx, h[1] - ly) <= h[2] * 1.25 for h in self.hits) or \
                    any(math.hypot(v[0] + w / 2 - x, v[1] + w / 2 - y) <= w / 2 for _k, v, w in self._sprite_places())
                if not on_card and not on_icon:
                    self.card = None
                    self.update()

    # ------------------------------------------------- smooth (sprites) ---- #
    def _sync_sprites(self):
        """(GUI thread) draw one icon picture per spawn group of the pets you still need; the render
        thread turns them into windows."""
        want = self.want_pets()
        key = (self.world, tuple(sorted(want)), self.mode, self.rect[2] if self.rect else 0)
        if key == self.sprite_key:
            return
        self.sprite_key = key
        pts = self.points.get(self.world) if self.world else None
        specs = []
        if self.mode == "smooth" and pts and self.rect:
            from PySide6.QtGui import QImage
            s = max(0.7, min(1.6, self.rect[2] / 1920))
            sz = 26 * s
            side = int(sz + 6 * s)
            for name, e in pts.get("pets", {}).items():
                if name not in want:
                    continue
                ring = QColor(GENUS_COL.get(e.get("g"), "#D7DCE6"))
                img = QImage(side, side, QImage.Format_ARGB32_Premultiplied)
                img.fill(0)
                p = QPainter(img)
                p.setRenderHint(QPainter.Antialiasing)
                p.setRenderHint(QPainter.SmoothPixmapTransform)
                MapView._pet_icon(p, QRectF(3 * s, 3 * s, sz, sz), self.icon_for(name), ring, s)
                p.end()
                data = bytes(img.constBits())[:side * side * 4]
                for ci, (x, y, n) in enumerate(e.get("c", [])):
                    specs.append(((name, (x, y), ci), side, side, data))
        self.sprite_specs = (self.sprite_specs[0] + 1 if self.sprite_specs else 1, specs)

    def _on_sprite_click(self, hwnd):          # render thread: hand it to the GUI thread
        self.click_q.append(hwnd)

    def _render(self):
        """Render thread for smooth mode: owns the icon windows; right after each screen refresh it moves
        all of them, in one batch, to where the map will be when the next refresh shows it."""
        import ctypes
        try:
            dwm = ctypes.windll.dwmapi
            layer = SpriteLayer(self._on_sprite_click, self.log)
        except Exception as e:
            self.log(f"map overlay: smooth mode unavailable: {e}")
            return
        self.layer = layer
        built = 0
        while True:
            try:
                if dwm.DwmFlush() != 0:
                    time.sleep(0.008)
            except Exception:
                time.sleep(0.008)
            try:
                layer.pump()
                spec = self.sprite_specs
                if spec and spec[0] != built:
                    built = spec[0]
                    layer.build(spec[1])
                if not layer.wins:
                    continue
                show = self.mode == "smooth" and self.active and self.A is not None and self.enabled() and \
                    time.time() >= self.hidden_until and time.time() - self.seen_t < 0.5
                # fade: out quickly while the map moves, back in once it has settled
                tgt = 1.0 if show and not self.moving() else 0.0
                fop = getattr(self, "fop", 0.0)
                fop = min(tgt, fop + 0.016 / 0.18) if tgt > fop else max(tgt, fop - 0.016 / 0.10)
                self.fop = fop
                show = show and fop > 0.01
                A = self._predicted(0.014) if show else None
                pts = self.points.get(self.world) if A is not None else None
                places = {}
                if pts:
                    np = self.matcher.np
                    Ai = np.linalg.inv(A)
                    r = self.rect
                    gx0, gx1, gy0, gy1 = pts["bounds"]
                    left, top = r[2] * (0.3 if self.panel else 0), r[3] * 0.07
                    panels = self.panels
                    for k, (hwnd, w, h) in layer.wins.items():
                        x, y = k[1]
                        uu, vv = (x - gx0) / (gx1 - gx0), (y - gy0) / (gy1 - gy0)
                        X = Ai[0, 0] * uu + Ai[0, 1] * vv + Ai[0, 2]
                        Y = Ai[1, 0] * uu + Ai[1, 1] * vv + Ai[1, 2]
                        ok = left <= X <= r[2] and top <= Y <= r[3] and \
                            not any(px <= X <= px + pw and py <= Y <= py + ph for px, py, pw, ph in panels)
                        places[k] = (round(r[0] + X - w / 2), round(r[1] + Y - h / 2)) if ok else None
                else:
                    places = {k: None for k in layer.wins}
                layer.move(places)
                layer.alpha(int(255 * getattr(self, "fop", 1.0)))
            except Exception as e:
                self.log(f"map overlay: {e}")
                time.sleep(0.5)

    def _sprite_places(self):
        layer = getattr(self, "layer", None)
        return [(k, v, layer.wins[k][1]) for k, v in list(layer.at.items()) if v and k in layer.wins] if layer else []

    def sprite_click(self, hwnd):
        """Clicked an icon: card for it and any others under the same spot."""
        layer = getattr(self, "layer", None)
        key = next((k for k, (h, _w, _h) in list(layer.wins.items()) if h == hwnd), None) if layer else None
        at = layer.at.get(key) if key else None
        if not at:
            return
        side = layer.wins[key][1]
        near = sorted((k for k, v, w in self._sprite_places() if math.hypot(v[0] - at[0], v[1] - at[1]) < side * 0.9),
                      key=lambda k: math.hypot(layer.at[k][0] - at[0], layer.at[k][1] - at[1]))
        names = [(k[0], k[1], k[2]) for k in near][:6]
        same = self.card and [(n[0], n[2]) for n in self.card["pets"]] == [(n[0], n[2]) for n in names]
        self.card = None if same else {"pets": names, "at": names[0][1], "t": time.time()}
        self.own_press = False
        self.update()

    def set_mode(self, mode):
        self.mode = mode
        self.sprite_key = None
        try:
            (self.app_dir / "maps" / "mapmode.json").write_text(json.dumps({"mode": mode}))
        except OSError:
            pass
        self.update()

    def _frame(self):
        self.cursor.on = self.active
        if self.active and self.cursor.close_key > self.hidden_until - 0.6 and \
                time.time() - self.cursor.close_key < 0.3 and self.A is not None:
            self.hidden_until = time.time() + 0.6           # M / Esc: gone this very frame, no fade
            self.op, self.card = 0.0, None
            self.A, self.prev = None, None
        if time.time() < self.hidden_until:
            if self.isVisible():
                self.hide()
            return
        if self.active and self.world:
            self._sync_sprites()
        while self.click_q:
            self.sprite_click(self.click_q.popleft())
        live = self.active and self.A is not None and time.time() - self.seen_t < 0.5
        self.op = min(1.0, self.op + 0.07) if live else max(0.0, self.op - 0.09)
        if self.op > 0:
            r = self.rect
            if r and self.geometry().getRect() != r:
                self.setGeometry(*r)
            if not self.isVisible():
                self.show()
            self._outside_clicks()
            if self.mode == "classic" and (self.ver != self.painted or self.op < 1 or self._dragging()):
                self.update()
            elif self.mode == "smooth" and (self.op < 1 or self.ver != self.painted or
                                            (self.card and 0 < getattr(self, "fop", 1) < 1)):
                self.update()
        else:
            if self.isVisible():
                self.hide()
            if not self.active:
                self.timer.stop()

    def moving(self):
        """The map is being dragged or zoomed (icons fade out until it settles)."""
        return self._dragging() or time.time() - getattr(self, "moved_t", 0) < 0.12

    def _dragging(self):
        r = self.rect
        h = self.cursor.hist
        if not h or not h[-1][3] or self.own_press or not r:
            return False
        if not self.cursor.last_press:
            return False
        _t, x, y = self.cursor.last_press
        lx, ly = x - r[0], y - r[1]
        if not (0 <= lx < r[2] and 0 <= ly < r[3]) or lx < r[2] * (0.3 if self.panel else 0):
            return False
        return not any(px <= lx <= px + pw and py <= ly <= py + ph for px, py, pw, ph in self.panels)

    def _follow(self, t, L, tau):
        """Where the game's map would have moved to by time t (screen px), given the mouse history:
        the mouse delayed by L and smoothed with time constant tau."""
        h = self.cursor.hist
        if not h:
            return None
        t = t - L
        y = None
        tp = None
        for (ts, x, yy, _d) in h:
            if ts - t > 0:
                break
            if y is None or tau <= 0:
                y = [x, yy]
            else:
                k = 1 - math.exp(-(ts - tp) / tau)
                y[0] += (x - y[0]) * k
                y[1] += (yy - y[1]) * k
            tp = ts
        if y is None:
            return None
        if tau > 0 and tp is not None and t > tp:          # past the last sample: keep easing toward it
            last = h[-1]
            k = 1 - math.exp(-(t - tp) / tau)
            y = [y[0] + (last[1] - y[0]) * k, y[1] + (last[2] - y[1]) * k]
        return y

    def _predicted(self, ahead=0.010):
        """Where the map is on screen right now. While you drag it, it moves exactly with your mouse
        (as the game's map does, with the same small delay the game has); otherwise it's where the last
        screen copy saw it. No guessing from speed, so nothing overshoots."""
        np = self.matcher.np
        A = self.A
        if A is None:
            return None
        if self.gain > 0.3 and self._dragging():
            now = time.time() + ahead                 # this frame reaches the screen a little later
            a = self._follow(now, self.lag, self.tau)
            b = self._follow(self.base_t, self.lag, self.tau)
            if a and b:
                dx, dy = (a[0] - b[0]) * self.gain, (a[1] - b[1]) * self.gain
                if abs(dx) + abs(dy) > 0.2:
                    T = np.array([[1.0, 0, -dx], [0, 1.0, -dy], [0, 0, 1.0]])
                    A = A @ T
        return A

    def _learn_drag(self):
        """Fit the game's drag delay, smoothing and ratio from what the screen copies saw vs the mouse."""
        np = self.matcher.np
        sm = self.drag_samples[-90:]
        h = list(self.cursor.hist)
        if len(sm) < 30 or len(h) < 50:
            return
        T = np.array([q[0] for q in h])
        X = np.array([q[1] for q in h], float)
        Y = np.array([q[2] for q in h], float)
        t0 = np.array([q[0] for q in sm])
        t1 = np.array([q[1] for q in sm])
        mx = np.array([q[2] for q in sm])
        my = np.array([q[3] for q in sm])
        best = None
        for tau in (0.0, 0.012, 0.025, 0.04, 0.06, 0.09):
            fx, fy = X.copy(), Y.copy()
            if tau > 0:                                       # the smoothed mouse path
                dt = np.diff(T, prepend=T[0])
                k = 1 - np.exp(-dt / tau)
                for i in range(1, len(fx)):
                    fx[i] = fx[i - 1] + (X[i] - fx[i - 1]) * k[i]
                    fy[i] = fy[i - 1] + (Y[i] - fy[i - 1]) * k[i]
            for L in [i * 0.004 for i in range(0, 16)]:
                cx = np.interp(t1 - L, T, fx) - np.interp(t0 - L, T, fx)
                cy = np.interp(t1 - L, T, fy) - np.interp(t0 - L, T, fy)
                den = float((cx * cx + cy * cy).sum())
                if den < 400:
                    continue
                g = float((cx * mx + cy * my).sum()) / den
                err = float(((mx - g * cx) ** 2 + (my - g * cy) ** 2).sum())
                if best is None or err < best[0]:
                    best = (err, L, g, tau)
        if best:
            _e, self.lag, self.gain, self.tau = best
        self.drag_samples = self.drag_samples[-60:]

    def _run(self):
        cv2, np = self.matcher.cv2, self.matcher.np
        last_t = None
        while True:
            if not self.active:
                self.motion, self.miss = None, 0            # keep A and the last frame: back from alt-tab,
                time.sleep(0.05)                            # the first new frame confirms it at once
                continue
            try:
                rect = self.rect
                t_cap = time.time()
                full = self.cap.grab(rect, np, cv2)
                if full is None:                          # nothing changed on screen: still right
                    if self.motion is not None and t_cap - self.motion[1] > 0.05:
                        self.motion = None
                    if self.A is not None and self.prev is not None and \
                            (t_cap - self.seen_t < 5 or t_cap - getattr(self, "wake_t", 0) < 2):
                        self.seen_t = t_cap
                    lf = getattr(self, "last_full", None)
                    if self.A is None and lf is not None and not self.pending and t_cap >= self.next_match:
                        bh = max(2, int(self.BIG * rect[3] / rect[2]))
                        big = cv2.resize(lf, (self.BIG, bh), interpolation=cv2.INTER_AREA)
                        self.pending, self.R = True, np.eye(3)
                        threading.Thread(target=self._match, args=(big, rect), daemon=True).start()
                    time.sleep(0.002)
                    continue
                self.last_full = full
                sh = max(2, int(self.SMALL * rect[3] / rect[2]))
                small = cv2.resize(full, (self.SMALL, sh), interpolation=cv2.INTER_AREA)
                f = rect[2] / self.SMALL
                self.nframe += 1
                if self.nframe % 6 == 1:
                    self.panels = [tuple(v * f for v in r) for r in ui_panels(small, np, cv2)]
                if (self.A is not None or self.pending) and self.prev is not None and self.prev.shape == small.shape:
                    M = self._flow(self.prev, small, f)
                    if M is not None:
                        if self.R is not None:
                            self.R = self.R @ M
                        if self.A is not None:
                            self.A = self.A @ M
                            self.base_t = t_cap
                            self.miss = 0
                            dt = (t_cap - last_t) if last_t else 0.016
                            self.motion = (M, t_cap, min(0.05, max(0.004, dt)))
                            if abs(M[0, 0] - 1) > 0.0015 or abs(M[0, 2]) + abs(M[1, 2]) > 1.5:
                                self.moved_t = t_cap
                            if last_t and self._dragging() and abs(M[0, 0] - 1) < 0.002:
                                self.drag_samples.append((last_t, t_cap, -M[0, 2], -M[1, 2]))
                                if len(self.drag_samples) % 30 == 0:
                                    self._learn_drag()
                            self._publish()
                    elif self.A is not None:
                        self.miss += 1
                        if self.miss > 6:                  # lost it (map closed, region switched...)
                            self.hint, self.A, self.motion, self.card = self.A, None, None, None
                    else:
                        self.R = None
                self.prev, last_t = small, t_cap
                res, self.result = self.result, None
                if res is not None:
                    self._correct(res)
                if not self.pending and t_cap >= self.next_match:
                    bh = max(2, int(self.BIG * rect[3] / rect[2]))
                    big = cv2.resize(full, (self.BIG, bh), interpolation=cv2.INTER_AREA)
                    self.pending, self.R = True, np.eye(3)
                    threading.Thread(target=self._match, args=(big, rect), daemon=True).start()
                self.fps = 0.92 * self.fps + 0.08 / max(1e-3, time.time() - t_cap + 0.0001) if False else \
                    0.92 * self.fps + 0.08 * (1 / max(1e-3, t_cap - getattr(self, "_fps_t", t_cap - 0.016)))
                self._fps_t = t_cap
                if self.cap.kind == "gdi":
                    time.sleep(0.004)
            except Exception as e:
                self.log(f"map overlay: {e}")
                time.sleep(0.5)

    def _flow(self, prev, cur, f):
        """How the map moved between two frames: 3x3 (current window px -> previous window px) or None."""
        cv2, np = self.matcher.cv2, self.matcher.np
        h, w = prev.shape
        if cv2.norm(prev, cur, cv2.NORM_L1) < 0.6 * w * h:      # practically the same picture
            return np.eye(3)
        mask = np.zeros_like(prev)
        mask[int(h * 0.1):int(h * 0.93), int(w * (0.3 if self.panel else 0.02)):int(w * 0.95)] = 255
        for x, y, ww, hh in self.panels:                           # not on game windows over the map
            mask[max(0, int(y / f)):int((y + hh) / f), max(0, int(x / f)):int((x + ww) / f)] = 0
        p0 = cv2.goodFeaturesToTrack(prev, 260, 0.01, 6, mask=mask, blockSize=5)
        if p0 is None or len(p0) < 25:
            return None
        lk = dict(winSize=(21, 21), maxLevel=3, criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 20, 0.03))
        p1, st, _ = cv2.calcOpticalFlowPyrLK(prev, cur, p0, None, **lk)
        back, st2, _ = cv2.calcOpticalFlowPyrLK(cur, prev, p1, None, **lk)
        ok = (st.ravel() == 1) & (st2.ravel() == 1) & (np.abs(back - p0).reshape(-1, 2).max(1) < 0.8)
        if ok.sum() < 20:
            return None
        M, inl = cv2.estimateAffinePartial2D(p1[ok], p0[ok], method=cv2.RANSAC, ransacReprojThreshold=1.0)
        if M is None or inl is None or inl.sum() < 18:
            return None
        sc = math.hypot(M[0, 0], M[1, 0])
        if abs(math.atan2(M[1, 0], M[0, 0])) > 0.02 or not 0.6 < sc < 1.7:
            return None
        M = M.astype(np.float64)
        if abs(sc - 1) < 0.003:                         # just a pan: no zoom / turn noise at all
            d = np.median((p0[ok] - p1[ok]).reshape(-1, 2)[inl.ravel() == 1], axis=0)
            M = np.array([[1.0, 0, d[0]], [0, 1.0, d[1]]])
        M[:, 2] *= f
        return _m3(M)

    def _match(self, big, rect):
        np = self.matcher.np
        try:
            k = self.BIG / rect[2]
            S = np.diag([k, k, 1.0])
            cur = self.A if self.A is not None else self.hint
            prev2 = (cur @ np.linalg.inv(S))[:2] if cur is not None else None
            order = []
            if prev2 is not None and (self.world or self.last_world):
                order.append((self.world or self.last_world, prev2))
            wl = self.data.world
            for c in ([str(wl)] if wl is not None else []) + ([self.last_world] if self.last_world else []) + \
                    self.matcher.worlds():
                if c and c in self.points and c not in [o[0] for o in order if o[1] is None]:
                    order.append((c, None))
            if self.A is None and self.miss % 4 and len(order) > 2:
                order = order[:2]
            H, w = None, None
            for c, pv in order:
                H = self.matcher.match(big, c, pv)
                if H is not None:
                    w = c
                    break
                if self.A is not None:
                    break
            if H is None:
                if self.A is None:
                    self.miss += 1
                    self.state = "looking"
                    self.next_match = time.time() + (0.3 if self.miss < 8 else 0.9)
                else:
                    self.next_match = time.time() + 0.3
                return
            col = big[int(big.shape[0] * 0.2):int(big.shape[0] * 0.8), int(big.shape[1] * 0.15)]
            self.panel = float(col.mean()) < 70 and float(col.std()) < 30
            self.result = (w, _m3(H) @ S)
            self.next_match = time.time() + 0.35
        except Exception as e:
            self.log(f"map overlay: {e}")
            self.next_match = time.time() + 1.0
        finally:
            self.pending = False

    def _correct(self, res):
        np = self.matcher.np
        w, Hk = res
        if self.R is None:
            return
        new = Hk @ self.R
        if self.A is None or w != self.world:
            self.A, self.card = new, None
        else:
            r = self.rect
            c = np.array([r[2] / 2, r[3] / 2, 1.0])
            a, b = self.A @ c, new @ c
            px = np.hypot(*(a - b)[:2]) / max(1e-12, math.hypot(self.A[0, 0], self.A[1, 0]))
            if px > 25:
                self.A, self.card = new, None
            elif px > 1.2:
                self.A = self.A + (new - self.A) * 0.2
        self.world, self.last_world, self.miss = w, w, 0
        self.state = "showing"
        self._publish()

    def _publish(self):
        self.seen_t = time.time()
        self.ver += 1

    # ----------------------------------------------------------- clicks ---- #
    def mouseReleaseEvent(self, e):
        self.own_press = False
        drag, self._sw_drag = getattr(self, "_sw_drag", None), None
        if drag is None:
            return
        if not drag[2]:                                   # a click, not a drag: switch pets on/off
            if self.set_enabled:
                self.set_enabled(not self.enabled())
            self.card = None
        else:
            try:
                (self.app_dir / "maps" / self.SWITCH_PATH).write_text(json.dumps(list(self._sw_pos)))
            except OSError:
                pass
        self.setCursor(Qt.OpenHandCursor)
        self.ver += 1
        self.update()

    def mousePressEvent(self, e):
        self.own_press = True
        pos = e.position()
        if self.switch_rect and self.switch_rect.contains(pos):
            c = self.switch_rect.center()
            self._sw_drag = (pos.x() - c.x(), pos.y() - c.y(), False, pos.x(), pos.y())
            return

        for r, fn in self.card_hits:
            if r.contains(pos):
                fn()
                self.update()
                return
        if self.card and self.card.get("rect") and self.card["rect"].contains(pos):
            return
        near = [h for h in self.hits if math.hypot(h[0] - pos.x(), h[1] - pos.y()) <= h[2] * 1.25]
        if near:
            names = []
            for h in sorted(near, key=lambda h: math.hypot(h[0] - pos.x(), h[1] - pos.y())):
                if (h[3], h[5]) not in [(n[0], n[2]) for n in names]:
                    names.append((h[3], h[4], h[5]))
            same = self.card and [(n[0], n[2]) for n in self.card["pets"]] == [(n[0], n[2]) for n in names]
            self.card = None if same else {"pets": names[:6], "at": names[0][1], "t": time.time()}
        else:
            self.card = None
        self.update()

    def mouseMoveEvent(self, e):
        pos = e.position()
        drag = getattr(self, "_sw_drag", None)
        if drag is not None:                              # dragging the pill
            moved = drag[2] or math.hypot(pos.x() - drag[3], pos.y() - drag[4]) > 4
            if moved:
                self._sw_drag = drag[:2] + (True,) + drag[3:]
                W, Hh = max(1, self.width()), max(1, self.height())
                self._sw_pos = ((pos.x() - drag[0]) / W, (pos.y() - drag[1]) / Hh)
                self.setCursor(Qt.ClosedHandCursor)
                self.ver += 1
                self.update()
            return
        if self.switch_rect and self.switch_rect.contains(pos):
            if not self.hover:
                self.hover = True
            self.setCursor(Qt.OpenHandCursor)
            return
        over = any(math.hypot(h[0] - pos.x(), h[1] - pos.y()) <= h[2] * 1.25 for h in self.hits) or \
            any(r.contains(pos) for r, _ in self.card_hits)
        if over != self.hover:
            self.hover = over
            self.setCursor(Qt.PointingHandCursor if over else Qt.ArrowCursor)

    # ----------------------------------------------------------- paint ---- #
    def paintEvent(self, _):
        A, w, rect = self._predicted(), self.world, self.rect
        self.hits, self.card_hits = [], []
        if A is None or not rect:
            return
        np = self.matcher.np
        Ai = np.linalg.inv(A)
        self.painted = self.ver
        zoom = self._zoom(A)
        pts = self.points.get(w)
        if not pts:
            return
        from ui import font, text, rr, draw_icon
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        p.setOpacity(self.op)
        W, Hh = rect[2], rect[3]
        reg = QRegion(int(W * (0.3 if self.panel else 0)), int(Hh * 0.07), W, Hh)
        for x, y, ww, hh in self.panels:
            reg = reg.subtracted(QRegion(int(x), int(y), int(ww), int(hh)))
        p.setClipRegion(reg)
        gx0, gx1, gy0, gy1 = pts["bounds"]

        def to(x, y):
            u, vv = (x - gx0) / (gx1 - gx0), (y - gy0) / (gy1 - gy0)
            return Ai[0, 0] * u + Ai[0, 1] * vv + Ai[0, 2], Ai[1, 0] * u + Ai[1, 1] * vv + Ai[1, 2]
        s = max(0.7, min(1.6, W / 1920))
        want = self.want_pets()
        pets = [(n, e) for n, e in pts.get("pets", {}).items() if n in want]
        dot = max(2.0, min(4.0, 1.5 + zoom * 0.4)) * s
        if self.mode == "smooth":
            pets = []                                     # the sprites draw the icons
        for name, e in pets:                              # spawn points, one batch per pet
            c = QColor(GENUS_COL.get(e.get("g"), "#D7DCE6"))
            c.setAlpha(170)
            pen = QPen(c, dot * 2, Qt.SolidLine, Qt.RoundCap)
            p.setPen(pen)
            vis = []
            for x, y in e["p"]:
                X, Y = to(x, y)
                if -10 <= X <= W + 10 and -10 <= Y <= Hh + 10:
                    vis.append(QPointF(X, Y))
            if vis:
                p.drawPoints(vis)
        sz = 26 * s
        f = font(10.5 * s, 600)
        for name, e in pets:
            ring = QColor(GENUS_COL.get(e.get("g"), "#D7DCE6"))
            pix = self.icon_for(name)
            for ci, (x, y, n) in enumerate(e.get("c", [])):
                X, Y = to(x, y)
                if not (-sz <= X <= W + sz and -sz <= Y <= Hh + sz) or not reg.contains(QPointF(X, Y).toPoint()):
                    continue
                self.hits.append((X, Y, sz / 2, name, (x, y), ci))
                self._pet_icon(p, QRectF(X - sz / 2, Y - sz / 2, sz, sz), pix, ring, s)
                if zoom > 3.0:
                    for dx, dy, col in ((1, 1, QColor(0, 0, 0, 220)), (0, 0, QColor(255, 255, 255, 235))):
                        text(p, X + dx, Y + sz / 2 + 13 * s + dy, name, f, col, align="c")
        if self.card and self.enabled():
            p.save()
            p.setOpacity(self.op * getattr(self, "fop", 1.0))     # the card fades with the icons
            self._paint_card(p, s, to, pts, W, Hh, font, text, rr, draw_icon)
            p.restore()
        self._paint_switch(p, s, W, Hh, font, text, rr)
        p.end()

    SWITCH_PATH = "switch.json"

    def _game_icon(self, name):
        cache = self.__dict__.setdefault("_gicons", {})
        if name not in cache:
            from PySide6.QtGui import QPixmap
            pm = QPixmap(str(self.app_dir / "ui_icons" / f"{name}.png"))
            cache[name] = None if pm.isNull() else pm
        return cache[name]

    def switch_pos(self):
        """Where the pill sits, as a fraction of the map window (you can drag it anywhere)."""
        if not hasattr(self, "_sw_pos"):
            try:
                v = json.loads((self.app_dir / "maps" / self.SWITCH_PATH).read_text())
                self._sw_pos = (float(v[0]), float(v[1]))
            except (OSError, ValueError, IndexError, TypeError):
                self._sw_pos = (0.86, 0.105)
        return self._sw_pos

    def _paint_switch(self, p, s, W, Hh, font, text, rr):
        """Pets on/off pill on the map: a paw, the word, and a small sliding knob."""
        on = self.enabled()
        t = time.time()
        k = getattr(self, "_sw_k", 1.0 if on else 0.0)        # animated knob position
        k += ((1.0 if on else 0.0) - k) * min(1.0, (t - getattr(self, "_sw_t", t)) / 0.12 + 0.25)
        self._sw_k, self._sw_t = k, t
        p.save()
        p.setClipping(False)
        f = font(10.5 * s, 600)
        w, h = 104 * s, 28 * s
        fx, fy = self.switch_pos()
        x = min(max(4 * s, fx * W - w / 2), W - w - 4 * s)
        y = min(max(4 * s, fy * Hh - h / 2), Hh - h - 4 * s)
        r = QRectF(x, y, w, h)
        self.switch_rect = r
        rr(p, r, h / 2, QColor(14, 17, 24, 215))
        pet_pix = self._game_icon("tab_pets")
        if pet_pix is not None:                         # the game's pet icon
            p.save()
            p.setRenderHint(QPainter.SmoothPixmapTransform)
            p.setOpacity(p.opacity() * (1.0 if on else 0.45))
            p.drawPixmap(QRectF(x + 8 * s, y + 4 * s, 20 * s, 20 * s), pet_pix, QRectF(pet_pix.rect()))
            p.restore()
        else:
            from ui import draw_icon
            draw_icon(p, "pets", x + 10 * s, y + 6 * s, 16 * s, QColor(255, 255, 255, 235) if on else QColor("#7D8698"))
        text(p, x + 31 * s, y + 18.5 * s, "Pets", f, QColor(255, 255, 255, 235) if on else QColor("#A9B1C2"))
        tr = QRectF(x + w - 40 * s, y + 7 * s, 30 * s, 14 * s)           # the little track + knob
        on_c, off_c = QColor(230, 233, 240), QColor("#262C3A")
        rr(p, tr, 7 * s, QColor(int(off_c.red() + (on_c.red() - off_c.red()) * k),
                                int(off_c.green() + (on_c.green() - off_c.green()) * k),
                                int(off_c.blue() + (on_c.blue() - off_c.blue()) * k)))
        p.setBrush(QColor(14, 17, 24) if k > 0.5 else QColor("#A9B1C2"))
        p.drawEllipse(QPointF(tr.x() + 7 * s + k * 16 * s, tr.center().y()), 5 * s, 5 * s)
        p.restore()
        if abs(k - (1.0 if on else 0.0)) > 0.01:
            self.ver += 1                                          # keep animating the knob

    @staticmethod
    def _pet_icon(p, r, pix, ring, s):
        p.setPen(QPen(QColor(0, 0, 0, 150), 4 * s))
        p.setBrush(QColor(14, 17, 24, 235))
        p.drawEllipse(r)
        if pix is not None and not pix.isNull():
            clip = QPainterPath()
            clip.addEllipse(r.adjusted(1.5 * s, 1.5 * s, -1.5 * s, -1.5 * s))
            p.save()
            p.setClipPath(clip, Qt.IntersectClip)
            p.drawPixmap(r, pix, QRectF(pix.rect()))
            p.restore()
        p.setPen(QPen(ring, 2 * s))
        p.setBrush(Qt.NoBrush)
        p.drawEllipse(r)

    def toggle_pin(self, world, name, x, y):
        self.pin = None if self.pin and self.pin[1:] == (name, x, y) else (world, name, x, y)
        try:
            (self.app_dir / "maps" / "pin.json").write_text(json.dumps(list(self.pin) if self.pin else []))
        except OSError:
            pass

    def _paint_card(self, p, s, to, pts, W, Hh, font, text, rr, draw_icon):
        """Details for the clicked pet(s), pinned next to them on the map."""
        cd = self.card
        ax, ay = to(*cd["at"])
        rows = cd["pets"]
        cw, rh, pad = 262 * s, 50 * s, 10 * s
        ch = pad * 2 + 18 * s + rh * len(rows)
        x = ax + 22 * s if ax + 22 * s + cw < W - 8 * s else ax - 22 * s - cw
        y = min(max(Hh * 0.08, ay - 24 * s), Hh - ch - 8 * s)
        rect = QRectF(x, y, cw, ch)
        cd["rect"] = rect
        p.save()
        p.setClipping(False)
        age = min(1.0, (time.time() - cd["t"]) / 0.14)
        p.setOpacity(self.op * age)
        p.translate(0, (1 - age) * 6 * s)
        rr(p, rect, 10 * s, QColor(14, 17, 24, 238))
        text(p, x + pad, y + pad + 11 * s, "Pets here" if len(rows) > 1 else "Pet", font(11 * s, 600, True),
             QColor("#A9B1C2"))
        xr = QRectF(x + cw - 26 * s, y + 6 * s, 20 * s, 20 * s)
        p.setPen(QPen(QColor("#A9B1C2"), 1.6 * s, Qt.SolidLine, Qt.RoundCap))
        c = xr.center()
        d = 4.5 * s
        p.drawLine(QPointF(c.x() - d, c.y() - d), QPointF(c.x() + d, c.y() + d))
        p.drawLine(QPointF(c.x() - d, c.y() + d), QPointF(c.x() + d, c.y() - d))
        self.card_hits.append((xr, lambda: setattr(self, "card", None)))
        kibs = pts.get("kibs", [])
        for i, (name, (cx, cy), ci) in enumerate(rows):
            ry = y + pad + 22 * s + i * rh
            e = pts["pets"].get(name, {})
            ring = QColor(GENUS_COL.get(e.get("g"), "#D7DCE6"))
            self._pet_icon(p, QRectF(x + pad, ry + 4 * s, 34 * s, 34 * s), self.icon_for(name), ring, s)
            tx = x + pad + 44 * s
            info = self.info_for(name) or {}
            text(p, tx, ry + 15 * s, name, font(12 * s, 700), QColor(255, 255, 255, 240), w=cw - (tx - x) - pad - 28 * s)
            pinned = bool(self.pin) and self.pin[1:] == (name, cx, cy)
            pr_ = QRectF(x + cw - pad - 22 * s, ry + 2 * s, 22 * s, 18 * s)
            rr(p, pr_, 5 * s, QColor(255, 255, 255, 235) if pinned else QColor("#262C3A"))
            pin_pix = self._game_icon("pin")
            if pin_pix is not None:                     # the game's own map pin
                c_, d_ = pr_.center(), 8 * s
                p.save()
                p.setRenderHint(QPainter.SmoothPixmapTransform)
                p.setOpacity(p.opacity() * (1.0 if pinned else 0.8))
                p.drawPixmap(QRectF(c_.x() - d_, c_.y() - d_, 2 * d_, 2 * d_), pin_pix, QRectF(pin_pix.rect()))
                p.restore()
            else:
                draw_pin(p, pr_.center().x(), pr_.center().y(), 5.5 * s, QColor("#0E1118") if pinned else QColor("#D7DCE6"))
            self.card_hits.append((pr_, lambda n=name, a=cx, b=cy: self.toggle_pin(self.world, n, a, b)))
            if info.get("maxed"):
                prog, k = "Collection complete", 1.0
            elif info.get("need"):
                prog, k = f"Lv {info['level']}  ·  {info['cur']}/{info['need']} souls", info["cur"] / info["need"]
            else:
                prog, k = "", 0
            fam = info.get("family", "")
            text(p, tx, ry + 29 * s, " · ".join(v for v in (fam, prog) if v), font(9.5 * s), QColor("#D7DCE6"),
                 w=cw - (tx - x) - pad)
            bw = cw - (tx - x) - pad
            rr(p, QRectF(tx, ry + 33 * s, bw, 2.5 * s), 1.2 * s, QColor("#262C3A"))
            rr(p, QRectF(tx, ry + 33 * s, bw * max(0.0, min(1.0, k)), 2.5 * s), 1.2 * s, ring)
            cl = e.get("c", [])
            n = cl[ci][2] if ci < len(cl) else 0
            near = min(kibs, key=lambda q: (q[2] - cx) ** 2 + (q[3] - cy) ** 2) if kibs else None
            bits = [f"{n} spawns here"] if n else []
            if near:
                num = self.kibnum.get(str(near[0]))
                dist = math.hypot(near[2] - cx, near[3] - cy) / 100
                bits.append(f"◆{num} {near[1]} · {dist:.0f} m" if num else f"◆ {near[1]} · {dist:.0f} m")
            text(p, tx, ry + 46 * s, "   ".join(bits), font(9 * s), QColor("#A9B1C2"), w=cw - (tx - x) - pad)
        p.restore()


# ------------------------------------------------------------------------------------------ minimap ---- #
class MiniView(QWidget):
    """The same pet spawns on the minimap while you play. The minimap is north-up with a fixed zoom, so
    sliding it over the region map (template matching) finds where you are: once from scratch (~50 ms),
    then in a small window around the last spot (~2 ms) as you move."""
    K0 = 6783 / 816000              # minimap px per game unit at a 1920-wide screen (measured on your screen)
    MATCH_H = 145                   # rows used for matching (the clock bar below is left out)

    def __init__(self, big, log):
        super().__init__()
        self.big, self.log = big, log
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool |
                            Qt.WindowDoesNotAcceptFocus | Qt.WindowTransparentForInput)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.active, self.rect, self.world = False, None, None
        self.pos, self.W, self.score = None, None, 0.0        # top-left of the minimap in the W-size map
        self.maps, self.lost, self.next_try = {}, 0, 0.0
        self.ver, self.painted, self.seen_t, self.op = 0, -1, 0.0, 0.0
        self.thread = None
        self.state = "off"
        self.k = self.K0
        self.lock_score = 0.0
        self.ghosts = []
        self.timer = QTimer(self)
        self.timer.setInterval(30)
        self.timer.timeout.connect(self._frame)

    def showEvent(self, e):
        super().showEvent(e)
        _exclude_capture(self)

    def _load_k(self):
        try:
            return float(json.loads((self.big.app_dir / "maps" / "minimap.json").read_text())["k"])
        except (OSError, ValueError, KeyError):
            return self.K0

    def _save_k(self):
        try:
            (self.big.app_dir / "maps" / "minimap.json").write_text(json.dumps({"k": self.k}))
        except OSError:
            pass

    def status(self):
        d = self.big.data
        info = f"  live pets {len(getattr(d, 'live', {}))}  needed pets {len(self.big.want_pets())}  " \
               f"drawn {getattr(self, 'drawn', 0)}  you {'known' if getattr(self.big.data, 'self_eid', None) else 'not seen yet'}"
        return self.state + info + (f"  score {self.score:.2f}" if self.state == "showing" else
                             f"  world {self.world}  last try {getattr(self, 'last_try', None)}")

    def tick(self, playing, rect):
        b = self.big
        on = bool(playing and rect and rect[2] > 400 and b.enabled()) and b.setup()
        w = b.data.world
        if w is None and on:                     # region not known yet (just restarted): try each in turn
            cands = [c for c in b.points if b.points[c].get("pets") and b.matcher._src(c) is not None]
            if self.pos is not None and self.world in cands:
                w = self.world
            elif cands:
                if time.time() >= getattr(self, "_next_guess", 0):
                    self._guess = (getattr(self, "_guess", -1) + 1) % len(cands)
                    self._next_guess = time.time() + 1.2
                w = cands[getattr(self, "_guess", 0) % len(cands)]
        on = on and w is not None and str(w) in b.points and b.matcher._src(str(w)) is not None
        if on:
            x0, y0, ww, hh = rect
            s = min(ww / 1920, hh / 1080)
            self.rect = (int(x0 + ww - 268 * s), int(y0 + 100 * s), int(244 * s), int(162 * s))
            self.s, self.world = s, str(w)
            if not self.active:
                self.active = True
                if self.thread is None or not self.thread.is_alive():
                    self.thread = threading.Thread(target=self._run, daemon=True)
                    self.thread.start()
            if not self.timer.isActive():
                self.timer.start()
        elif self.active:
            self.active = False
            self.state = "idle"

    def _map(self, W, world=None):
        """Region map, grey, at minimap scale (+ a quarter-size copy for the first search)."""
        world = world or self.world
        key = (world, W)
        if key not in self.maps:
            cv2 = self.big.matcher.cv2
            if getattr(self, "src", (None,))[0] != world:
                self.src = (world, cv2.imread(str(self.big.matcher._src(world)), cv2.IMREAD_GRAYSCALE))
            m = cv2.resize(self.src[1], (W, W), interpolation=cv2.INTER_AREA)
            if len(self.maps) > 4:
                self.maps = {}
            self.maps[key] = (m, cv2.resize(m, (W // 4, W // 4), interpolation=cv2.INTER_AREA))
        return self.maps[key]

    def _run(self):
        b = self.big
        cv2, np = b.matcher.cv2, b.matcher.np
        while True:
            if not self.active:
                time.sleep(0.1)
                continue
            t0 = time.time()
            try:
                rect, world = self.rect, self.world
                img = b.cap.grab(rect, np, cv2)
                if img is not None and img.size:
                    img = img[:int(self.MATCH_H * self.s)]
                    pts = b.points[world]
                    W = int(self.k * abs(pts["bounds"][1] - pts["bounds"][0]) * self.s)
                    if self._from_position(world, W):
                        pass
                    elif self.pos is not None and self.W == W and world == getattr(self, "_pos_world", None):
                        self._local(img, W, world)
                        self._learn_self(world, W)
                    elif time.time() >= self.next_try or world != getattr(self, "_tried", None):
                        self._tried = world
                        self._global(img, world, W)
                        self._learn_self(world, W)
            except Exception as e:
                self.log(f"minimap overlay: {e}")
                time.sleep(1.0)
            time.sleep(max(0.0, 0.04 - (time.time() - t0)))

    def _grad(self, a):
        """Edges only: the view cone and glow over the minimap barely change them, so matching holds."""
        cv2 = self.big.matcher.cv2
        a = cv2.GaussianBlur(a, (3, 3), 0).astype("float32")
        return cv2.magnitude(cv2.Sobel(a, cv2.CV_32F, 1, 0), cv2.Sobel(a, cv2.CV_32F, 0, 1))

    def _score(self, m, img, x, y, pad, gimg=None):
        cv2 = self.big.matcher.cv2
        h, w = img.shape
        x0, y0 = max(0, int(x - pad)), max(0, int(y - pad))
        sub = m[y0:y0 + h + 2 * pad, x0:x0 + w + 2 * pad]
        if sub.shape[0] < h or sub.shape[1] < w:
            return -1, None
        r = cv2.matchTemplate(self._grad(sub), gimg if gimg is not None else self._grad(img), cv2.TM_CCOEFF_NORMED)
        _, mx, _, loc = cv2.minMaxLoc(r)
        r2 = r.copy()
        cv2.circle(r2, loc, max(4, int(8 * self.s)), -1.0, -1)
        self.sharp = mx - cv2.minMaxLoc(r2)[1] if r2.size > 1 else 0.0   # how clearly this spot wins
        return mx, (x0 + loc[0], y0 + loc[1])

    def _local(self, img, W, world=None):
        m, _ = self._map(W, world)
        anc, age = self._anchor(world or self.world, W)
        if anc is not None and age < 2 and math.hypot(self.pos[0] - anc[0], self.pos[1] - anc[1]) > 110 * self.s:
            self.pos, self.state = None, "looking"           # locked onto the wrong spot: the game says otherwise
            return
        sc, p = self._score(m, img, self.pos[0], self.pos[1], int(24 * self.s))
        if sc > 0.16 and p and sc > 0.55 * self.lock_score and self.sharp > 0.02:
            self.lock_score = 0.9 * self.lock_score + 0.1 * sc
            self.lost = 0
            if p != self.pos:
                self.pos = p
                self.ver += 1
            self.score, self.seen_t, self.state = sc, time.time(), "showing"
        else:
            self.lost += 1
            if self.lost > 25:                           # ~1 s of not finding it: look from scratch
                self.pos, self.state = None, "looking"

    def _global(self, img, world, W):
        """Find you from scratch: edges of the minimap against edges of the half-size region map. Edges work
        even on snow and grass that look alike everywhere; ~0.3 s, only when not already tracking."""
        cv2 = self.big.matcher.cv2
        m, _ = self._map(W, world)
        key = (world, W)
        anc, age = self._anchor(world, W)
        if anc is not None:                    # the game said where you are: look only around there
            pad = int((30 + 12 * age) * self.s)
            sc, p = self._score(m, img, anc[0], anc[1], pad)
            if p and sc > 0.2 and self.sharp > 0.03:
                self._take(p, W, world, sc)
                return
        if getattr(self, "_ghalf", (None,))[0] != key:
            half = cv2.resize(m, (W // 2, W // 2), interpolation=cv2.INTER_AREA)
            self._ghalf = (key, self._grad(half))
        h, w = img.shape
        th = self._grad(cv2.resize(img, (w // 2, h // 2), interpolation=cv2.INTER_AREA))
        r = cv2.matchTemplate(self._ghalf[1], th, cv2.TM_CCOEFF_NORMED)
        _, mx, _, loc = cv2.minMaxLoc(r)
        r2 = r.copy()
        cv2.circle(r2, loc, 6, -1.0, -1)
        gap = mx - cv2.minMaxLoc(r2)[1]
        sc, p = self._score(m, img, loc[0] * 2, loc[1] * 2, int(6 * self.s))
        self.last_try = (round(mx, 3), round(gap, 3), round(sc, 3))
        far = anc is not None and p is not None and math.hypot(p[0] - anc[0], p[1] - anc[1]) > (60 + 15 * age) * self.s
        if mx > 0.3 and gap > 0.08 and sc > 0.2 and not far:   # one clear winner, and where the game says
            self._take(p, W, world, sc)
        elif anc is not None and age < 3:      # can't see it clearly, but the game just said where you are
            self._take(anc, W, world, 0.2)
            self.lock_score = 0.2
        else:
            self.state = "looking"
            self.next_try = time.time() + 1.0

    def _take(self, p, W, world, sc):
        self.lock_score = sc
        self.pos, self.W, self.lost, self.score = p, W, 0, sc
        self._pos_world = world
        self.seen_t, self.state = time.time(), "showing"
        self.ver += 1

    CX, CY = 122, 81                    # where you are on the minimap (px at a 1920-wide screen)

    def _me(self, world, W):
        """Your position (game units) from the minimap match."""
        pts = self.big.points[world]
        gx0, gx1, gy0, gy1 = pts["bounds"]
        return (gx0 + (self.pos[0] + self.CX * self.s) / W * (gx1 - gx0),
                gy0 + (self.pos[1] + self.CY * self.s) / W * (gy1 - gy0))

    def _learn_self(self, world, W):
        """You are known from the game data (your character's entity), nothing to learn here."""

    def _anchor(self, world, W):
        """Where the game data last said you stand, as a minimap position, and how old that is (s)."""
        sp = getattr(self.big.data, "self_pos", None)
        if not sp or getattr(self.big.data, "world", None) is None or str(self.big.data.world) != str(world):
            return None, None
        age = time.time() - sp[2]
        if age > 20:
            return None, None
        gx0, gx1, gy0, gy1 = self.big.points[world]["bounds"]
        u, v = (sp[0] - gx0) / (gx1 - gx0), (sp[1] - gy0) / (gy1 - gy0)
        if not (0 <= u <= 1 and 0 <= v <= 1):
            return None, None
        return (u * W - self.CX * self.s, v * W - self.CY * self.s), age

    def _from_position(self, world, W):
        """Place the minimap from your live position in the game data, when the game sends it."""
        e = getattr(self.big.data, "self_eid", None)
        m = getattr(self.big.data, "moves", {}).get(e) if e else None
        if not m or time.time() - m[2] > 0.4:
            return False
        pts = self.big.points[world]
        gx0, gx1, gy0, gy1 = pts["bounds"]
        u, v = (m[0] - gx0) / (gx1 - gx0), (m[1] - gy0) / (gy1 - gy0)
        if not (0 <= u <= 1 and 0 <= v <= 1):
            return False
        p = (u * W - self.CX * self.s, v * W - self.CY * self.s)
        if p != self.pos:
            self.pos = p
            self.ver += 1
        self.W, self._pos_world, self.lost = W, world, 0
        self.seen_t, self.state, self.score = time.time(), "showing", 1.0
        return True

    def live_now(self, pts, want):
        """Pets in view right now: drop ones you killed, walked far from, or saw long ago."""
        d = self.big.data
        live = getattr(d, "live", None)
        if live is None or self.pos is None or not self.W:
            return []
        gx0, gx1, gy0, gy1 = pts["bounds"]
        s = self.s
        me_x = gx0 + (self.pos[0] + self.CX * s) / self.W * (gx1 - gx0)
        me_y = gy0 + (self.pos[1] + self.CY * s) / self.W * (gy1 - gy0)
        now = time.time()
        for nm, t in list(getattr(d, "kills", [])):
            d.kills.remove((nm, t))
            cand = [(math.hypot(v[1] - me_x, v[2] - me_y), k) for k, v in list(live.items()) if v[0] == nm]
            if cand:
                k = min(cand)[1]                               # the one you just killed: fade it out now
                v = live.pop(k, None)
                if v:
                    self.ghosts.append((v[0], v[1], v[2], now))
        for k, (nm, x, y, t) in list(live.items()):
            if now - t > 300 or math.hypot(x - me_x, y - me_y) > 32000:
                live.pop(k, None)
        self.ghosts = [g for g in self.ghosts if now - g[3] < 0.25]
        return [(nm, x, y) for nm, x, y, t in list(live.values()) if nm in want]

    def _frame(self):
        live = self.active and self.pos is not None and time.time() - self.seen_t < 1.5
        self.op = min(1.0, self.op + 0.3) if live else max(0.0, self.op - 0.2)
        if self.op > 0:
            if self.rect and self.geometry().getRect() != self.rect:
                self.setGeometry(*self.rect)
            if not self.isVisible():
                self.show()
            if self.ver != self.painted or self.op < 1 or (self.big.pin and self.big.pin[0] == self.world) or \
                    getattr(self.big.data, "live", None):
                self.update()
        else:
            if self.isVisible():
                self.hide()
            if not self.active:
                self.timer.stop()

    def paintEvent(self, _):
        b, pos, W = self.big, self.pos, self.W
        if pos is None or not W or self.world not in b.points:
            return
        self.painted = self.ver
        pts = b.points[self.world]
        gx0, gx1, gy0, gy1 = pts["bounds"]
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setOpacity(self.op)
        s = self.s
        w, h = self.width(), self.height()
        p.setClipRect(QRectF(2 * s, 2 * s, w - 4 * s, h - 4 * s))

        def to(x, y):
            return (x - gx0) / (gx1 - gx0) * W - pos[0], (y - gy0) / (gy1 - gy0) * W - pos[1]
        want = b.want_pets()
        pets = [(n, e) for n, e in pts.get("pets", {}).items() if n in want]
        cx0, cy0 = self.CX * s, self.CY * s                             # you: the minimap's centre
        # where each pet can spawn: small faded dots
        for name, e in pets:
            c = QColor(GENUS_COL.get(e.get("g"), "#D7DCE6"))
            c.setAlpha(170)
            p.setPen(QPen(c, 3.4 * s, Qt.SolidLine, Qt.RoundCap))
            vis = [QPointF(*q) for q in (to(x, y) for x, y in e["p"]) if -4 <= q[0] <= w + 4 and -4 <= q[1] <= h + 4]
            if vis:
                p.drawPoints(vis)
        # pets actually there right now (from the game's own data): one icon each
        live = self.live_now(pts, want)
        self.drawn = len(live)
        sz = 17 * s
        now = time.time()
        for name, x, y, fade in [(n, x, y, 1.0) for n, x, y in live] + \
                [(g[0], g[1], g[2], 1 - (now - g[3]) / 0.25) for g in self.ghosts]:
            X, Y = to(x, y)
            e = pts["pets"].get(name, {})
            m = 9 * s
            if m <= X <= w - m and m <= Y <= h - 4 * s - m:
                d = math.hypot(X - cx0, Y - cy0)
                p.setOpacity(self.op * fade * (0.4 + 0.6 * min(1.0, max(0.0, (d - 8 * s) / (30 * s)))))
                r = sz
            else:                                                # further away: waiting at the edge
                dx, dy = X - cx0, Y - cy0
                k = min((w / 2 - m) / max(1e-6, abs(dx)), (h / 2 - m) / max(1e-6, abs(dy)))
                X, Y = cx0 + dx * k, cy0 + dy * k
                p.setOpacity(self.op * fade * 0.55)
                r = sz * 0.72
            MapView._pet_icon(p, QRectF(X - r / 2, Y - r / 2, r, r), b.icon_for(name),
                              QColor(GENUS_COL.get(e.get("g"), "#D7DCE6")), s * 0.5)
        p.setOpacity(self.op)
        pin = b.pin
        if pin and pin[0] == self.world:
            X, Y = to(pin[2], pin[3])
            cx, cy = cx0, cy0
            m = 25 * s                                        # room for the arrow inside the minimap
            inside = 12 * s <= X <= w - 12 * s and 12 * s <= Y <= h - 26 * s
            white = QColor(255, 255, 255)
            p.setClipping(False)
            if not inside:                                    # stick to the edge, pointing the way
                dx, dy = X - cx, Y - cy
                k = min((w / 2 - m) / max(1e-6, abs(dx)), (h / 2 - m) / max(1e-6, abs(dy)))
                X, Y = cx + dx * k, cy + dy * k
                ang = math.atan2(dy, dx)
                tip = QPointF(X + math.cos(ang) * 15 * s, Y + math.sin(ang) * 15 * s)
                l = QPointF(X + math.cos(ang + 2.6) * 6 * s + math.cos(ang) * 8 * s,
                            Y + math.sin(ang + 2.6) * 6 * s + math.sin(ang) * 8 * s)
                r_ = QPointF(X + math.cos(ang - 2.6) * 6 * s + math.cos(ang) * 8 * s,
                             Y + math.sin(ang - 2.6) * 6 * s + math.sin(ang) * 8 * s)
                path = QPainterPath()
                path.moveTo(tip)
                path.lineTo(l)
                path.lineTo(r_)
                path.closeSubpath()
                p.setPen(QPen(QColor(0, 0, 0, 170), 1.4 * s))
                p.setBrush(white)
                p.drawPath(path)
            big = 20 * s
            t = (time.time() * 0.8) % 1.0                     # a soft ripple going out, like a sonar ping
            p.setPen(QPen(QColor(255, 255, 255, int(150 * (1 - t))), 1.6 * s))
            p.setBrush(Qt.NoBrush)
            p.drawEllipse(QPointF(X, Y), big / 2 + 2 * s + t * 9 * s, big / 2 + 2 * s + t * 9 * s)
            e = pts["pets"].get(pin[1], {})
            MapView._pet_icon(p, QRectF(X - big / 2, Y - big / 2, big, big), b.icon_for(pin[1]),
                              QColor(GENUS_COL.get(e.get("g"), "#D7DCE6")), s * 0.8)
            draw_pin(p, X + big * 0.42, Y - big * 0.48, 4.2 * s, white)
        p.end()
