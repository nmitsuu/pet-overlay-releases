"""
Pet spawns drawn right on the game's own big map. While a full-screen window is open it looks at the
screen, recognises the region map by matching it against the same map picture the Farm maps use, works
out where it's scrolled and zoomed to, and draws pet icons at their spawn spots. Read-only: it only
looks at screen pixels, nothing is sent to the game.
Needs OpenCV (installed by itself in the background the first time).
"""
import importlib
import json
import math
import os
import site
import subprocess
import sys
import threading
import time
from pathlib import Path

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer
from PySide6.QtGui import QColor, QCursor, QPainter, QPainterPath, QPen, QPolygonF, QRegion
from PySide6.QtWidgets import QWidget

MAPRES = 4096                       # map picture size the features are found at
GENUS_COL = {"C": "#5AA9FF", "F": "#FF6B5E", "N": "#5FD38A", "V": "#F2C94C"}


def _cv():
    try:
        import cv2
        import numpy
        if not getattr(cv2, "_po_threads", False):   # few helper threads: leaves the CPU to the game
            cv2._po_threads = True
            cv2.setNumThreads(2)
        return cv2, numpy
    except ImportError:
        return None, None


def ensure_cv(app_dir, log):
    """True when OpenCV can be used; otherwise starts a one-time quiet install and returns False."""
    if _cv()[0]:
        return True
    flag = Path(app_dir) / "maps" / "opencv_install.txt"
    try:
        if time.time() - flag.stat().st_mtime < 6 * 3600:
            return False
    except OSError:
        pass
    try:
        flag.parent.mkdir(exist_ok=True)
        flag.write_text(time.ctime(), encoding="utf-8")
    except OSError:
        return False

    def work():
        exe = Path(sys.executable)
        py = exe.with_name("python.exe") if exe.name.lower() == "pythonw.exe" else exe
        try:
            r = subprocess.run([str(py), "-m", "pip", "install", "--user", "--disable-pip-version-check", "-q",
                                "opencv-python-headless", "numpy", "dxcam"], capture_output=True, text=True, timeout=900,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            if r.returncode:
                log(f"map overlay: installing OpenCV failed: {r.stderr[-400:]}")
            site.addsitedir(site.getusersitepackages())
            importlib.invalidate_caches()
        except Exception as e:
            log(f"map overlay: installing OpenCV failed: {e}")
    threading.Thread(target=work, daemon=True, name="mapview work").start()
    return False


class Matcher:
    """Finds where a screenshot of the big map sits on the region's map picture."""

    def __init__(self, maps_dir, log):
        self.dir, self.log = Path(maps_dir), log
        self.feats = {}
        cv2, np = _cv()
        self.cv2, self.np = cv2, np
        self.orb = cv2.ORB_create(nfeatures=1500, scaleFactor=1.25, nlevels=10)
        self.bf = cv2.BFMatcher(cv2.NORM_HAMMING)

    def _listing(self):
        """Map files in the folder, looked up at most every 10 s (this runs every frame; reading the
        folder each time slowed the overlay down)."""
        t = time.monotonic()
        c = getattr(self, "_list_cache", None)
        if c is None or t - c[0] > 10:
            names = {p.name for p in self.dir.glob("*.webp")}
            c = self._list_cache = (t, names)
        return c[1]

    def _src(self, w):
        names = self._listing()
        for n in (f"world_{w}.webp", f"_{w}.webp"):
            if n in names:
                return self.dir / n
        return None

    def worlds(self):
        names = self._listing()
        out = {n[6:-5] for n in names if n.startswith("world_")}
        out |= {n[1:-5] for n in names if n.startswith("_")}
        return sorted(out)

    def feats_for(self, w):
        if w in self.feats:
            return self.feats[w]
        cv2, np = self.cv2, self.np
        src = self._src(w)
        if src is None:
            self.feats[w] = None
            return None
        cache = self.dir / f"feat_{w}.npz"
        try:
            if cache.exists() and cache.stat().st_mtime >= src.stat().st_mtime:
                z = np.load(cache)
                self.feats[w] = (z["p"], z["d"])
                return self.feats[w]
            img = cv2.imread(str(src), cv2.IMREAD_GRAYSCALE)
            if img is None:
                self.feats[w] = None
                return None
            img = cv2.resize(img, (MAPRES, MAPRES), interpolation=cv2.INTER_AREA)
            orb = cv2.ORB_create(nfeatures=40000, scaleFactor=1.25, nlevels=12, fastThreshold=12)
            k, d = orb.detectAndCompute(img, None)
            p = np.float32([q.pt for q in k]) / MAPRES
            np.savez(cache, p=p, d=d)
            self.feats[w] = (p, d)
        except Exception as e:
            self.log(f"map overlay: features for {w} failed: {e}")
            self.feats[w] = None
        return self.feats[w]

    def match(self, gray, w, prev=None, margin=0.25):
        """gray: numpy screen image. Returns a 2x3 transform (screen px -> map 0..1) or None."""
        cv2, np = self.cv2, self.np
        f = self.feats_for(w)
        if f is None:
            return None
        P, D = f
        h, wd = gray.shape
        mask = np.zeros_like(gray)
        mask[int(h * 0.07):, int(wd * 0.3):] = 255          # skip the list on the left and the top bar
        ks, ds = self.orb.detectAndCompute(gray, mask)
        if ds is None or len(ks) < 30:
            return None
        idx = None
        if prev is not None:                                  # look only near where it was a moment ago
            c = np.float32([[0, 0], [wd, 0], [0, h], [wd, h]])
            m = (prev[:, :2] @ c.T).T + prev[:, 2]
            (x0, y0), (x1, y1) = m.min(0), m.max(0)
            mx, my = (x1 - x0) * margin, (y1 - y0) * margin
            sel = (P[:, 0] > x0 - mx) & (P[:, 0] < x1 + mx) & (P[:, 1] > y0 - my) & (P[:, 1] < y1 + my)
            idx = np.nonzero(sel)[0]
            if len(idx) < 50:
                idx = None
        Dm = D if idx is None else D[idx]
        ms = self.bf.knnMatch(ds, Dm, k=2)
        good = [a for a, b in (x for x in ms if len(x) == 2) if a.distance < 0.8 * b.distance]
        if len(good) < 15:
            return None
        src = np.float32([ks[a.queryIdx].pt for a in good])
        ti = np.array([a.trainIdx for a in good])
        dst = (P[ti] if idx is None else P[idx[ti]]) * MAPRES
        H, inl = cv2.estimateAffinePartial2D(src, dst, method=cv2.RANSAC, ransacReprojThreshold=4)
        if H is None or inl is None:
            return None
        n = int(inl.sum())
        rot = math.atan2(H[1, 0], H[0, 0])
        if n < 18 or n < 0.35 * len(good) or abs(rot) > 0.03 or H[0, 0] <= 0:
            return None
        # The big map fills the screen, so its matching points spread across most of it. A window that
        # only shows a piece of the map (a picture in a dialog, a quest window...) matches in one small
        # patch: not the big map.
        q = src[inl.ravel() == 1]
        if (q[:, 0].max() - q[:, 0].min()) < 0.35 * wd or (q[:, 1].max() - q[:, 1].min()) < 0.3 * h:
            return None
        return H / MAPRES


def ensure_dxcam(app_dir, log):
    """Faster screen copies (DXGI, the way recording apps do it). Optional: GDI is used until it's there."""
    try:
        import dxcam  # noqa: F401
        return True
    except Exception:
        pass
    flag = Path(app_dir) / "maps" / "dxcam_install.txt"
    if flag.exists():
        return False
    try:
        flag.write_text(time.ctime(), encoding="utf-8")
    except OSError:
        return False

    def work():
        exe = Path(sys.executable)
        py = exe.with_name("python.exe") if exe.name.lower() == "pythonw.exe" else exe
        try:
            subprocess.run([str(py), "-m", "pip", "install", "--user", "--disable-pip-version-check", "-q", "dxcam"],
                           capture_output=True, text=True, timeout=600,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            site.addsitedir(site.getusersitepackages())
            importlib.invalidate_caches()
        except Exception as e:
            log(f"map overlay: dxcam install failed: {e}")
    threading.Thread(target=work, daemon=True, name="mapview work").start()
    return False


_DIAG = set()


def _diag_save(app_dir, name, img, cv2, note):
    """Once per run: keep what the map reader saw, so a problem on another PC can be checked."""
    k = sum(1 for n in _DIAG if n[0] == name)
    if k >= 3 or any(n[0] == name and time.time() - n[1] < 20 for n in _DIAG):
        return                                   # up to 3 per run, 20 s apart
    _DIAG.add((name, time.time()))
    try:
        folder = Path(app_dir) / "samples"
        folder.mkdir(exist_ok=True)
        stem, ext = name.rsplit(".", 1)
        name = f"{stem}_{k + 1}.{ext}"
        cv2.imwrite(str(folder / name), img)
        with open(folder / "map_diag.txt", "a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%H:%M:%S')} {name}: {note}\n")
    except Exception:
        pass


class Capture:
    """Grey copies of a screen area. DXGI (dxcam) when it works: it hands over a frame the moment the
    screen changes, in ~2 ms. Otherwise plain GDI. Shared by the big-map and minimap trackers."""

    def __init__(self, app_dir, log):
        self.app_dir, self.log = app_dir, log
        self.lock = threading.Lock()
        self.cam, self.cam_tried, self.gdi = None, 0.0, None
        self.kind = "gdi"

    def _dx(self):
        if self.cam is not None or time.time() < self.cam_tried:
            return self.cam
        self.cam_tried = time.time() + 5
        if not ensure_dxcam(self.app_dir, self.log):
            return None
        try:
            import dxcam
            self.cam = dxcam.create(output_idx=0, output_color="BGRA")
            self.kind = "dxgi"
        except Exception as e:
            self.log(f"map overlay: dxcam unavailable ({e}), using GDI")
            self.cam = None
            self.cam_tried = time.time() + 30
        return self.cam

    def grab(self, rect, np, cv2):
        """Full-resolution grey picture of rect, or None if the screen hasn't changed (DXGI only)."""
        x, y, w, h = rect
        with self.lock:
            cam = self._dx()
            if cam is not None:
                try:
                    W, H = cam.width, cam.height
                    if x >= 0 and y >= 0 and x + w <= W and y + h <= H:
                        f = cam.grab(region=(x, y, x + w, y + h))
                        self.fails = 0
                        self.kind = "dxgi"
                        if f is None:
                            return None
                        g = cv2.cvtColor(f, cv2.COLOR_BGRA2GRAY)
                        if int(g[::16, ::16].max()) >= 8:
                            self.black = 0
                            return g
                        # all black: on some laptops (two graphics chips) DXGI only ever hands over black
                        # pictures while plain GDI sees the game fine. Check with GDI, and switch for good.
                        self.black = getattr(self, "black", 0) + 1
                        if self.black < 5:
                            return g
                        if self.gdi is None:
                            self.gdi = _Gdi()
                        gg = self.gdi.grab(rect, np, cv2)
                        if gg is not None and int(gg[::16, ::16].max()) >= 8:
                            self.log("map overlay: DXGI gives black pictures here, using GDI")
                            try:
                                cam.release()
                            except Exception:
                                pass
                            self.cam, self.cam_tried, self.kind = None, float("inf"), "gdi (dxgi black)"
                            return gg
                        self.black = 0
                        return g
                except Exception as e:
                    # usually Windows taking the screen copy away for a moment (alt-tab, a full-screen
                    # switch): reconnect instead of giving up; plain GDI meanwhile
                    self.fails = getattr(self, "fails", 0) + 1
                    if self.fails in (1, 50):
                        self.log(f"map overlay: dxcam lost the screen ({e}), reconnecting")
                    try:
                        cam._on_output_change()
                    except Exception:
                        pass
                    if self.fails == 30:                    # still lost: start a brand-new screen copy
                        try:
                            import dxcam
                            cam.release()
                            getattr(dxcam, "__factory")._camera_instances.clear()
                        except Exception:
                            pass
                        self.cam, self.cam_tried = None, 0.0
                    if self.fails > 200:                    # it really doesn't work here: GDI for a while
                        self.cam, self.cam_tried, self.kind, self.fails = None, time.time() + 60, "gdi", 0
                    if self.gdi is None:
                        self.gdi = _Gdi()
                    return self.gdi.grab(rect, np, cv2)
            if self.gdi is None:
                self.gdi = _Gdi()
            return self.gdi.grab(rect, np, cv2)


class _Gdi:
    def __init__(self):
        import ctypes
        from ctypes import wintypes as W
        self.c = ctypes
        u, g = ctypes.windll.user32, ctypes.windll.gdi32
        u.GetDC.restype, u.GetDC.argtypes = W.HDC, [W.HWND]
        u.ReleaseDC.argtypes = [W.HWND, W.HDC]
        g.CreateCompatibleDC.restype, g.CreateCompatibleDC.argtypes = W.HDC, [W.HDC]
        g.CreateCompatibleBitmap.restype = W.HBITMAP
        g.CreateCompatibleBitmap.argtypes = [W.HDC, ctypes.c_int, ctypes.c_int]
        g.SelectObject.restype, g.SelectObject.argtypes = W.HGDIOBJ, [W.HDC, W.HGDIOBJ]
        g.BitBlt.argtypes = [W.HDC] + [ctypes.c_int] * 4 + [W.HDC] + [ctypes.c_int] * 2 + [W.DWORD]
        g.GetDIBits.argtypes = [W.HDC, W.HBITMAP, W.UINT, W.UINT, ctypes.c_void_p, ctypes.c_void_p, W.UINT]
        g.DeleteObject.argtypes, g.DeleteDC.argtypes = [W.HGDIOBJ], [W.HDC]
        self.u, self.g = u, g

        class BIH(ctypes.Structure):
            _fields_ = [("biSize", W.DWORD), ("biWidth", W.LONG), ("biHeight", W.LONG), ("biPlanes", W.WORD),
                        ("biBitCount", W.WORD), ("biCompression", W.DWORD), ("biSizeImage", W.DWORD),
                        ("biXPelsPerMeter", W.LONG), ("biYPelsPerMeter", W.LONG), ("biClrUsed", W.DWORD),
                        ("biClrImportant", W.DWORD), ("colors", W.DWORD * 3)]
        self.BIH = BIH

    def grab(self, rect, np, cv2):
        x, y, w, h = rect
        u, g = self.u, self.g
        sdc = u.GetDC(None)
        mdc = g.CreateCompatibleDC(sdc)
        bmp = g.CreateCompatibleBitmap(sdc, w, h)
        old = g.SelectObject(mdc, bmp)
        g.BitBlt(mdc, 0, 0, w, h, sdc, x, y, 0x00CC0020)       # our layered windows aren't copied
        g.SelectObject(mdc, old)
        bi = self.BIH()
        bi.biSize, bi.biWidth, bi.biHeight, bi.biPlanes, bi.biBitCount = 40, w, -h, 1, 32
        buf = np.empty((h, w, 4), np.uint8)
        g.GetDIBits(mdc, bmp, 0, h, buf.ctypes.data, self.c.byref(bi), 0)
        g.DeleteObject(bmp)
        g.DeleteDC(mdc)
        u.ReleaseDC(None, sdc)
        return cv2.cvtColor(buf, cv2.COLOR_BGRA2GRAY)


class Cursor:
    """Samples the mouse position and left button ~500 times a second (only reads them; nothing is sent
    anywhere). Lets the map layer move with a drag in real time, the same way the game's map does."""

    def __init__(self):
        import collections
        self.hist = collections.deque(maxlen=600)      # (t, x, y, down)
        self.presses = collections.deque(maxlen=20)    # (t, x, y) when the button went down
        self.on = False
        self.ok = True
        self.last_press = None
        self.key0, self.close_key = False, 0.0
        try:
            import ctypes
            from ctypes import wintypes
            self.u = ctypes.windll.user32
            self.pt = wintypes.POINT()
            self.ref = ctypes.byref(self.pt)
        except Exception:
            self.ok = False
        threading.Thread(target=self._run, daemon=True, name="cursor").start()

    def _run(self):
        down0 = False
        while True:
            if not (self.on and self.ok):
                time.sleep(0.05)
                continue
            self.u.GetCursorPos(self.ref)
            down = bool(self.u.GetAsyncKeyState(0x01) & 0x8000)
            t = time.time()
            self.hist.append((t, self.pt.x, self.pt.y, down))
            if down and not down0:
                self.presses.append((t, self.pt.x, self.pt.y))
                self.last_press = (t, self.pt.x, self.pt.y)
            down0 = down
            km = bool(self.u.GetAsyncKeyState(0x4D) & 0x8000)
            k = km or bool(self.u.GetAsyncKeyState(0x1B) & 0x8000)
            fg = getattr(self, "fg", True)             # only keys pressed in the game count (not "m" typed
            if k and not self.key0 and fg:            # in another window, e.g. a chat, then alt-tab back)
                self.close_key = t
            if km and not getattr(self, "m0", False) and fg:
                self.m_key = t                          # M: the big map's key (opens or closes it)
            self.m0 = km
            self.key0 = k
            time.sleep(0.002)

    def at(self, t):
        """Cursor position at time t (between samples: in between; later than the last: the last)."""
        h = self.hist
        if not h:
            return None
        if t >= h[-1][0]:
            return h[-1][1], h[-1][2]
        for i in range(len(h) - 1, 0, -1):
            a, b = h[i - 1], h[i]
            if a[0] <= t <= b[0]:
                k = (t - a[0]) / max(1e-6, b[0] - a[0])
                return a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k
        return h[0][1], h[0][2]

    def down(self):
        return bool(self.hist) and self.hist[-1][3]


def _m3(m2):
    import numpy as np
    return np.vstack([m2, [0.0, 0.0, 1.0]])


def _exclude_capture(w):
    try:                                   # keep our own icons out of any screen copy
        import ctypes
        ctypes.windll.user32.SetWindowDisplayAffinity(int(w.winId()), 0x11)
    except Exception:
        pass


def ui_panels(small, np, cv2):
    """Game windows on top of the map (Change Map and the like): big, flat, dark boxes. [(x, y, w, h)]
    in small-frame px."""
    g = small.astype(np.float32)
    mu = cv2.blur(g, (10, 10))
    sd = np.sqrt(np.maximum(0, cv2.blur(g * g, (10, 10)) - mu * mu))
    m = ((sd < 5) & (mu < 70)).astype(np.uint8) * 255
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((9, 9), np.uint8))
    n, _lab, st, _c = cv2.connectedComponentsWithStats(m)
    k = small.shape[1] / 480
    out = []
    for i in range(1, n):
        x, y, w, h, a = st[i]
        if a > 2500 * k * k and a > 0.45 * w * h and w < 0.6 * small.shape[1] and h > 40 * k:
            e = 6 * k
            out.append((x - e, y - e, w + 2 * e, h + 2 * e))
    return out


# ------------------------------------------------------------------------------------------ big map ---- #
_SWP = 0x0001 | 0x0004 | 0x0010 | 0x4000          # NOSIZE | NOZORDER | NOACTIVATE | ASYNCWINDOWPOS


class SpriteLayer:
    """Pet icons as plain Windows layered windows, created, owned and moved by one render thread.
    All moves for a frame go in one batch right after the screen refresh, so every icon lands on the
    same frame and nothing waits on the overlay's main thread."""

    def __init__(self, on_click, log):
        import ctypes
        from ctypes import wintypes as W
        self.c, self.W, self.log, self.on_click = ctypes, W, log, on_click
        u, g, k = ctypes.windll.user32, ctypes.windll.gdi32, ctypes.windll.kernel32
        self.u, self.g = u, g
        LRESULT = ctypes.c_ssize_t
        self.WNDPROC = ctypes.WINFUNCTYPE(LRESULT, W.HWND, W.UINT, W.WPARAM, W.LPARAM)
        u.DefWindowProcW.restype = LRESULT
        u.DefWindowProcW.argtypes = [W.HWND, W.UINT, W.WPARAM, W.LPARAM]
        u.CreateWindowExW.restype = W.HWND
        u.CreateWindowExW.argtypes = [W.DWORD, W.LPCWSTR, W.LPCWSTR, W.DWORD, ctypes.c_int, ctypes.c_int,
                                      ctypes.c_int, ctypes.c_int, W.HWND, W.HMENU, W.HINSTANCE, W.LPVOID]
        u.BeginDeferWindowPos.restype = W.HANDLE
        u.DeferWindowPos.restype = W.HANDLE
        u.DeferWindowPos.argtypes = [W.HANDLE, W.HWND, W.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                     ctypes.c_int, W.UINT]
        u.EndDeferWindowPos.argtypes = [W.HANDLE]
        u.UpdateLayeredWindow.argtypes = [W.HWND, W.HDC, ctypes.c_void_p, ctypes.c_void_p, W.HDC,
                                          ctypes.c_void_p, W.DWORD, ctypes.c_void_p, W.DWORD]
        u.GetDC.restype = W.HDC
        g.CreateCompatibleDC.restype = W.HDC
        g.CreateDIBSection.restype = W.HBITMAP
        g.CreateDIBSection.argtypes = [W.HDC, ctypes.c_void_p, W.UINT, ctypes.POINTER(ctypes.c_void_p),
                                       W.HANDLE, W.DWORD]
        g.SelectObject.restype = W.HGDIOBJ
        g.SelectObject.argtypes = [W.HDC, W.HGDIOBJ]
        u.SetWindowDisplayAffinity.argtypes = [W.HWND, W.DWORD]
        u.SetCursor.argtypes = [W.HANDLE]
        u.ShowWindow.argtypes = [W.HWND, ctypes.c_int]
        u.DestroyWindow.argtypes = [W.HWND]
        u.ReleaseDC.argtypes = [W.HWND, W.HDC]
        u.GetDC.argtypes = [W.HWND]
        u.PeekMessageW.argtypes = [ctypes.POINTER(W.MSG), W.HWND, W.UINT, W.UINT, W.UINT]
        u.TranslateMessage.argtypes = [ctypes.POINTER(W.MSG)]
        u.DispatchMessageW.argtypes = [ctypes.POINTER(W.MSG)]
        u.RegisterClassExW.argtypes = [ctypes.c_void_p]
        g.CreateCompatibleDC.argtypes = [W.HDC]
        g.DeleteObject.argtypes = [W.HGDIOBJ]
        g.DeleteDC.argtypes = [W.HDC]
        k.GetModuleHandleW.restype = W.HMODULE
        k.GetModuleHandleW.argtypes = [W.LPCWSTR]
        u.LoadCursorW.restype = W.HANDLE
        u.LoadCursorW.argtypes = [W.HINSTANCE, ctypes.c_void_p]
        self.hand = u.LoadCursorW(None, ctypes.c_void_p(32649))
        self.hinst = k.GetModuleHandleW(None)

        def proc(hwnd, msg, wp, lp):
            if msg == 0x0021:                     # WM_MOUSEACTIVATE: never take focus from the game
                return 3
            if msg == 0x0020:                     # WM_SETCURSOR: a hand over the icon
                u.SetCursor(self.hand)
                return 1
            if msg == 0x0201:                     # left click
                self.on_click(hwnd)
                return 0
            return u.DefWindowProcW(hwnd, msg, wp, lp)
        self._proc = self.WNDPROC(proc)

        class WC(ctypes.Structure):
            _fields_ = [("cbSize", W.UINT), ("style", W.UINT), ("lpfnWndProc", self.WNDPROC), ("cbClsExtra", ctypes.c_int),
                        ("cbWndExtra", ctypes.c_int), ("hInstance", W.HINSTANCE), ("hIcon", W.HANDLE),
                        ("hCursor", W.HANDLE), ("hbrBackground", W.HANDLE), ("lpszMenuName", W.LPCWSTR),
                        ("lpszClassName", W.LPCWSTR), ("hIconSm", W.HANDLE)]
        wc = WC()
        wc.cbSize = ctypes.sizeof(WC)
        wc.lpfnWndProc = self._proc
        wc.hInstance = self.hinst
        wc.lpszClassName = "PetOverlaySprite"
        u.RegisterClassExW(ctypes.byref(wc))
        self.wins = {}                          # key -> (hwnd, w, h)
        self.err = ""
        self.at = {}                            # key -> (x, y) or None

    def pump(self):
        msg = self.W.MSG()
        while self.u.PeekMessageW(self.c.byref(msg), None, 0, 0, 1):
            self.u.TranslateMessage(self.c.byref(msg))
            self.u.DispatchMessageW(self.c.byref(msg))

    def build(self, specs):
        """specs: [(key, w, h, premultiplied BGRA bytes)]."""
        for hwnd, _w, _h in self.wins.values():
            self.u.DestroyWindow(hwnd)
        self.wins, self.at = {}, {}
        c, W, u, g = self.c, self.W, self.u, self.g
        sdc = u.GetDC(None)
        for key, w, h, data in specs:
            hwnd = u.CreateWindowExW(0x80000 | 0x8 | 0x80 | 0x8000000 | 0x20, "PetOverlaySprite", "", 0x80000000,
                                     -4000, -4000, w, h, None, None, self.hinst, None)
            if not hwnd:
                self.err = f"CreateWindow {c.windll.kernel32.GetLastError()}"
                continue
            u.SetWindowDisplayAffinity(hwnd, 0x11)      # never in screen copies (ours or anyone's)
            mdc = g.CreateCompatibleDC(sdc)
            bi = (c.c_byte * 44)()
            c.memmove(bi, c.pointer(c.c_int32(40)), 4)
            hdr = (c.c_int32 * 3)(w, -h, 0)
            c.memmove(c.addressof(bi) + 4, hdr, 8)
            c.memmove(c.addressof(bi) + 12, (c.c_uint16 * 2)(1, 32), 4)
            bits = c.c_void_p()
            bmp = g.CreateDIBSection(mdc, bi, 0, c.byref(bits), None, 0)
            c.memmove(bits, data, w * h * 4)
            old = g.SelectObject(mdc, bmp)
            size = (c.c_int32 * 2)(w, h)
            src = (c.c_int32 * 2)(0, 0)
            pos = (c.c_int32 * 2)(-4000, -4000)
            blend = (c.c_ubyte * 4)(0, 0, 255, 1)        # AC_SRC_OVER, alpha from the pixels
            if not u.UpdateLayeredWindow(hwnd, sdc, pos, size, mdc, src, 0, blend, 2):
                self.err = f"UpdateLayeredWindow {c.windll.kernel32.GetLastError()}"
            g.SelectObject(mdc, old)
            g.DeleteObject(bmp)
            g.DeleteDC(mdc)
            u.ShowWindow(hwnd, 4)                         # SW_SHOWNOACTIVATE
            self.wins[key] = (hwnd, w, h)
            self.at[key] = None
        u.ReleaseDC(None, sdc)

    def alpha(self, a):
        """Opacity of every icon (0-255), only when it changed."""
        if a == getattr(self, "_a", None):
            return
        self._a = a
        blend = (self.c.c_ubyte * 4)(0, 0, a, 1)
        for k, (hwnd, w, h) in self.wins.items():
            if self.at.get(k):
                self.u.UpdateLayeredWindow(hwnd, None, None, None, None, None, 0, blend, 2)

    def move(self, places):
        """places: {key: (x, y) or None}. One batch, applied together."""
        changed = [(k, v) for k, v in places.items() if k in self.wins and self.at.get(k) != v]
        if not changed:
            return
        u = self.u
        hdwp = u.BeginDeferWindowPos(len(changed))
        for k, v in changed:
            hwnd, w, h = self.wins[k]
            x, y = v if v else (-4000, -4000)
            hdwp = u.DeferWindowPos(hdwp, hwnd, None, int(x), int(y), 0, 0, 0x0001 | 0x0004 | 0x0010)
            if v and not self.at.get(k):
                self._a = None                                # re-apply alpha to the newly shown one
            self.at[k] = v
        if hdwp:
            u.EndDeferWindowPos(hdwp)
        else:
            self.err = f"DeferWindowPos {self.c.windll.kernel32.GetLastError()}"


def paint_pill(p, r, pos, lit, rr):
    """The two-way pets / gathering switch (big map and minimap): pos 0 = butterfly side, 1 = basket side;
    lit 1 = showing, 0 = hidden (dark knob). Soft glow around the lit knob. A tall rect = vertical switch
    (butterfly on top)."""
    import ui as theme
    if r.height() > r.width():                       # vertical: draw it lying down, turned a quarter
        c = r.center()
        p.save()
        p.translate(c)
        p.rotate(90)
        p.translate(-c)
        flat = QRectF(c.x() - r.height() / 2, c.y() - r.width() / 2, r.height(), r.width())
        _pill(p, flat, pos, lit, rr, theme, upright=-90)
        p.restore()
        return
    _pill(p, r, pos, lit, rr, theme)


def _pill(p, r, pos, lit, rr, theme, upright=0):
    h, w = r.height(), r.width()
    cy = r.center().y()
    rr(p, r, h / 2, QColor(theme.TILE.red(), theme.TILE.green(), theme.TILE.blue(), 235))
    rr(p, r, h / 2, theme._mix(QColor(26, 31, 43, 0), QColor(230, 233, 240, 77), lit))
    pad = h * 0.083
    kd = h - 2 * pad
    step = w - 2 * pad - kd
    soft = QColor(theme.SOFT.red(), theme.SOFT.green(), theme.SOFT.blue(), 72)
    ei = kd * 0.6
    for i, name in ((0, "dock_pets"), (1, "dock_gather")):      # faint icons at both ends
        away = min(1.0, abs(pos - i))
        if away > 0.05:
            c_ = QColor(soft)
            c_.setAlpha(int(72 * away))
            ex = r.x() + pad + i * step + (kd - ei) / 2
            _upright(p, QRectF(ex, cy - ei / 2, ei, ei), upright,
                     lambda q, n=name, c=c_: theme.draw_tinted(p, theme.UI._inst, n, q, c))
    kx = r.x() + pad + step * pos
    kr = QRectF(kx, r.y() + pad, kd, kd)
    if lit > 0.02:                                    # soft glow around the lit knob
        from PySide6.QtGui import QRadialGradient
        gr = kd * 0.5 + 9 * (h / 40)
        g = QRadialGradient(kr.center(), gr)
        g.setColorAt(kd * 0.5 / gr * 0.92, QColor(230, 233, 240, int(140 * lit)))
        g.setColorAt(1.0, QColor(230, 233, 240, 0))
        p.setPen(Qt.NoPen)
        p.setBrush(g)
        p.drawEllipse(kr.center(), gr, gr)
    rr(p, kr, kd / 2, theme._mix(QColor("#3A4152"), theme.LIT, lit))
    m = kd * 0.2
    for i, name in ((0, "dock_pets"), (1, "dock_gather")):
        near = max(0.0, 1 - abs(pos - i))
        if near > 0.02:
            c_ = theme._mix(QColor("#8A92A3"), theme.INK, lit)   # dark knob: a soft grey icon
            c_.setAlpha(int(230 * near))
            _upright(p, kr.adjusted(m, m, -m, -m), upright,
                     lambda q, n=name, c=c_: theme.draw_tinted(p, theme.UI._inst, n, q, c))


def _upright(p, rect, deg, draw):
    """Draw into rect, turned back by deg around its centre (icons stay upright on a vertical switch)."""
    if not deg:
        draw(rect)
        return
    c = rect.center()
    p.save()
    p.translate(c)
    p.rotate(deg)
    p.translate(-c)
    draw(rect)
    p.restore()


class PillAnim:
    """Where the switch's knob is (slides with a little bounce) and how lit it is (fades)."""

    def __init__(self):
        self.to, self.lit_to = None, None

    def get(self, side, lit_to):
        t = time.time()
        if self.to != side:
            first = self.to is None
            self.frm = float(side) if first else getattr(self, "now", float(side))
            self.to, self.t0 = side, t
        if self.lit_to != lit_to:
            first = self.lit_to is None
            self.lfrm = lit_to if first else getattr(self, "lnow", lit_to)
            self.lit_to, self.lt0 = lit_to, t
        u = min(1.0, (t - self.t0) / 0.38)
        e_ = 1 + 2.45 * (u - 1) ** 3 + 1.45 * (u - 1) ** 2
        self.now = self.frm + (side - self.frm) * e_
        v = min(1.0, (t - self.lt0) / 0.22)
        self.lnow = self.lfrm + (lit_to - self.lfrm) * (1 - (1 - v) ** 2)
        return self.now, self.lnow, (u < 1.0 or v < 1.0)


def draw_pin(p, cx, cy, r, col):
    """Small map-pin glyph."""
    path = QPainterPath()
    path.moveTo(cx, cy + r * 1.25)
    path.cubicTo(cx - r * 1.3, cy - r * 0.1, cx - r * 0.9, cy - r * 1.25, cx, cy - r * 1.25)
    path.cubicTo(cx + r * 0.9, cy - r * 1.25, cx + r * 1.3, cy - r * 0.1, cx, cy + r * 1.25)
    p.setPen(Qt.NoPen)
    p.setBrush(col)
    p.drawPath(path)
    p.setBrush(QColor(0, 0, 0, 120))
    p.drawEllipse(QPointF(cx, cy - r * 0.35), r * 0.38, r * 0.38)


def best_nodes(P, most=None):
    """Busiest gathering areas, best first: [[x, y, nodes]] (items.gather_groups, shared with the dock)."""
    from items import gather_groups, SPOTS
    return [[int(x), int(y), len(g)] for x, y, g in gather_groups(P, most=most or SPOTS)]


def patches(points, cell=7000):
    """Every separate spawn patch of a pet: [(x, y, n)] (spawn points grouped ~70 m apart)."""
    groups = {}
    for x, y in points:
        g = groups.setdefault((int(x // cell), int(y // cell)), [0, 0, 0])
        g[0] += x
        g[1] += y
        g[2] += 1
    return [(gx / n, gy / n, n) for gx, gy, n in groups.values()]


class MapView(QWidget):
    """Layer over the game's big map with pet spawns, kept in sync like this:
    - a worker thread copies the screen as soon as it changes and follows the map's motion frame to frame
      (optical flow: sub-pixel, a few ms);
    - a second thread matches the whole picture against the region map a few times a second, only to
      find it and to cancel any drift;
    - drawing predicts a frame ahead from the current pan / zoom speed, so the icons arrive on screen
      together with the map instead of one frame behind it.
    Click an icon (or a pile of them) for a card with each pet's details."""
    SMALL, BIG, LEAD = 480, 960, 0.016

    def __init__(self, app_dir, data, log, icon_for, want_pets, info_for, enabled, capture):
        super().__init__()
        self.app_dir, self.data, self.log = Path(app_dir), data, log
        self.icon_for, self.want_pets, self.info_for, self.enabled = icon_for, want_pets, info_for, enabled
        self.cap = capture
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool | Qt.WindowDoesNotAcceptFocus)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.setMouseTracking(True)
        self.points, self.points_m, self.kibnum = {}, 0, {}
        self.matcher, self.ready = None, False
        self.state = "off"
        self.active, self.rect = False, None
        self.A, self.world, self.panel, self.panels = None, None, False, []
        self.motion = None                 # (M cur->prev, capture time, frame interval)
        self._covered = False
        self.ver, self.painted, self.seen_t = 0, -1, 0.0
        self.hint, self.last_world, self.miss = None, None, 0
        self.R, self.pending, self.result = None, False, None
        self.next_match = 0.0
        self.prev, self.fps, self.nframe = None, 0.0, 0
        self.op = 0.0
        self.thread = None
        self.hits, self.card, self.card_hits, self.hover = [], None, [], False
        self.cursor = Cursor()
        self.mode = "smooth"                       # icons as sprite windows (the only mode)
        import collections
        self.sprite_specs, self.sprite_key, self.switch_rect = None, None, None
        self.set_enabled = None
        self.click_q = collections.deque()
        self.hidden_until = 0.0
        threading.Thread(target=self._render, daemon=True, name="mapview render").start()
        try:                                       # (world, name, x, y): followed on the minimap
            self.pin = tuple(json.loads((self.app_dir / "maps" / "pin.json").read_text())) or None
        except (OSError, ValueError, TypeError):
            self.pin = None
        self.lag, self.gain, self.tau = 0.03, 1.0, 0.0   # learned: delay, ratio and smoothing of the game's drag
        self.drag_samples, self.own_press = [], False
        self.base_t = 0.0
        self.timer = QTimer(self)
        self.timer.setTimerType(Qt.PreciseTimer)
        self.timer.setInterval(7)
        self.timer.timeout.connect(self._frame)

    def showEvent(self, e):
        super().showEvent(e)
        _exclude_capture(self)

    def _load_points(self):
        p = self.app_dir / "maps" / "live_points.json"
        try:
            m = p.stat().st_mtime
            if m != self.points_m:
                self.points, self.points_m = json.loads(p.read_text(encoding="utf-8")), m
            if not self.kibnum:
                d = json.loads((self.app_dir / "pet_spawns.json").read_text(encoding="utf-8"))
                self.kibnum = d.get("kib_numbers", {})
        except (OSError, ValueError):
            pass

    def status(self):
        z = self._zoom(self.A) if self.A is not None else 0
        extra = f"  world {self.world}  zoom {z:.2f}  {self.fps:.0f} fps  {self.cap.kind}  " \
                f"drag lag {self.lag * 1000:.0f} ms x{self.gain:.2f}" \
            if self.state == "showing" else ""
        layer = getattr(self, "layer", None)
        n = len(layer.wins) if layer else 0
        vis = sum(1 for v in layer.at.values() if v) if layer else 0
        mt = getattr(self, "m_times", None)
        return self.state + extra + f"  icons {vis}/{n}" + (f"  layer error {layer.err}" if layer and layer.err else "") + \
            (f"  M->icons ms {mt}" if mt else "") + \
            (f"  map change {getattr(self, 'swap_d', 0):.0f}/{self.SWAP}" if getattr(self, "swap_d", None) is not None else "")

    def _zoom(self, A):
        r = self.rect
        if A is None or not r:
            return 0
        return 1 / max(1e-12, math.hypot(A[0, 0], A[1, 0])) / max(1, r[2])

    # ---------------------------------------------------- main thread ---- #
    def setup(self):
        if self.ready:
            return True
        if not ensure_cv(self.app_dir, self.log):
            self.state = "no opencv"
            return False
        self._load_points()
        try:
            self.matcher = Matcher(self.app_dir / "maps", self.log)
        except Exception as e:
            self.log(f"map overlay: {e}")
            self.state = "no opencv"
            return False
        self.ready = True
        threading.Thread(target=self._warm, daemon=True, name="mapview work").start()
        return True

    def _warm(self):
        """Every map's matching data loaded in the background now, so the first M after a start (or an
        update) finds the map as fast as later ones."""
        try:
            for w in self.matcher.worlds():
                self.matcher.feats_for(w)
                time.sleep(0.05)
        except Exception as e:
            self.log(f"map overlay: warm-up: {e}")

    def tick(self, game_fg, hwnd, covered, rect):
        """~10 times a second from the main loop: whether to run, and where the game is."""
        # M just pressed (the big map's key): start looking at once, before the health bars disappear
        # (an M pressed while the map was open is closing it: nothing to look for)
        mk = getattr(self.cursor, "m_key", 0)
        if mk != getattr(self, "_mk_seen", 0):
            self._mk_seen, self._m_was_open = mk, bool(self.active and self.A is not None)
        m_open = time.time() - getattr(self.cursor, "m_key", 0) < 1.2 and not getattr(self, "_m_was_open", False)
        self._game_fg = bool(game_fg)
        self.cursor.fg = bool(game_fg)
        self._covered = bool(covered)
        if game_fg and not self.cursor.on:
            self.cursor.on = True
        on = bool(game_fg and (covered or m_open) and rect and rect[2] > 400) and self.setup()
        if on and (not self.points or not self.matcher.worlds()):
            self._load_points()
            self.state = "no maps"
            on = False
        if on:
            self.rect = tuple(rect)
            if hwnd != getattr(self, "_hwnd", hwnd):        # a new game window (restarted, reconnected):
                self.A, self.prev, self.hint, self.card = None, None, None, None   # never trust the old map
                self.motion, self.miss = None, 0
            self._hwnd = hwnd
            zw = getattr(self.data, "world", None)
            if zw != getattr(self, "_zone_seen", zw):      # teleported / another zone: the old map is wrong
                self.A, self.prev, self.hint, self.card = None, None, None, None
                self.motion, self.miss, self.last_world = None, 0, None
            self._zone_seen = zw
            if not self.active:
                self.olog("active (looking)")
                self.active, self.next_match = True, 0.0
                # Opened again: the last map is only a hint for the first match, never shown until that match
                # confirms it (it kept Elyos icons on the Abyss map after a teleport, 13 Nov).
                if self.A is not None:
                    self.hint, self.A = self.A, None
                self.motion, self.prev = None, None
                self.wake_t = 0.0
                if self.thread is None or not self.thread.is_alive():
                    self.thread = threading.Thread(target=self._run, daemon=True, name="big map")
                    self.thread.start()
            if not self.timer.isActive():
                self.timer.start()
        elif self.active:
            self.active, self.card = False, None
            if self.state == "showing":
                self.state = "idle"

    def _outside_clicks(self):
        """A click anywhere that isn't the card or an icon closes the card. Only a real click: a press
        that drags the map (pans it) more than a few pixels before letting go leaves the card open."""
        pr, r = self.cursor.presses, self.rect
        while pr:
            t0, x, y = pr[0]
            held = [q for q in list(self.cursor.hist) if q[0] >= t0]
            rel = next((i for i, q in enumerate(held) if not q[3]), None)
            if rel is None:                                  # still held: decide when it's let go
                if time.time() - t0 < 1.0:
                    return
                pr.popleft()                                 # held a long time: a drag, not a click
                continue
            pr.popleft()
            if any(abs(q[1] - x) > 4 or abs(q[2] - y) > 4 for q in held[:rel + 1]):
                continue                                     # dragged the map: keep the card
            if self.card and r:
                lx, ly = x - r[0], y - r[1]
                on_card = self.card.get("rect") is not None and self.card["rect"].contains(QPointF(lx, ly))
                on_icon = self._icon_under(lx, ly) is not None or \
                    any(math.hypot(h[0] - lx, h[1] - ly) <= h[2] * 1.25 for h in self.hits) or \
                    any(math.hypot(v[0] + w / 2 - x, v[1] + w / 2 - y) <= w / 2 for _k, v, w in self._sprite_places())
                if not on_card and not on_icon:
                    self.card = None
                    self.update()

    # ------------------------------------------------- smooth (sprites) ---- #
    def _sync_sprites(self):
        """(GUI thread) draw one icon picture per spawn group of the pets you still need; the render
        thread turns them into windows."""
        pts = self.points.get(self.world) if self.world else None
        shown = self.shown(pts) if pts else {}
        key = (self.world, self.layer_mode(), tuple(sorted(shown)), self.mode, self.rect[2] if self.rect else 0)
        if key == self.sprite_key:
            return
        self.sprite_key = key
        specs = []
        if self.mode == "smooth" and pts and self.rect:
            from PySide6.QtGui import QImage
            s = max(0.7, min(1.6, self.rect[2] / 1920))
            sz = 26 * s
            side = int(sz + 6 * s)
            for name, e in shown.items():
                ring = self.ring(e)
                img = QImage(side, side, QImage.Format_ARGB32_Premultiplied)
                img.fill(0)
                p = QPainter(img)
                p.setRenderHint(QPainter.Antialiasing)
                p.setRenderHint(QPainter.SmoothPixmapTransform)
                MapView._pet_icon(p, QRectF(3 * s, 3 * s, sz, sz), self.icon(name, e), ring, s)
                p.end()
                data = bytes(img.constBits())[:side * side * 4]
                for ci, (x, y, n) in enumerate(e.get("c", [])):
                    specs.append(((name, (x, y), ci), side, side, data))
        self.sprite_specs = (self.sprite_specs[0] + 1 if self.sprite_specs else 1, specs)

    def _on_sprite_click(self, hwnd):          # render thread: hand it to the GUI thread
        self.click_q.append(hwnd)

    def _render(self):
        """Render thread for smooth mode: owns the icon windows; right after each screen refresh it moves
        all of them, in one batch, to where the map will be when the next refresh shows it."""
        import ctypes
        try:
            dwm = ctypes.windll.dwmapi
            layer = SpriteLayer(self._on_sprite_click, self.log)
        except Exception as e:
            self.log(f"map overlay: smooth mode unavailable: {e}")
            return
        self.layer = layer
        built = 0
        while True:
            try:
                if dwm.DwmFlush() != 0:
                    time.sleep(0.008)
            except Exception:
                time.sleep(0.008)
            try:
                layer.pump()
                spec = self.sprite_specs
                if spec and spec[0] != built:
                    built = spec[0]
                    layer.build(spec[1])
                if not layer.wins:
                    continue
                show = self.mode == "smooth" and self.active and self.A is not None and self.enabled() and \
                    time.time() >= self.hidden_until and time.time() - self.seen_t < 0.5 and self.miss == 0
                # gone the instant the map is closed or starts to move (pan or zoom), so nothing ever
                # jiggles or lingers; back with a short fade once it has stood still for a moment
                tn = time.time()
                dt = min(0.05, tn - getattr(self, "_fop_t", tn))
                self._fop_t = tn
                if self.moving():
                    self._still_t = None
                elif getattr(self, "_still_t", None) is None:
                    self._still_t = tn
                settled = self._still_t is not None and tn - self._still_t > 0.10
                fop = getattr(self, "fop", 0.0)
                if not show:
                    self._first_show = True                       # closed / lost: next time, at once
                if show and getattr(self, "_first_show", True) and not self.moving():
                    fop, self._first_show, settled = 1.0, False, True   # just opened: no wait, no fade
                fop = min(1.0, fop + dt / 0.15) if show and settled else 0.0
                self.fop = fop
                show = show and fop > 0.01
                A = self._predicted(0.014) if show else None
                pts = self.points.get(self.world) if A is not None else None
                places = {}
                if pts:
                    np = self.matcher.np
                    Ai = np.linalg.inv(A)
                    r = self.rect
                    gx0, gx1, gy0, gy1 = pts["bounds"]
                    left, top = r[2] * (0.3 if self.panel else 0), r[3] * 0.07
                    panels = self.panels + list(getattr(self, "own_rects", []))
                    for k, (hwnd, w, h) in layer.wins.items():
                        x, y = k[1]
                        uu, vv = (x - gx0) / (gx1 - gx0), (y - gy0) / (gy1 - gy0)
                        X = Ai[0, 0] * uu + Ai[0, 1] * vv + Ai[0, 2]
                        Y = Ai[1, 0] * uu + Ai[1, 1] * vv + Ai[1, 2]
                        ok = left <= X <= r[2] and top <= Y <= r[3] and not self.steps_aside(k[0]) and \
                            not any(px <= X <= px + pw and py <= Y <= py + ph for px, py, pw, ph in panels)
                        places[k] = (round(r[0] + X - w / 2), round(r[1] + Y - h / 2)) if ok else None
                else:
                    places = {k: None for k in layer.wins}
                layer.move(places)
                layer.alpha(int(255 * getattr(self, "fop", 1.0)))
            except Exception as e:
                self.log(f"map overlay: {e}")
                time.sleep(0.5)

    def _sprite_places(self):
        layer = getattr(self, "layer", None)
        return [(k, v, layer.wins[k][1]) for k, v in list(layer.at.items()) if v and k in layer.wins] if layer else []

    def sprite_click(self, hwnd):
        """Icons can't be clicked any more (clicks go through to the game): hover shows the spotlight."""
        return
        layer = getattr(self, "layer", None)
        key = next((k for k, (h, _w, _h) in list(layer.wins.items()) if h == hwnd), None) if layer else None
        at = layer.at.get(key) if key else None
        if not at:
            return
        side = layer.wins[key][1]
        near = sorted((k for k, v, w in self._sprite_places() if math.hypot(v[0] - at[0], v[1] - at[1]) < side * 0.9),
                      key=lambda k: math.hypot(layer.at[k][0] - at[0], layer.at[k][1] - at[1]))
        names = [(k[0], k[1], k[2]) for k in near][:6]
        same = self.card and [(n[0], n[2]) for n in self.card["pets"]] == [(n[0], n[2]) for n in names]
        self.card = None if same else {"pets": names, "at": names[0][1], "t": time.time()}
        self.own_press = False
        self.update()

    def set_mode(self, mode):
        self.mode = mode
        self.sprite_key = None
        try:
            (self.app_dir / "maps" / "mapmode.json").write_text(json.dumps({"mode": mode}))
        except OSError:
            pass
        self.update()

    def _frame(self):
        self.cursor.on = self.active or getattr(self, "_game_fg", False)   # M must be seen before the map opens
        if self.active and self.cursor.close_key > self.hidden_until - 0.6 and \
                time.time() - self.cursor.close_key < 0.3 and self.A is not None:
            self.hidden_until = time.time() + 0.6           # M / Esc: gone this very frame, no fade
            self.op, self.card = 0.0, None
            self.A, self.prev = None, None
        if time.time() < self.hidden_until:
            if self.isVisible():
                self.hide()
            return
        if self.active and self.world:
            self._sync_sprites()
        while self.click_q:
            self.sprite_click(self.click_q.popleft())
        self._spot_step()
        live = self.active and self.A is not None and time.time() - self.seen_t < 0.5
        self.op = 1.0 if live else 0.0                               # there at once, gone at once
        if self.op > 0:
            r = self.rect
            if r and self.geometry().getRect() != r:
                self.setGeometry(*r)
            if not self.isVisible():
                self.show()
                from ui import no_activate
                no_activate(self)
            self._outside_clicks()
            if self.mode == "classic" and (self.ver != self.painted or self.op < 1 or self._dragging()):
                self.update()
            slot = self.dock_slot() if getattr(self, "dock_slot", None) else None
            slot = tuple(round(v) for v in slot) if slot else None
            if slot != getattr(self, "_slot_seen", None):      # the round button moved / opened
                self._slot_seen = slot
                self.ver += 1
            if self.mode == "smooth":
                mv_now = self.moving()
                if mv_now != getattr(self, "_dots_moving", None):   # the dots go the moment a drag starts
                    self._dots_moving = mv_now
                    self.update()
                fop = getattr(self, "fop", 1)
                hidden = fop <= 0.01 and getattr(self, "_painted_hidden", False)
                if self.op < 1 or (self.ver != self.painted and not hidden) or \
                        0 < fop < 1 or (fop <= 0.01) != getattr(self, "_painted_hidden", False):   # dots + card
                    self.update()                            # while hidden for a pan: no full-screen redraws
                elif self.card and time.time() - self.card.get("t", 0) < 0.25:
                    r = self.card.get("rect")                # only the card is moving: redraw just the card
                    self.update(r.adjusted(-4, -4, 4, 14).toAlignedRect() if r is not None else self.rect_())
        else:
            if self.isVisible():
                self.hide()
            if not self.active:
                self.timer.stop()

    def moving(self):
        """The map is being dragged or zoomed (icons hide until it settles). A drag counts once the mouse
        has moved a few px with the button held, so a plain click on an icon doesn't hide them."""
        if time.time() - getattr(self, "moved_t", 0) < 0.12:
            return True
        if not self._dragging():
            return False
        lp, h = self.cursor.last_press, self.cursor.hist
        return bool(lp and h and math.hypot(h[-1][1] - lp[1], h[-1][2] - lp[2]) > 3)

    def _dragging(self):
        r = self.rect
        h = self.cursor.hist
        if not h or not h[-1][3] or self.own_press or not r:
            return False
        if not self.cursor.last_press:
            return False
        _t, x, y = self.cursor.last_press
        lx, ly = x - r[0], y - r[1]
        if not (0 <= lx < r[2] and 0 <= ly < r[3]) or lx < r[2] * (0.3 if self.panel else 0):
            return False
        return not any(px <= lx <= px + pw and py <= ly <= py + ph
                       for px, py, pw, ph in self.panels + list(getattr(self, "own_rects", [])))

    def _follow(self, t, L, tau):
        """Where the game's map would have moved to by time t (screen px), given the mouse history:
        the mouse delayed by L and smoothed with time constant tau."""
        h = list(self.cursor.hist)       # a copy: the cursor thread keeps adding to it
        if not h:
            return None
        t = t - L
        y = None
        tp = None
        for (ts, x, yy, _d) in h:
            if ts - t > 0:
                break
            if y is None or tau <= 0:
                y = [x, yy]
            else:
                k = 1 - math.exp(-(ts - tp) / tau)
                y[0] += (x - y[0]) * k
                y[1] += (yy - y[1]) * k
            tp = ts
        if y is None:
            return None
        if tau > 0 and tp is not None and t > tp:          # past the last sample: keep easing toward it
            last = h[-1]
            k = 1 - math.exp(-(t - tp) / tau)
            y = [y[0] + (last[1] - y[0]) * k, y[1] + (last[2] - y[1]) * k]
        return y

    def _predicted(self, ahead=0.010):
        """Where the map is on screen right now. While you drag it, it moves exactly with your mouse
        (as the game's map does, with the same small delay the game has); otherwise it's where the last
        screen copy saw it. No guessing from speed, so nothing overshoots."""
        np = self.matcher.np
        A = self.A
        if A is None:
            return None
        if self.gain > 0.3 and self._dragging():
            now = time.time() + ahead                 # this frame reaches the screen a little later
            a = self._follow(now, self.lag, self.tau)
            b = self._follow(self.base_t, self.lag, self.tau)
            if a and b:
                dx, dy = (a[0] - b[0]) * self.gain, (a[1] - b[1]) * self.gain
                if abs(dx) + abs(dy) > 0.2:
                    T = np.array([[1.0, 0, -dx], [0, 1.0, -dy], [0, 0, 1.0]])
                    A = A @ T
        return A

    def _learn_drag(self):
        """Fit the game's drag delay, smoothing and ratio from what the screen copies saw vs the mouse."""
        np = self.matcher.np
        sm = self.drag_samples[-90:]
        h = list(self.cursor.hist)
        if len(sm) < 30 or len(h) < 50:
            return
        T = np.array([q[0] for q in h])
        X = np.array([q[1] for q in h], float)
        Y = np.array([q[2] for q in h], float)
        t0 = np.array([q[0] for q in sm])
        t1 = np.array([q[1] for q in sm])
        mx = np.array([q[2] for q in sm])
        my = np.array([q[3] for q in sm])
        best = None
        for tau in (0.0, 0.012, 0.025, 0.04, 0.06, 0.09):
            fx, fy = X.copy(), Y.copy()
            if tau > 0:                                       # the smoothed mouse path
                dt = np.diff(T, prepend=T[0])
                k = 1 - np.exp(-dt / tau)
                for i in range(1, len(fx)):
                    fx[i] = fx[i - 1] + (X[i] - fx[i - 1]) * k[i]
                    fy[i] = fy[i - 1] + (Y[i] - fy[i - 1]) * k[i]
            for L in [i * 0.004 for i in range(0, 16)]:
                cx = np.interp(t1 - L, T, fx) - np.interp(t0 - L, T, fx)
                cy = np.interp(t1 - L, T, fy) - np.interp(t0 - L, T, fy)
                den = float((cx * cx + cy * cy).sum())
                if den < 400:
                    continue
                g = float((cx * mx + cy * my).sum()) / den
                err = float(((mx - g * cx) ** 2 + (my - g * cy) ** 2).sum())
                if best is None or err < best[0]:
                    best = (err, L, g, tau)
        if best:
            _e, self.lag, self.gain, self.tau = best
        self.drag_samples = self.drag_samples[-60:]

    def _run(self):
        cv2, np = self.matcher.cv2, self.matcher.np
        last_t = None
        while True:
            if not self.active:
                self.motion, self.miss = None, 0            # keep A and the last frame: back from alt-tab,
                time.sleep(0.05)                            # the first new frame confirms it at once
                continue
            try:
                rect = self.rect
                t_cap = time.time()
                full = self.cap.grab(rect, np, cv2)
                mo = getattr(self, "m_open_t", 0)
                if mo and self.A is None and getattr(self, "_olog_fr", None) != mo:
                    self._olog_fr = mo
                    self.olog("first screen picture" if full is not None else "first grab: screen unchanged")
                if full is None:                          # nothing changed on screen: still right
                    if self.motion is not None and t_cap - self.motion[1] > 0.05:
                        self.motion = None
                    if self.A is not None and self.miss == 0 and \
                            (t_cap - self.seen_t < 5 or t_cap - getattr(self, "wake_t", 0) < 2):
                        self.seen_t = t_cap
                    res, self.result = self.result, None    # a match finished while the map stood still
                    if res is not None:
                        self._correct(res)
                    lf = getattr(self, "last_full", None)
                    tries = self.__dict__.setdefault("_still_tries", [None, 0])
                    if lf is not None and tries[0] is not lf:
                        tries[0], tries[1] = lf, 0
                    if lf is not None and tries[1] < 2 and not self.pending and t_cap >= self.next_match and \
                            t_cap - getattr(self, "_still_since", t_cap) > 0.25:
                        tries[1] += 1                         # the same still picture: two looks, then rest
                        bh = max(2, int(self.BIG * rect[3] / rect[2]))
                        big = cv2.resize(lf, (self.BIG, bh), interpolation=cv2.INTER_AREA)
                        self.pending, self.R = True, np.eye(3)
                        self._verify = self.A is not None     # icons up: make sure it's still the map
                        threading.Thread(target=self._match, args=(big, rect), daemon=True, name="mapview match").start()
                    time.sleep(0.002)
                    continue
                self.last_full = full
                self._still_since = t_cap                     # when the screen last changed
                if self.state == "looking" and time.time() - getattr(self, "_look_t", time.time()) > 3:
                    _diag_save(self.app_dir, "map_frame.jpg", full, cv2, f"{self.cap.kind} {full.shape} "
                               f"mean {float(full.mean()):.1f} world {self.world} rect {self.rect}")
                sh = max(2, int(self.SMALL * rect[3] / rect[2]))
                small = cv2.resize(full, (self.SMALL, sh), interpolation=cv2.INTER_AREA)
                f = rect[2] / self.SMALL
                self.nframe += 1
                if self.nframe % 6 == 1:
                    self.panels = [tuple(v * f for v in r) for r in ui_panels(small, np, cv2)]
                if (self.A is not None or self.pending) and self.prev is not None and self.prev.shape == small.shape:
                    M = self._flow(self.prev, small, f)
                    if M is not None and self.A is not None and self._swapped(self.prev, small, M, f):
                        # another map in the same window (the map menu's region switch, an Abyss map...):
                        # icons off at once, the old map forgotten, every map tried again
                        self.hint, self.A, self.motion, self.card = None, None, None, None
                        self.miss, self.last_world, self.next_match, M = 0, None, 0.0, None
                        self.state = "looking"
                    if M is not None:
                        if self.R is not None:
                            self.R = self.R @ M
                        if self.A is not None:
                            self.A = self.A @ M
                            self.base_t = t_cap
                            self.miss = 0
                            dt = (t_cap - last_t) if last_t else 0.016
                            self.motion = (M, t_cap, min(0.05, max(0.004, dt)))
                            if abs(M[0, 0] - 1) > 0.0015 or abs(M[0, 2]) + abs(M[1, 2]) > 1.5:
                                self.moved_t = t_cap
                            if last_t and self._dragging() and abs(M[0, 0] - 1) < 0.002:
                                self.drag_samples.append((last_t, t_cap, -M[0, 2], -M[1, 2]))
                                if len(self.drag_samples) % 30 == 0:
                                    self._learn_drag()
                            self._publish()
                    elif self.A is not None:
                        self.miss += 1
                        if self.miss > 6:                  # lost it (map closed, region switched, menu...)
                            self.hint, self.A, self.motion, self.card = self.A, None, None, None
                    else:
                        self.R = None
                self.prev, last_t = small, t_cap
                res, self.result = self.result, None
                if res is not None:
                    self._correct(res)
                opening = self.A is None and time.time() - getattr(self.cursor, "m_key", 0) < 2.0
                if not self.pending and t_cap >= self.next_match and not (opening and not self._covered):
                    # (just after M the map is still opening: a search then fails and costs ~1 s on her laptop)
                    bh = max(2, int(self.BIG * rect[3] / rect[2]))
                    big = cv2.resize(full, (self.BIG, bh), interpolation=cv2.INTER_AREA)
                    self.pending, self.R, self._verify = True, np.eye(3), False
                    threading.Thread(target=self._match, args=(big, rect), daemon=True, name="mapview match").start()
                self.fps = 0.92 * self.fps + 0.08 / max(1e-3, time.time() - t_cap + 0.0001) if False else \
                    0.92 * self.fps + 0.08 * (1 / max(1e-3, t_cap - getattr(self, "_fps_t", t_cap - 0.016)))
                self._fps_t = t_cap
                if self.cap.kind.startswith("gdi"):
                    time.sleep(0.004)
            except Exception as e:
                self.log(f"map overlay: {e}")
                time.sleep(0.5)

    SWAP = 30               # median grey difference after following the motion: ~2 for a pan, ~90 for another map

    def _swapped(self, prev, cur, M, f):
        """The picture no longer matches the last frame moved by M: a different map is showing (two frames
        in a row, so a passing tooltip or fade doesn't count). Tuned on her real map frames, 13 Nov."""
        cv2, np = self.matcher.cv2, self.matcher.np
        h, w = prev.shape
        Ms = M[:2].copy()
        Ms[:, 2] /= f
        pred = cv2.warpAffine(prev, Ms, (w, h), flags=cv2.WARP_INVERSE_MAP | cv2.INTER_LINEAR,
                              borderMode=cv2.BORDER_REPLICATE)
        y0, y1 = int(h * 0.1), int(h * 0.93)
        x0, x1 = int(w * (0.3 if self.panel else 0.02)), int(w * 0.95)
        d = float(np.median(cv2.absdiff(cur[y0:y1, x0:x1], pred[y0:y1, x0:x1])))
        self.swap_d = d
        n = getattr(self, "_swap_n", 0) + 1 if d > self.SWAP else 0
        self._swap_n = n
        return n >= 2

    def _flow(self, prev, cur, f):
        """How the map moved between two frames: 3x3 (current window px -> previous window px) or None."""
        cv2, np = self.matcher.cv2, self.matcher.np
        h, w = prev.shape
        if cv2.norm(prev, cur, cv2.NORM_L1) < 0.6 * w * h:      # practically the same picture
            return np.eye(3)
        mask = np.zeros_like(prev)
        mask[int(h * 0.1):int(h * 0.93), int(w * (0.3 if self.panel else 0.02)):int(w * 0.95)] = 255
        for x, y, ww, hh in self.panels:                           # not on game windows over the map
            mask[max(0, int(y / f)):int((y + hh) / f), max(0, int(x / f)):int((x + ww) / f)] = 0
        p0 = cv2.goodFeaturesToTrack(prev, 260, 0.01, 6, mask=mask, blockSize=5)
        if p0 is None or len(p0) < 25:
            return None
        lk = dict(winSize=(21, 21), maxLevel=3, criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 20, 0.03))
        p1, st, _ = cv2.calcOpticalFlowPyrLK(prev, cur, p0, None, **lk)
        back, st2, _ = cv2.calcOpticalFlowPyrLK(cur, prev, p1, None, **lk)
        ok = (st.ravel() == 1) & (st2.ravel() == 1) & (np.abs(back - p0).reshape(-1, 2).max(1) < 0.8)
        if ok.sum() < 20:
            return None
        M, inl = cv2.estimateAffinePartial2D(p1[ok], p0[ok], method=cv2.RANSAC, ransacReprojThreshold=1.0)
        if M is None or inl is None or inl.sum() < 18:
            return None
        sc = math.hypot(M[0, 0], M[1, 0])
        if abs(math.atan2(M[1, 0], M[0, 0])) > 0.02 or not 0.6 < sc < 1.7:
            return None
        M = M.astype(np.float64)
        if abs(sc - 1) < 0.003:                         # just a pan: no zoom / turn noise at all
            d = np.median((p0[ok] - p1[ok]).reshape(-1, 2)[inl.ravel() == 1], axis=0)
            M = np.array([[1.0, 0, d[0]], [0, 1.0, d[1]]])
        M[:, 2] *= f
        return _m3(M)

    def _shown_pic(self, big, w):
        """samples/shown_N.jpg (newest 6): the screen each time the icons appeared, so icons showing over the
        wrong window can be checked afterwards (her: "icons show on full-screen windows")."""
        try:
            cv2 = self.matcher.cv2
            d = self.app_dir / "samples"
            d.mkdir(exist_ok=True)
            n = getattr(self, "_shown_n", 0)
            self._shown_n = n + 1
            small = cv2.resize(big, (480, max(2, int(480 * big.shape[0] / big.shape[1]))))
            cv2.imwrite(str(d / f"shown_{n % 6}.jpg"), small, [cv2.IMWRITE_JPEG_QUALITY, 70])
            with open(d / "shown_log.txt", "a", encoding="utf-8") as f:
                f.write(f"{time.strftime('%H:%M:%S')} shown_{n % 6}.jpg world {w}\n")
        except Exception:
            pass

    def _match(self, big, rect):
        np = self.matcher.np
        t_m = time.time()
        try:
            k = self.BIG / rect[2]
            S = np.diag([k, k, 1.0])
            cur = self.A if self.A is not None else self.hint
            prev2 = (cur @ np.linalg.inv(S))[:2] if cur is not None else None
            order = []
            if prev2 is not None and (self.world or self.last_world):
                order.append((self.world or self.last_world, prev2))
            wl = self.data.world
            if self.A is None:                            # opening: the map opens centred on you, at the zoom
                pr = self._pos_prior(rect, S)             # you used last: look only there first (~6x faster)
                if pr is not None:
                    order.insert(0, pr)
            for c in ([str(wl)] if wl is not None else []) + ([self.last_world] if self.last_world else []) + \
                    self.matcher.worlds():
                if c in self.KR_ONLY and str(wl) != c:
                    continue                              # Eltnen / Morheim: not in the Global version
                if c and c in self.points and c not in [o[0] for o in order if o[1] is None]:
                    order.append((c, None))
            n_pr = sum(1 for o in order if o[1] is not None)  # guided tries are cheap: always keep them
            if self.A is None and self.miss % 4 and len(order) > n_pr + 2:
                order = order[:n_pr + 2]
            if self.A is None and time.time() - getattr(self.cursor, "m_key", 0) < 2.0 and self.data.world:
                order = order[:n_pr + 1]                 # opening: around you, then just the map you're on
            H, w = None, None
            for c, pv in order:
                H = self.matcher.match(big, c, pv, 0.6 if pv is not None and self.A is None else 0.25)
                if H is not None:
                    w = c
                    break
                if self.A is not None:
                    break
            if self.A is None and getattr(self, "m_open_t", 0):
                self.olog(f"match {'ok ' + str(w) if H is not None else 'failed'} ({int((time.time() - t_m) * 1000)} ms,"
                          f" tried {[o[0] + ('*' if o[1] is not None else '') for o in order]})")
            if H is None:
                if self.A is None:
                    self.miss += 1
                    self.state = "looking"
                    self._look_t = time.time()
                    opening = time.time() - getattr(self.cursor, "m_key", 0) < 2.0
                    self.next_match = time.time() + (0.0 if opening else 0.3 if self.miss < 8 else
                                                     0.9 if self.miss < 30 else 1.5)
                elif getattr(self, "_verify", False):
                    self._vfail = getattr(self, "_vfail", 0) + 1
                    if self._vfail >= 2:                    # the still picture isn't the map: icons off
                        self.hint, self.A, self.motion, self.card, self._vfail = self.A, None, None, None, 0
                        self.state = "looking"
                    self.next_match = time.time() + 0.8
                else:
                    self.next_match = time.time() + 0.3
                return
            col = big[int(big.shape[0] * 0.2):int(big.shape[0] * 0.8), int(big.shape[1] * 0.15)]
            self.panel = float(col.mean()) < 70 and float(col.std()) < 30
            if self.A is None:                            # found the map after not having it: keep a picture
                self._shown_pic(big, w)
            self.result = (w, _m3(H) @ S)
            self._vfail = 0
            self.next_match = time.time() + 0.35
        except Exception as e:
            self.log(f"map overlay: {e}")
            self.next_match = time.time() + 1.0
        finally:
            self.pending = False

    def _correct(self, res):
        np = self.matcher.np
        w, Hk = res
        if self.R is None:
            return
        new = Hk @ self.R
        if self.A is None or w != self.world:
            self.A, self.card = new, None
        else:
            r = self.rect
            c = np.array([r[2] / 2, r[3] / 2, 1.0])
            a, b = self.A @ c, new @ c
            px = np.hypot(*(a - b)[:2]) / max(1e-12, math.hypot(self.A[0, 0], self.A[1, 0]))
            if px > 25:
                self.A, self.card = new, None
            elif px > 1.2:
                self.A = self.A + (new - self.A) * 0.2
        if w != self.world:
            self.focus, self.hover_focus = None, None          # another map: the list's pick doesn't apply
        self.world, self.last_world, self.miss = w, w, 0
        self.last_k = math.hypot(self.A[0, 0], self.A[1, 0])   # the zoom you use (for the next opening)
        self.state = "showing"
        self.olog("found the map")
        self._publish()

    def _publish(self):
        self.seen_t = time.time()
        self.ver += 1

    KR_ONLY = {"1011", "1111"}      # Eltnen / Morheim: Korea / Taiwan only, never tried unless you're there

    def _pos_prior(self, rect, S):
        """(world, 2x3 guess in big-picture px) from where you stand (the minimap) and the zoom you used
        last; None if either is unknown."""
        np = self.matcher.np
        k = getattr(self, "last_k", None)
        f = getattr(self, "me_fn", None)
        me = f() if f else None
        if not k or not me or time.time() - me[3] > 120 or str(me[0]) not in self.points:
            return None
        gx0, gx1, gy0, gy1 = self.points[str(me[0])]["bounds"]
        u, v = (me[1] - gx0) / (gx1 - gx0), (me[2] - gy0) / (gy1 - gy0)
        A = np.array([[k, 0.0, u - k * rect[2] / 2], [0.0, k, v - k * rect[3] / 2], [0.0, 0.0, 1.0]])
        return str(me[0]), (A @ np.linalg.inv(S))[:2]

    def olog(self, ev):
        """Timeline of one map opening (ms after M), to find what makes the icons late. Written to
        samples/map_open_log.txt once the icons show (or 8 s after M)."""
        mk = getattr(self.cursor, "m_key", 0)
        t0 = getattr(self, "m_open_t", 0) or (mk if time.time() - mk < 3 and self.A is None else 0) or \
            getattr(self, "_olog_t0", 0)
        if not t0:
            return
        if t0 != getattr(self, "_olog_t0", None):
            self._olog_t0, self._olog = t0, []
        if len(self._olog) < 60:
            self._olog.append(f"{int((time.time() - t0) * 1000)} {ev}")
        if ev.startswith("icons") or time.time() - t0 > 8:
            self._olog_flush()

    def _olog_flush(self):
        lg, self._olog, self._olog_t0 = getattr(self, "_olog", []), [], None
        if not lg:
            return
        try:
            p = self.app_dir / "samples" / "map_open_log.txt"
            old = p.read_text(encoding="utf-8").splitlines()[-200:] if p.exists() else []
            old.append(time.strftime("%H:%M:%S") + "  " + " | ".join(lg))
            p.write_text("\n".join(old) + "\n", encoding="utf-8")
        except OSError:
            pass

    # ----------------------------------------------------------- clicks ---- #
    def mouseReleaseEvent(self, e):
        self.own_press = False
        drag, self._sw_drag = getattr(self, "_sw_drag", None), None
        if drag is None:
            return
        if not drag[2]:                                   # a click: the part of the switch you clicked
            r = self.switch_rect
            if getattr(self, "_sw_docked", False) and r is not None and getattr(self, "set_layer", None):
                side = "pets" if (drag[3] - r.x()) / max(1.0, r.width()) < 0.5 else "gather"
                self.set_layer(side)                                # pets or gathering (no hiding here)
            elif getattr(self, "set_layer", None):        # the free-standing pill: next one along
                order = ("pets", "gather", "off")
                self.set_layer(order[(order.index(self.layer_mode()) + 1) % 3])
            elif self.set_enabled:
                self.set_enabled(not self.enabled())
            self.card = None
        else:
            try:
                (self.app_dir / "maps" / self.SWITCH_PATH).write_text(json.dumps(list(self._sw_pos)))
            except OSError:
                pass
        self.setCursor(Qt.OpenHandCursor)
        self.ver += 1
        self.update()

    def mousePressEvent(self, e):
        self.own_press = True
        pos = e.position()
        if self.switch_rect and self.switch_rect.contains(pos):
            c = self.switch_rect.center()
            self._sw_drag = (pos.x() - c.x(), pos.y() - c.y(), False, pos.x(), pos.y())
            return

        for r, fn in self.card_hits:
            if r.contains(pos):
                fn()
                self.update()
                return
        if self.card and self.card.get("rect") and self.card["rect"].contains(pos):
            return
        hit = self._icon_under(pos.x(), pos.y())            # an icon (the spotlit one under the mouse)
        if hit is not None:
            name, x, y, ci = hit
            same = self.card and [(n[0], n[2]) for n in self.card["pets"]] == [(name, ci)]
            self.card = None if same else {"pets": [(name, (x, y), ci)], "at": (x, y), "t": time.time()}
            self.own_press = False
            self.update()
            return
        near = [h for h in self.hits if math.hypot(h[0] - pos.x(), h[1] - pos.y()) <= h[2] * 1.25]
        if near:
            names = []
            for h in sorted(near, key=lambda h: math.hypot(h[0] - pos.x(), h[1] - pos.y())):
                if (h[3], h[5]) not in [(n[0], n[2]) for n in names]:
                    names.append((h[3], h[4], h[5]))
            same = self.card and [(n[0], n[2]) for n in self.card["pets"]] == [(n[0], n[2]) for n in names]
            self.card = None if same else {"pets": names[:6], "at": names[0][1], "t": time.time()}
        else:
            self.card = None
        self.update()

    def mouseMoveEvent(self, e):
        pos = e.position()
        drag = getattr(self, "_sw_drag", None)
        if drag is not None and getattr(self, "_sw_docked", False):
            return                                        # it lives beside the round button: click only
        if drag is not None:                              # dragging the pill
            moved = drag[2] or math.hypot(pos.x() - drag[3], pos.y() - drag[4]) > 4
            if moved:
                self._sw_drag = drag[:2] + (True,) + drag[3:]
                W, Hh = max(1, self.width()), max(1, self.height())
                self._sw_pos = ((pos.x() - drag[0]) / W, (pos.y() - drag[1]) / Hh)
                self.setCursor(Qt.ClosedHandCursor)
                self.ver += 1
                self.update()
            return
        if self.switch_rect and self.switch_rect.contains(pos):
            if not self.hover:
                self.hover = True
            self.setCursor(Qt.OpenHandCursor)
            return
        over = any(math.hypot(h[0] - pos.x(), h[1] - pos.y()) <= h[2] * 1.25 for h in self.hits) or \
            any(r.contains(pos) for r, _ in self.card_hits)
        if over != self.hover:
            self.hover = over
            self.setCursor(Qt.PointingHandCursor if over else Qt.ArrowCursor)

    # ----------------------------------------------------------- paint ---- #
    def paintEvent(self, _):
        A, w, rect = self._predicted(), self.world, self.rect
        self.hits, self.card_hits = [], []
        if A is None or not rect:
            return
        np = self.matcher.np
        Ai = np.linalg.inv(A)
        self.painted = self.ver
        zoom = self._zoom(A)
        pts = self.points.get(w)
        if not pts:
            return
        from ui import font, text, rr, draw_icon
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        p.setOpacity(self.op)
        W, Hh = rect[2], rect[3]
        reg = QRegion(int(W * (0.3 if self.panel else 0)), int(Hh * 0.07), W, Hh)
        for x, y, ww, hh in self.panels:
            reg = reg.subtracted(QRegion(int(x), int(y), int(ww), int(hh)))
        p.setClipRegion(reg)
        gx0, gx1, gy0, gy1 = pts["bounds"]

        def to(x, y):
            u, vv = (x - gx0) / (gx1 - gx0), (y - gy0) / (gy1 - gy0)
            return Ai[0, 0] * u + Ai[0, 1] * vv + Ai[0, 2], Ai[1, 0] * u + Ai[1, 1] * vv + Ai[1, 2]
        s = max(0.7, min(1.6, W / 1920))
        pets = list(self.shown(pts).items())
        spot = self.focus_names()                         # hovered: drawn bigger below, the rest stay
        fop_d = getattr(self, "fop", 1.0) if self.mode == "smooth" else 1.0
        if self.mode == "smooth" and self.moving():
            fop_d = 0.0                                   # dragging / zooming: no dots left behind
        iso = getattr(self, "iso_focus", None)           # hovering a Gathering list row: only that one
        if fop_d > 0.01:                                  # every real spawn a dot (her pick A, 13 Nov); they
            p.save()                                      # hide and come back with the icons
            p.setOpacity(self.op * fop_d)
            own = QRegion(reg)
            for x, y, ww, hh in getattr(self, "own_rects", []):   # not under our own list / round button
                own = own.subtracted(QRegion(int(x), int(y), int(ww), int(hh)))
            p.setClipRegion(own)
            dd = max(4.0, min(6.5, 3.0 + zoom * 0.5)) * s
            for name, e in pets:
                if name in spot or (iso and name != iso):
                    continue                              # hovered: its spawns are small pictures instead
                vis = []
                for x, y in e["p"]:
                    X, Y = to(x, y)
                    if -10 <= X <= W + 10 and -10 <= Y <= Hh + 10:
                        vis.append(QPointF(X, Y))
                if vis and e.get("res"):                  # materials: always pictures, never dots (her call)
                    mini = self._mini(name, e, int(16 * s))
                    hw = mini.width() / 2
                    for q in vis:
                        p.drawPixmap(QPointF(q.x() - hw, q.y() - hw), mini)
                elif vis:
                    c = self.ring(e)
                    p.setPen(QPen(QColor(0, 0, 0, 150), dd + 2 * s, Qt.SolidLine, Qt.RoundCap))
                    p.drawPoints(vis)
                    c.setAlpha(235)
                    p.setPen(QPen(c, dd, Qt.SolidLine, Qt.RoundCap))
                    p.drawPoints(vis)
            p.restore()
            p.setClipRegion(reg)
        if self.mode == "smooth":
            pets = []                                     # the sprites draw the icons
        sz = 26 * s
        f = font(10.5 * s, 600)
        for name, e in pets:
            if name in spot:
                continue
            ring = self.ring(e)
            pix = self.icon(name, e)
            for ci, (x, y, n) in enumerate(e.get("c", [])):
                X, Y = to(x, y)
                if not (-sz <= X <= W + sz and -sz <= Y <= Hh + sz) or not reg.contains(QPointF(X, Y).toPoint()):
                    continue
                self.hits.append((X, Y, sz / 2, name, (x, y), ci))
                self._pet_icon(p, QRectF(X - sz / 2, Y - sz / 2, sz, sz), pix, ring, s)
                if zoom > 3.0:
                    for dx, dy, col in ((1, 1, QColor(0, 0, 0, 220)), (0, 0, QColor(255, 255, 255, 235))):
                        text(p, X + dx, Y + sz / 2 + 13 * s + dy, name, f, col, align="c")
        fop = getattr(self, "fop", 1.0) if self.mode == "smooth" else 1.0
        self._painted_hidden = fop <= 0.01
        if self.enabled() and fop > 0.01:
            p.save()
            p.setOpacity(self.op * fop)
            self._paint_pinned(p, s, to, pts, reg)
            p.restore()
        if (self.card or self.focus_names()) and self.enabled() and fop > 0.01:
            p.save()
            p.setOpacity(self.op * fop)                       # the glow hides and returns with the icons
            self._paint_glow(p, s, to, pts, W, Hh, reg)
            p.restore()
        if self.card and self.enabled() and fop > 0.01:
            p.save()
            p.setOpacity(self.op * getattr(self, "fop", 1.0))     # the card fades with the icons
            self._paint_card(p, s, to, pts, W, Hh, font, text, rr, draw_icon)
            p.restore()
        self._paint_switch(p, s, W, Hh, font, text, rr)
        p.end()

    def rect_(self):
        from PySide6.QtCore import QRect
        return QRect(0, 0, self.width(), self.height())

    def _paint_glow(self, p, s, to, pts, W, Hh, reg):
        """The clicked pet's farm spots: a soft glow around each one on screen, and an arrow at the map's
        edge pointing to each one that's off screen."""
        names = []
        for n in (self.card.get("pets", []) if self.card else []):
            if n[0] not in names:
                names.append(n[0])
        names = names or self.focus_names()
        p.save()
        for name in (self.focus_names() if not self.card else [])[:1]:   # hovered: every spawn a small picture
            e = self.entry(pts, name)
            if not e:
                continue
            mini = self._mini(name, e, int(18 * s))
            hw = mini.width() / 2
            box_ = reg.boundingRect()
            for x, y in e.get("p", []):
                X, Y = to(x, y)
                if box_.left() <= X <= box_.right() and box_.top() <= Y <= box_.bottom():
                    p.drawPixmap(QPointF(X - hw, Y - hw), mini)
        sz = 26 * s
        box = reg.boundingRect()
        cx, cy = box.center().x(), box.center().y()
        m = 34 * s
        for name in names[:2]:
            e = self.entry(pts, name)
            if not e:
                continue
            ring = self.ring(e)
            for x, y, _n in e.get("c", []):
                X, Y = to(x, y)
                if box.left() + 4 <= X <= box.right() - 4 and box.top() + 4 <= Y <= box.bottom() - 4:
                    k_ = self.spot_scale() or 1.0                 # the spotlight: the icon itself, bigger
                    b_ = sz * k_
                    self._pet_icon(p, QRectF(X - b_ / 2, Y - b_ / 2, b_, b_), self.icon(name, e), ring, s * k_)
                    continue
                dx, dy = X - cx, Y - cy                       # off screen: arrow at the edge
                k = min((box.width() / 2 - m) / max(1e-6, abs(dx)), (box.height() / 2 - m) / max(1e-6, abs(dy)))
                ex, ey = cx + dx * k, cy + dy * k
                ang = math.atan2(dy, dx)
                tip = QPointF(ex + math.cos(ang) * 20 * s, ey + math.sin(ang) * 20 * s)
                l = QPointF(ex + math.cos(ang + 2.5) * 9 * s, ey + math.sin(ang + 2.5) * 9 * s)
                r = QPointF(ex + math.cos(ang - 2.5) * 9 * s, ey + math.sin(ang - 2.5) * 9 * s)
                p.setPen(QPen(QColor(0, 0, 0, 160), 1.5 * s))
                p.setBrush(ring)
                p.drawPolygon(QPolygonF([tip, l, r]))
                self._pet_icon(p, QRectF(ex - sz * 0.42, ey - sz * 0.42, sz * 0.84, sz * 0.84),
                               self.icon(name, e), ring, s * 0.8)
        p.restore()

    def _mini(self, name, e, px):
        """A small round picture of a pet / material, drawn once and reused (hundreds per hover)."""
        cache = self.__dict__.setdefault("_minis", {})
        k = (name, px)
        if k not in cache:
            from PySide6.QtGui import QPixmap
            pm = QPixmap(px + 4, px + 4)
            pm.fill(Qt.transparent)
            q = QPainter(pm)
            q.setRenderHint(QPainter.Antialiasing)
            q.setRenderHint(QPainter.SmoothPixmapTransform)
            self._pet_icon(q, QRectF(2, 2, px, px), self.icon(name, e), self.ring(e), px / 26)
            q.end()
            if len(cache) > 200:
                cache.clear()
            cache[k] = pm
        return cache[k]

    def _paint_pinned(self, p, s, to, pts, reg):
        """The pinned pet (same pin as the minimap's): marked where it is, or held at the map's edge with an
        arrow pointing to it when it's off screen. Clicking it unpins it, so it never has to be hunted for."""
        pin = self.pin
        if not pin or str(pin[0]) != str(self.world):
            return
        e = self.entry(pts, pin[1])
        ring = self.ring(e)
        white = QColor(255, 255, 255)
        sz = 26 * s
        box = reg.boundingRect()
        X, Y = to(pin[2], pin[3])
        m = 40 * s
        inside = box.left() + m <= X <= box.right() - m and box.top() + m <= Y <= box.bottom() - m
        p.save()
        if inside:                                        # a white ring around its icon, pin on top
            p.setPen(QPen(white, 2.2 * s))
            p.setBrush(Qt.NoBrush)
            p.drawEllipse(QPointF(X, Y), sz * 0.72, sz * 0.72)
        else:
            cx, cy = box.center().x(), box.center().y()
            dx, dy = X - cx, Y - cy
            k = min((box.width() / 2 - m) / max(1e-6, abs(dx)), (box.height() / 2 - m) / max(1e-6, abs(dy)))
            X, Y = cx + dx * k, cy + dy * k
            ang = math.atan2(dy, dx)
            tip = QPointF(X + math.cos(ang) * 22 * s, Y + math.sin(ang) * 22 * s)
            l = QPointF(X + math.cos(ang + 2.5) * 10 * s, Y + math.sin(ang + 2.5) * 10 * s)
            r = QPointF(X + math.cos(ang - 2.5) * 10 * s, Y + math.sin(ang - 2.5) * 10 * s)
            p.setPen(QPen(QColor(0, 0, 0, 170), 1.5 * s))
            p.setBrush(white)
            p.drawPolygon(QPolygonF([tip, l, r]))
            self._pet_icon(p, QRectF(X - sz / 2, Y - sz / 2, sz, sz), self.icon(pin[1], e), ring, s)
            p.setPen(QPen(white, 2 * s))
            p.setBrush(Qt.NoBrush)
            p.drawEllipse(QPointF(X, Y), sz * 0.6, sz * 0.6)
        bx, by = X + sz * 0.45, Y - sz * 0.55                   # the pin badge
        badge = QRectF(bx - 8 * s, by - 8 * s, 16 * s, 16 * s)
        p.setPen(Qt.NoPen)
        p.setBrush(white)
        p.drawEllipse(badge)
        draw_pin(p, bx, by, 5 * s, QColor("#0E1118"))
        p.restore()
        hit = QRectF(X - sz * 0.7, Y - sz * 0.75, sz * 1.5, sz * 1.45).united(badge.adjusted(-3, -3, 3, 3))
        self.card_hits.append((hit, lambda: self.toggle_pin(*pin)))

    # --------------------------------------------------------- spotlight ---- #
    # Hover an icon on the map, or a row of the dock's list: that pet's or material's spots pop up bigger
    # (off-screen ones get an arrow at the edge); every other icon stays (her call, 13 Nov). Nothing is clicked.
    SPOT_IN, SPOT_OUT, SPOT_BIG = 0.18, 0.14, 1.4

    def steps_aside(self, name):
        """Hovered: only that pet's / material's own icon windows step aside (it's drawn bigger on the map
        layer); every other icon stays where it is."""
        iso = getattr(self, "iso_focus", None)
        if iso is not None:
            return True                                  # isolated: the painter draws that one, nothing else
        return bool(getattr(self, "spot_hide", False)) and name == getattr(self, "_spot", None)

    def focus_names(self):
        sp = getattr(self, "_spot", None)
        return [sp] if sp and self.spot_scale() is not None else []

    def set_focus(self, name, hover=True, isolate=False):
        """The dock's list: the row under the mouse (None = left the list). isolate (the Gathering list):
        only that material shows until the mouse leaves the row."""
        iso = name if isolate else None
        if name != getattr(self, "hover_focus", None) or iso != getattr(self, "iso_focus", None):
            self.hover_focus, self.iso_focus = name, iso
            self.update()

    def spot_scale(self):
        """How big the spotlit icons are right now (None = no spotlight)."""
        t = time.time()
        if getattr(self, "_spot_on", False):
            u = min(1.0, (t - self._spot_t) / self.SPOT_IN)
            e = 1 - (1 - u) ** 3                                      # plain ease out (no bounce: her call)
            return 1 + (self.SPOT_BIG - 1) * e
        if getattr(self, "_spot", None) and t - getattr(self, "_spot_t", 0) < self.SPOT_OUT:
            u = (t - self._spot_t) / self.SPOT_OUT
            return self._spot_from - (self._spot_from - 1) * (1 - (1 - u) ** 2)
        return None

    def _icon_under(self, lx, ly):
        """(name, x, y, spot index) of the map icon at window point lx, ly, or None."""
        if not (self.active and self.A is not None and getattr(self, "fop", 0) > 0.5 and self.rect):
            return None
        pts = self.points.get(self.world)
        if not pts:
            return None
        if any(px <= lx <= px + pw and py <= ly <= py + ph for px, py, pw, ph in getattr(self, "own_rects", [])):
            return None
        Ai = self.matcher.np.linalg.inv(self.A)
        gx0, gx1, gy0, gy1 = pts["bounds"]
        s = max(0.7, min(1.6, self.rect[2] / 1920))
        best, bd = None, 1e9
        sp, sc = getattr(self, "_spot", None), self.spot_scale()
        for name, e in self.shown(pts).items():
            rad = 15 * s * (sc if sc and name == sp else 1.0)
            for ci, (x, y, _n) in enumerate(e.get("c", [])):
                uu, vv = (x - gx0) / (gx1 - gx0), (y - gy0) / (gy1 - gy0)
                dx = Ai[0, 0] * uu + Ai[0, 1] * vv + Ai[0, 2] - lx
                dy = Ai[1, 0] * uu + Ai[1, 1] * vv + Ai[1, 2] - ly
                d = dx * dx + dy * dy
                if d < rad * rad and d < bd:
                    best, bd = (name, x, y, ci), d
        return best

    def _map_hover(self):
        """The icon under the mouse on the big map (its name), from where the icons are drawn now."""
        if self.cursor.down() or not self.rect:
            return None
        q = QCursor.pos()
        hit = self._icon_under(q.x() - self.rect[0], q.y() - self.rect[1])
        return hit[0] if hit else None

    def _spot_step(self):
        """Every frame (GUI thread): who's in the spotlight, and its little grow / shrink animation."""
        want = self._map_hover() or getattr(self, "hover_focus", None)
        cur = getattr(self, "_spot", None) if getattr(self, "_spot_on", False) else None
        if want != cur:
            if want:
                self._spot, self._spot_on, self._spot_t = want, True, time.time()
            elif cur:
                self._spot_from = self.spot_scale() or self.SPOT_BIG
                self._spot_on, self._spot_t = False, time.time()
        sc = self.spot_scale()
        was = getattr(self, "spot_hide", False)
        self.spot_hide = sc is not None                      # render thread: the hovered one's windows away
        if self.spot_hide != was or (sc is not None and abs(sc - self.SPOT_BIG) > 1e-3) or \
                (self.spot_hide and getattr(self, "_spot_drawn", None) != self._spot):
            self._spot_drawn = self._spot if self.spot_hide else None
            self.update()                                    # only while it grows / shrinks or changes

    # ---------------------------------------------- pets or gathering ---- #
    def layer_mode(self):
        """What the map shows: "pets", "gather" or "off" (the three-way switch)."""
        f = getattr(self, "layer_fn", None)
        return f() if f else ("pets" if self.enabled() else "off")

    def entries(self, pts, mode=None):
        """{name: {"p": points, "c": [[x, y, n]] best spots, ...}} for the layer shown (all of them)."""
        mode = mode or self.layer_mode()
        if mode != "gather":
            return pts.get("pets", {})
        cache = self.__dict__.setdefault("_gcache", {})
        key = id(pts)
        if key not in cache:
            try:
                from items import GATHER, CRAFT
                kinds = dict(GATHER)
            except Exception:
                kinds, CRAFT = {}, {}
            out = {}
            for name, P in pts.get("res", {}).items():
                if not P or name not in kinds:              # only materials on our list (Global ones)
                    continue
                c = best_nodes(P)
                out[name] = {"p": P, "c": c, "col": CRAFT.get(kinds.get(name), ("", "#D7DCE6"))[1], "res": True}
            cache[key] = out
        return cache[key]

    def shown(self, pts):
        """Entries drawn as icons: pets you still need, or every gathering resource."""
        mode = self.layer_mode()
        if mode == "off":
            return {}
        e = self.entries(pts, mode)
        pk = getattr(self, "picks", None)
        hid = pk.hidden("big", mode) if pk else ()          # her ticks for the big map (or the minimap's)
        if mode == "gather":
            cr = getattr(self, "craft_ok", None)              # the Gathering lists' use filter
            return {n: v for n, v in e.items() if n not in hid and (cr is None or cr(n))}
        want = self.want_pets()
        fam = getattr(self, "fam_ok", None)                 # the Pets lists' family filter
        return {n: v for n, v in e.items() if n in want and n not in hid and (fam is None or fam(n))}

    def entry(self, pts, name):
        return pts.get("pets", {}).get(name) or self.entries(pts, "gather").get(name) or {}

    @staticmethod
    def ring(e):
        return QColor(e.get("col") or GENUS_COL.get(e.get("g"), "#D7DCE6"))

    def icon(self, name, e=None):
        if e and e.get("res"):
            f = getattr(self, "res_icon", None)
            return f(name) if f else None
        return self.icon_for(name)

    SWITCH_PATH = "switch.json"

    def _game_icon(self, name):
        cache = self.__dict__.setdefault("_gicons", {})
        if name not in cache:
            from PySide6.QtGui import QPixmap
            pm = QPixmap(str(self.app_dir / "ui_icons" / f"{name}.png"))
            cache[name] = None if pm.isNull() else pm
        return cache[name]

    def switch_pos(self):
        """Where the pill sits, as a fraction of the map window (you can drag it anywhere)."""
        if not hasattr(self, "_sw_pos"):
            try:
                v = json.loads((self.app_dir / "maps" / self.SWITCH_PATH).read_text())
                self._sw_pos = (float(v[0]), float(v[1]))
            except (OSError, ValueError, IndexError, TypeError):
                self._sw_pos = (0.86, 0.105)
        return self._sw_pos

    def _side(self):
        """Which end the knob is at: the layer shown, or (when off) the one shown last."""
        mode = self.layer_mode()
        if mode in ("pets", "gather"):
            return mode
        f = getattr(self, "last_layer", None)
        v = f() if f else "pets"
        return v if v in ("pets", "gather") else "pets"

    def _paint_switch(self, p, s, W, Hh, font, text, rr):
        """Two-way switch beside the overlay's round button: pets (butterfly) on the left, gathering (basket)
        on the right. Tapping the lit side hides both: the knob goes dark where it is. Slides with a bounce."""
        if getattr(self, "hide_switch", False):           # the dock's butterfly / basket do this job
            self.switch_rect, self._sw_docked = None, False
            return
        mode = self.layer_mode()
        tgt = 0 if self._side() == "pets" else 1
        lit_to = 0.0 if mode == "off" else 1.0
        t = time.time()
        if getattr(self, "_sw_to", None) != tgt:                 # changed: slide from where it is now
            first = getattr(self, "_sw_to", None) is None
            self._sw_from = float(tgt) if first else getattr(self, "_sw_pos_now", float(tgt))
            self._sw_to, self._sw_t0 = tgt, t
        if getattr(self, "_sw_lit_to", None) != lit_to:          # on / off: fade the knob
            first = getattr(self, "_sw_lit_to", None) is None
            self._sw_lit_from = lit_to if first else getattr(self, "_sw_lit_now", lit_to)
            self._sw_lit_to, self._sw_lit_t0 = lit_to, t
        u = min(1.0, (t - self._sw_t0) / 0.38)
        e_ = 1 + 2.45 * (u - 1) ** 3 + 1.45 * (u - 1) ** 2          # ease-out with a little overshoot
        pos = self._sw_from + (tgt - self._sw_from) * e_
        self._sw_pos_now = pos
        v = min(1.0, (t - self._sw_lit_t0) / 0.22)
        lit = self._sw_lit_from + (lit_to - self._sw_lit_from) * (1 - (1 - v) ** 2)
        self._sw_lit_now = lit
        moving = u < 1.0 or v < 1.0
        on = self.enabled()
        kc = 1.0 if on else 0.0                               # for the old free-standing pill below
        p.save()
        p.setClipping(False)
        slot = self.dock_slot() if getattr(self, "dock_slot", None) else None
        if slot and self.rect:                                    # beside the overlay's round button
            gx, gy, d = slot[:3]
            sign = slot[3] if len(slot) > 3 else 1
            cx, cy = gx - self.rect[0], gy - self.rect[1]
            if 0 <= cx <= W and 0 <= cy <= Hh:
                h = slot[4] if len(slot) > 4 else d * 0.82          # as tall as the round button
                w = h * 2.0
                x0 = cx - d / 2 if sign > 0 else cx + d / 2 - w     # grows away from the round button
                r = QRectF(x0, cy - h / 2, w, h)
                self.switch_rect, self._sw_docked = r.adjusted(-3, -3, 3, 3), True
                paint_pill(p, r, pos, lit, rr)
                p.restore()
                if moving:
                    self.update(r.toAlignedRect().adjusted(-14, -14, 14, 14))
                return
        self._sw_docked = False
        k = kc
        f = font(10.5 * s, 600)
        w, h = 104 * s, 28 * s
        fx, fy = self.switch_pos()
        x = min(max(4 * s, fx * W - w / 2), W - w - 4 * s)
        y = min(max(4 * s, fy * Hh - h / 2), Hh - h - 4 * s)
        r = QRectF(x, y, w, h)
        self.switch_rect = r
        rr(p, r, h / 2, QColor(14, 17, 24, 215))
        from ui import draw_icon
        draw_icon(p, "pets", x + 10 * s, y + 6 * s, 16 * s, QColor(255, 255, 255, 235) if on else QColor("#7D8698"))
        text(p, x + 31 * s, y + 18.5 * s, "Pets", f, QColor(255, 255, 255, 235) if on else QColor("#A9B1C2"))
        tr = QRectF(x + w - 40 * s, y + 7 * s, 30 * s, 14 * s)           # the little track + knob
        on_c, off_c = QColor(230, 233, 240), QColor("#262C3A")
        rr(p, tr, 7 * s, QColor(int(off_c.red() + (on_c.red() - off_c.red()) * k),
                                int(off_c.green() + (on_c.green() - off_c.green()) * k),
                                int(off_c.blue() + (on_c.blue() - off_c.blue()) * k)))
        p.setBrush(QColor(14, 17, 24) if k > 0.5 else QColor("#A9B1C2"))
        p.drawEllipse(QPointF(tr.x() + 7 * s + k * 16 * s, tr.center().y()), 5 * s, 5 * s)
        p.restore()
        if abs(k - (1.0 if on else 0.0)) > 0.01:
            self.ver += 1                                          # keep animating the knob

    @staticmethod
    def _pet_icon(p, r, pix, ring, s):
        p.setPen(QPen(QColor(0, 0, 0, 150), 4 * s))
        p.setBrush(QColor(14, 17, 24, 235))
        p.drawEllipse(r)
        if pix is not None and not pix.isNull():
            clip = QPainterPath()
            clip.addEllipse(r.adjusted(1.5 * s, 1.5 * s, -1.5 * s, -1.5 * s))
            p.save()
            p.setClipPath(clip, Qt.IntersectClip)
            p.drawPixmap(r, pix, QRectF(pix.rect()))
            p.restore()
        p.setPen(QPen(ring, 2 * s))
        p.setBrush(Qt.NoBrush)
        p.drawEllipse(r)

    def toggle_pin(self, world, name, x, y):
        self.pin = None if self.pin and self.pin[1:] == (name, x, y) else (world, name, x, y)
        try:
            (self.app_dir / "maps" / "pin.json").write_text(json.dumps(list(self.pin) if self.pin else []))
        except OSError:
            pass

    def _paint_card(self, p, s, to, pts, W, Hh, font, text, rr, draw_icon):
        """Details for the clicked pet(s), pinned next to them on the map."""
        cd = self.card
        ax, ay = to(*cd["at"])
        rows = cd["pets"]
        cw, rh, pad = 262 * s, 50 * s, 10 * s
        ch = pad * 2 + rh * len(rows) - 4 * s          # no close button: a click anywhere else closes it
        x = ax + 22 * s if ax + 22 * s + cw < W - 8 * s else ax - 22 * s - cw
        y = min(max(Hh * 0.08, ay - 24 * s), Hh - ch - 8 * s)
        rect = QRectF(x, y, cw, ch)
        cd["rect"] = rect
        p.save()
        p.setClipping(False)
        age = min(1.0, (time.time() - cd["t"]) / 0.14)
        p.setOpacity(self.op * age)
        p.translate(0, (1 - age) * 6 * s)
        rr(p, rect, 10 * s, QColor(14, 17, 24, 238))
        for i, (name, (cx, cy), ci) in enumerate(rows):
            ry = y + pad - 2 * s + i * rh
            e = self.entry(pts, name)
            ring = self.ring(e)
            self._pet_icon(p, QRectF(x + pad, ry + 4 * s, 34 * s, 34 * s), self.icon(name, e), ring, s)
            tx = x + pad + 44 * s
            if e.get("res"):
                f = getattr(self, "res_info", None)
                info = (f(name) if f else None) or {}
            else:
                info = self.info_for(name) or {}
            text(p, tx, ry + 15 * s, name, font(12 * s, 700), QColor(255, 255, 255, 240), w=cw - (tx - x) - pad - 28 * s)
            pinned = bool(self.pin) and self.pin[1:] == (name, cx, cy)
            pr_ = QRectF(x + cw - pad - 22 * s, ry + 2 * s, 22 * s, 18 * s)
            rr(p, pr_, 5 * s, QColor(255, 255, 255, 235) if pinned else QColor("#262C3A"))
            draw_pin(p, pr_.center().x(), pr_.center().y(), 5.5 * s, QColor("#0E1118") if pinned else QColor("#D7DCE6"))
            self.card_hits.append((pr_, lambda n=name, a=cx, b=cy: self.toggle_pin(self.world, n, a, b)))
            if e.get("res"):
                prog, k = info.get("have", ""), info.get("k", 0)
            elif info.get("maxed"):
                prog, k = "Collection complete", 1.0
            elif info.get("need"):
                prog, k = f"Lv {info['level']}  ·  {info['cur']}/{info['need']} souls", info["cur"] / info["need"]
            else:
                prog, k = "", 0
            fam = info.get("family", "")
            text(p, tx, ry + 29 * s, " · ".join(v for v in (fam, prog) if v), font(9.5 * s), QColor("#D7DCE6"),
                 w=cw - (tx - x) - pad)
            bw = cw - (tx - x) - pad
            rr(p, QRectF(tx, ry + 33 * s, bw, 2.5 * s), 1.2 * s, QColor("#262C3A"))
            rr(p, QRectF(tx, ry + 33 * s, bw * max(0.0, min(1.0, k)), 2.5 * s), 1.2 * s, ring)
            cl = e.get("c", [])
            n = cl[ci][2] if ci < len(cl) else 0
            bits = [f"{n} {'nodes' if e.get('res') else 'spawns'} here"] if n else []     # just the count
            text(p, tx, ry + 46 * s, "   ".join(bits), font(9 * s), QColor("#A9B1C2"), w=cw - (tx - x) - pad)
        p.restore()


# ------------------------------------------------------------------------------------------ minimap ---- #
class MiniView(QWidget):
    """The same pet spawns on the minimap while you play. The minimap is north-up with a fixed zoom, so
    sliding it over the region map (template matching) finds where you are: once from scratch (~50 ms),
    then in a small window around the last spot (~2 ms) as you move."""
    K0 = 6783 / 816000              # minimap px per game unit at a 1920-wide screen (measured on your screen)
    MATCH_H = 145                   # rows used for matching (the clock bar below is left out)

    def __init__(self, big, log):
        super().__init__()
        self.big, self.log = big, log
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool |
                            Qt.WindowDoesNotAcceptFocus | Qt.WindowTransparentForInput)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.active, self.rect, self.world = False, None, None
        self.pos, self.W, self.score = None, None, 0.0        # top-left of the minimap in the W-size map
        self.maps, self.lost, self.next_try = {}, 0, 0.0
        self.ver, self.painted, self.seen_t, self.op = 0, -1, 0.0, 0.0
        self.thread = None
        self.state = "off"
        self.k = self.K0
        self.lock_score = 0.0
        self.ghosts = []
        self.timer = QTimer(self)
        self.timer.setTimerType(Qt.PreciseTimer)
        self.timer.setInterval(16)
        self.timer.timeout.connect(self._frame)

    def showEvent(self, e):
        super().showEvent(e)
        _exclude_capture(self)

    def _load_k(self):
        try:
            return float(json.loads((self.big.app_dir / "maps" / "minimap.json").read_text())["k"])
        except (OSError, ValueError, KeyError):
            return self.K0

    def _save_k(self):
        try:
            (self.big.app_dir / "maps" / "minimap.json").write_text(json.dumps({"k": self.k}))
        except OSError:
            pass

    def status(self):
        d = self.big.data
        info = f"  live pets {len(getattr(d, 'live', {}))}  needed pets {len(self.big.want_pets())}  " \
               f"drawn {getattr(self, 'drawn', 0)}  you {'known' if getattr(self.big.data, 'self_eid', None) else 'not seen yet'}"
        info += f"  shown {self.visible_now()}  blocked {getattr(self, 'blocked', 0)}  cover score " \
                f"{getattr(self, 'last_cover', '-')}"
        info += f"  gatherer {getattr(d, 'gather_eid', None)} / you {getattr(d, 'self_eid', None)}"
        fm = d.farmed() if hasattr(d, "farmed") else set()
        info += f"  nodes {len(getattr(d, 'nodes', {}))} (gone: {getattr(d, 'node_why', {})})  farming {sorted(fm)}" \
                f"  edge {len(getattr(self, 'node_edge', ()))} known {len(getattr(self, 'node_known', ()))}"
        nc = getattr(d, "node_check", None)
        if nc and sum(nc):
            info += f"  node counts on sight: {nc[0]} right / {nc[1]} wrong"
        return self.state + info + (f"  score {self.score:.2f}" if self.state == "showing" else
                             f"  world {self.world}  last try {getattr(self, 'last_try', None)}")

    ZONE_DOUBT = 8.0     # s of the minimap never matching the zone you're said to be in: try the other maps

    def _check_zone(self, b, w):
        """The zone the app was told (or kept from before a restart) can be wrong. When the minimap hasn't matched
        it for ZONE_DOUBT s, try every field map in turn (yours too); the first one the minimap picture really
        matches becomes the zone. Returns the map to try now."""
        t = time.time()
        if self.pos is not None:
            if getattr(self, "_doubt", False) and self.world and self.world != w:
                b.data.world = w = self.world     # the minimap picture says you're here (a wrong one fails again
                                                  # and gets re-checked, so this can't stick on a wrong map)
                self.big.log(f"minimap: zone corrected to {w}")
            self._fail_t, self._doubt = None, False
            return w
        if getattr(self, "_fail_t", None) is None:
            self._fail_t = t
        if t - self._fail_t > self.ZONE_DOUBT:
            self._doubt = True
        if not getattr(self, "_doubt", False):
            return w
        cands = [c for c in b.points if b.points[c].get("pets") and b.matcher._src(c) is not None
                 and (c not in MapView.KR_ONLY or c == w)]
        if w in b.points and w not in cands:
            cands.insert(0, w)
        if not cands:
            return w
        if t >= getattr(self, "_next_zone", 0):
            self._zguess = (getattr(self, "_zguess", -1) + 1) % len(cands)
            self._next_zone, self._rot_t = t + 2.5, t     # a slow PC needs ~2 s for a map's first match
            self.pos = None
        return cands[self._zguess % len(cands)]

    def tick(self, playing, rect):
        b = self.big
        self._tick_switch(playing, rect)
        on = bool(playing and rect and rect[2] > 400) and b.setup()     # tracked even when switched off
        w = b.data.world
        if w is None and on:                     # not known yet (just restarted): from what's around you
            w = self._infer_world()
            if w is not None:
                b.data.world = w
        if w is None and on:                     # region not known yet (just restarted): try each in turn
            cands = [c for c in b.points if b.points[c].get("pets") and b.matcher._src(c) is not None]
            if self.pos is not None and self.world in cands and getattr(self, "blocked", 0) < 6:
                w = self.world                   # this guess matches the picture: keep it
            elif self.pos is not None and self.world in cands:
                self.pos, self.blocked = None, 0  # placed from your position, but the picture says no: next
                self._next_guess = 0
                w = None
            if w is None and cands:
                if time.time() >= getattr(self, "_next_guess", 0):
                    self._guess = (getattr(self, "_guess", -1) + 1) % len(cands)
                    self._next_guess = time.time() + 1.2
                w = cands[getattr(self, "_guess", 0) % len(cands)]
        if w is not None and on:                 # the map you're on, but the minimap never matches it: the zone
            w = self._check_zone(b, str(w))      # the app was told is wrong (his PC: "20" while farming a field)
        on = on and w is not None and str(w) in b.points and b.matcher._src(str(w)) is not None
        if on:
            x0, y0, ww, hh = rect
            s = min(ww / 1920, hh / 1080)
            self.rect = (int(x0 + ww - 268 * s), int(y0 + 100 * s), int(244 * s), int(162 * s))
            self.s, self.world = s, str(w)
            if not self.active:
                self.active = True
                if self.thread is None or not self.thread.is_alive():
                    self.thread = threading.Thread(target=self._run, daemon=True, name="minimap")
                    self.thread.start()
            if not self.timer.isActive():
                self.timer.start()
        elif self.active:
            self.active = False
            self.state = "idle"

    def _map(self, W, world=None):
        """Region map, grey, at minimap scale (+ a quarter-size copy for the first search)."""
        world = world or self.world
        key = (world, W)
        if key not in self.maps:
            cv2 = self.big.matcher.cv2
            if getattr(self, "src", (None,))[0] != world:
                self.src = (world, cv2.imread(str(self.big.matcher._src(world)), cv2.IMREAD_GRAYSCALE))
            m = cv2.resize(self.src[1], (W, W), interpolation=cv2.INTER_AREA)
            if len(self.maps) > 4:
                self.maps = {}
            self.maps[key] = (m, cv2.resize(m, (W // 4, W // 4), interpolation=cv2.INTER_AREA))
        return self.maps[key]

    def _run(self):
        b = self.big
        cv2, np = b.matcher.cv2, b.matcher.np
        while True:
            if not self.active:
                time.sleep(0.1)
                continue
            t0 = time.time()
            try:
                rect, world = self.rect, self.world
                # plain GDI for this small area: unlike the DXGI copy it leaves out our own windows, so the
                # icons we draw over the minimap can't spoil the match (or make it look covered)
                if getattr(self, "_gdi", None) is None:
                    self._gdi = _Gdi()
                img = self._gdi.grab(rect, np, cv2)
                if img is None or int(img[::8, ::8].max()) < 8:
                    img = b.cap.grab(rect, np, cv2)
                if img is not None and img.size:
                    img = img[:int(self.MATCH_H * self.s)]
                    if self.state == "looking":
                        _diag_save(b.app_dir, "minimap_frame.png", img, cv2,
                                   f"{b.cap.kind} {img.shape} mean {float(img.mean()):.1f} world {world} "
                                   f"rect {rect} s {self.s} last try {getattr(self, 'last_try', None)}")
                    pts = b.points[world]
                    W = int(self.k * abs(pts["bounds"][1] - pts["bounds"][0]) * self.s)
                    if self._from_position(world, W):
                        # still on screen? (a window over the minimap). The game position is only close to
                        # the picture's place, so look as widely as the normal tracking does; a covered
                        # minimap scores near 0, a visible one 0.2+ (her laptop, Nov 2026)
                        # Checked where the picture itself last matched (the game's position can sit a
                        # little off the picture), searched more widely when that's old or far
                        m, _ = self._map(W, world)
                        pp, pt = getattr(self, "pic_pos", None), getattr(self, "pic_t", 0)
                        near = pp is not None and time.time() - pt < 2 and \
                            math.hypot(pp[0] - self.pos[0], pp[1] - self.pos[1]) < 60 * self.s
                        bx, by = pp if near else self.pos
                        sc, p_ = self._score(m, img, bx, by, int((20 if near else 45) * self.s))
                        self.last_cover = round(sc, 3)
                        if sc > self.cover_cut():
                            self.blocked = 0
                            self.pic_pos, self.pic_t = p_, time.time()
                            self.lock_score = 0.95 * self.lock_score + 0.05 * sc if self.lock_score else sc
                        else:
                            self.blocked = getattr(self, "blocked", 0) + 1
                    elif self.pos is not None and self.W == W and world == getattr(self, "_pos_world", None):
                        self._local(img, W, world)
                        self._learn_self(world, W)
                    elif time.time() >= self.next_try or world != getattr(self, "_tried", None):
                        self._tried = world
                        self._global(img, world, W)
                        self._learn_self(world, W)
            except Exception as e:
                self.log(f"minimap overlay: {e}")
                time.sleep(1.0)
            time.sleep(max(0.0, 0.04 - (time.time() - t0)))

    def _grad(self, a):
        """Edges only: the view cone and glow over the minimap barely change them, so matching holds."""
        cv2 = self.big.matcher.cv2
        a = cv2.GaussianBlur(a, (3, 3), 0).astype("float32")
        return cv2.magnitude(cv2.Sobel(a, cv2.CV_32F, 1, 0), cv2.Sobel(a, cv2.CV_32F, 0, 1))

    def _score(self, m, img, x, y, pad, gimg=None):
        cv2 = self.big.matcher.cv2
        h, w = img.shape
        x0, y0 = max(0, int(x - pad)), max(0, int(y - pad))
        sub = m[y0:y0 + h + 2 * pad, x0:x0 + w + 2 * pad]
        if sub.shape[0] < h or sub.shape[1] < w:
            return -1, None
        r = cv2.matchTemplate(self._grad(sub), gimg if gimg is not None else self._grad(img), cv2.TM_CCOEFF_NORMED)
        _, mx, _, loc = cv2.minMaxLoc(r)
        r2 = r.copy()
        cv2.circle(r2, loc, max(4, int(8 * self.s)), -1.0, -1)
        self.sharp = mx - cv2.minMaxLoc(r2)[1] if r2.size > 1 else 0.0   # how clearly this spot wins
        return mx, (x0 + loc[0], y0 + loc[1])

    def _local(self, img, W, world=None):
        m, _ = self._map(W, world)
        anc, age = self._anchor(world or self.world, W)
        if anc is not None and age < 2 and math.hypot(self.pos[0] - anc[0], self.pos[1] - anc[1]) > 110 * self.s:
            self.pos, self.state = None, "looking"           # locked onto the wrong spot: the game says otherwise
            return
        sc, p = self._score(m, img, self.pos[0], self.pos[1], int(24 * self.s))
        if sc > 0.16 and p and sc > 0.55 * self.lock_score and self.sharp > 0.02:
            self.lock_score = 0.9 * self.lock_score + 0.1 * sc
            self.lost = 0
            if p != self.pos:
                self.pos = p
                self.ver += 1
            self.score, self.seen_t, self.state = sc, time.time(), "showing"
            self.blocked = 0
            self.pic_pos, self.pic_t = p, time.time()
        else:
            if sc < self.cover_cut():                    # nothing like the map there: covered by a window.
                self.blocked = getattr(self, "blocked", 0) + 1   # Not lost: keep the spot, so it's back the
            else:                                        # moment the window closes (no search from scratch)
                self.lost += 1
            self.last_cover = round(sc, 3)
            if self.lost > 25:                           # ~1 s of not finding it: look from scratch
                self.pos, self.state = None, "looking"

    def _global(self, img, world, W):
        """Find you from scratch: edges of the minimap against edges of the half-size region map. Edges work
        even on snow and grass that look alike everywhere; ~0.3 s, only when not already tracking."""
        cv2 = self.big.matcher.cv2
        m, _ = self._map(W, world)
        key = (world, W)
        anc, age = self._anchor(world, W)
        if anc is not None:                    # the game said where you are: look only around there
            pad = int((30 + 12 * age) * self.s)
            sc, p = self._score(m, img, anc[0], anc[1], pad)
            if p and sc > 0.2 and self.sharp > 0.03:
                self._take(p, W, world, sc)
                return
        if getattr(self, "_ghalf", (None,))[0] != key:
            half = cv2.resize(m, (W // 2, W // 2), interpolation=cv2.INTER_AREA)
            self._ghalf = (key, self._grad(half))
        h, w = img.shape
        th = self._grad(cv2.resize(img, (w // 2, h // 2), interpolation=cv2.INTER_AREA))
        r = cv2.matchTemplate(self._ghalf[1], th, cv2.TM_CCOEFF_NORMED)
        _, mx, _, loc = cv2.minMaxLoc(r)
        r2 = r.copy()
        cv2.circle(r2, loc, 6, -1.0, -1)
        gap = mx - cv2.minMaxLoc(r2)[1]
        sc, p = self._score(m, img, loc[0] * 2, loc[1] * 2, int(6 * self.s))
        self.last_try = (round(mx, 3), round(gap, 3), round(sc, 3))
        far = anc is not None and p is not None and math.hypot(p[0] - anc[0], p[1] - anc[1]) > (60 + 15 * age) * self.s
        if mx > 0.3 and gap > 0.08 and sc > 0.2 and not far:   # one clear winner, and where the game says
            self._take(p, W, world, sc)
        elif anc is not None and age < 3:      # can't see it clearly, but the game just said where you are
            self._take(anc, W, world, 0.2)
            self.lock_score = 0.2
        else:
            self.state = "looking"
            self.next_try = time.time() + 1.0

    def _take(self, p, W, world, sc):
        self.lock_score = sc
        self.pos, self.W, self.lost, self.score = p, W, 0, sc
        self._pos_world = world
        self.seen_t, self.state, self.blocked = time.time(), "showing", 0
        self.ver += 1

    CX, CY = 122, 81                    # where you are on the minimap (px at a 1920-wide screen)

    def _me(self, world, W):
        """Your position (game units) from the minimap match."""
        pts = self.big.points[world]
        gx0, gx1, gy0, gy1 = pts["bounds"]
        return (gx0 + (self.pos[0] + self.CX * self.s) / W * (gx1 - gx0),
                gy0 + (self.pos[1] + self.CY * self.s) / W * (gy1 - gy0))

    def _learn_self(self, world, W):
        """You are known from the game data (your character's entity), nothing to learn here."""

    def _anchor(self, world, W):
        """Where the game data last said you stand, as a minimap position, and how old that is (s)."""
        sp = getattr(self.big.data, "self_pos", None)
        dw = getattr(self.big.data, "world", None)        # unknown after a restart until you teleport
        if not sp or (dw is not None and str(dw) != str(world)):
            return None, None
        age = time.time() - sp[2]
        if age > 20:
            return None, None
        gx0, gx1, gy0, gy1 = self.big.points[world]["bounds"]
        u, v = (sp[0] - gx0) / (gx1 - gx0), (sp[1] - gy0) / (gy1 - gy0)
        if not (0 <= u <= 1 and 0 <= v <= 1):
            return None, None
        return (u * W - self.CX * self.s, v * W - self.CY * self.s), age

    def _from_position(self, world, W):
        """Place the minimap from your live position in the game data, when the game sends it."""
        e = getattr(self.big.data, "self_eid", None)
        m = getattr(self.big.data, "moves", {}).get(e) if e else None
        if not m or time.time() - m[2] > 0.4:
            return False
        pts = self.big.points[world]
        gx0, gx1, gy0, gy1 = pts["bounds"]
        u, v = (m[0] - gx0) / (gx1 - gx0), (m[1] - gy0) / (gy1 - gy0)
        if not (0 <= u <= 1 and 0 <= v <= 1):
            return False
        p = (u * W - self.CX * self.s, v * W - self.CY * self.s)
        if p != self.pos:
            self.pos = p
            self.ver += 1
        self.W, self._pos_world, self.lost = W, world, 0
        self.seen_t, self.state, self.score = time.time(), "showing", 1.0
        return True

    def _infer_world(self):
        """Which map you're on, from the gathering nodes the game says are around you: every map's node
        spots are its own, so 2+ nodes standing exactly on one map's spots settle it (no guessing)."""
        b = self.big
        nodes = list(getattr(b.data, "nodes", {}).values())
        if len(nodes) < 2:
            return None
        grids = self.__dict__.setdefault("_wgrid", {})
        best, bn = None, 0
        for w, v in b.points.items():
            g = grids.get(w)
            if g is None:
                g = grids[w] = {(int(x // 8), int(y // 8)) for P in v.get("res", {}).values() for x, y in P}
            n = sum(1 for _t, x, y, _ in nodes
                    if any((int(x // 8) + dx, int(y // 8) + dy) in g for dx in (-1, 0, 1) for dy in (-1, 0, 1)))
            if n > bn:
                best, bn = w, n
        return best if bn >= 2 else None

    def _tick_switch(self, playing, rect):
        """Where the picker's round button sits (left of the minimap, under the game's star and filter),
        or None while the minimap isn't on screen (covered by a window, big map open...)."""
        f = getattr(self, "picker_fn", None)
        if f is None:
            return
        if playing and rect and rect[2] > 400 and self.visible_now():
            x0, y0, ww, hh = rect
            s = min(ww / 1920, hh / 1080)
            mx, my = x0 + ww - 268 * s, y0 + 100 * s        # the minimap's top-left
            f((mx - 15 * s, my + 131 * s, s))               # the round button's centre (right edge kept)
        else:
            f(None)

    def cover_cut(self):
        """Below this the minimap counts as covered: under half of how well it usually matches."""
        return min(0.15, max(0.07, 0.45 * (self.lock_score or 0.0)))

    def visible_now(self):
        """The game's minimap is on screen and not covered (inventory, any window): tracked this moment."""
        return bool(self.active and self.pos is not None and time.time() - self.seen_t < 0.25 and
                    getattr(self, "blocked", 0) < 2)

    def layer(self):
        """The minimap's own switch: "pets", "gather" or "off" (separate from the big map's)."""
        f = getattr(self, "layer_fn", None)
        return f() if f else self.big.layer_mode()

    NODE_USES = 3           # gathers a field node has (shared by everyone); Abyss nodes count 0 = no limit
    KNOWN_EDGE = 8          # farming: known spots of the material shown on the minimap's edge (nearest)
    ABYSS = {"20", "22", "23"}

    def nodes_near(self, pts, to, w, h):
        """Gathering nodes that are really there right now (the game's own messages, shown the moment they
        arrive), inside the minimap, as (name, x, y). A node standing on a known spot of the map data
        teaches the app its material, so every node gets its picture without any setup."""
        d = self.big.data
        nodes, kinds = getattr(d, "nodes", None), getattr(d, "node_kinds", {})
        if not nodes:
            return []
        s = self.s
        cx0, cy0 = self.CX * s, self.CY * s
        ent = self.big.entries(pts, "gather")
        pk = getattr(self, "picks", None)
        hidden = pk.hidden("mini", "gather") if pk else set()   # materials she unticked
        tried = self.__dict__.setdefault("_kind_tried", set())
        out, left, edge = [], {}, set()
        self.node_busy = None
        farmed = d.farmed() if hasattr(d, "farmed") else set()
        for _k, (tid, x, y, _t) in list(nodes.items()):
            name = kinds.get(tid)
            if name is None and tid not in tried:           # unknown node id: is it on a known spot?
                tried.add(tid)
                # only when exactly one material has a spot right there (spots of different materials can
                # sit close together, and a wrong guess would stick)
                close = {nm for nm, e in ent.items() if any(abs(px - x) < 3 and abs(py - y) < 3 for px, py in e["p"])}
                around = {nm for nm, e in ent.items() if any(abs(px - x) < 30 and abs(py - y) < 30 for px, py in e["p"])}
                if len(close) == 1 and around == close:
                    name = next(iter(close))
                    if hasattr(d, "learn_node_kind"):
                        d.learn_node_kind(tid, name)
            if name not in ent or name in hidden:            # not on our list / not known yet / switched off
                continue
            cr = getattr(self, "craft_ok", None)
            if cr is not None and not cr(name):              # its use is switched off in the Gathering lists
                continue
            X, Y = to(x, y)
            inside = 0 <= X <= w and 0 <= Y <= h
            if not inside and name in farmed:                # farming it: far live nodes stick to the edge
                edge.add((name, x, y))
            if inside or name in farmed:
                out.append((math.hypot(X - cx0, Y - cy0), name, x, y))
                used = getattr(d, "node_uses", {}).get(_k)
                if used is not None and str(self.world) not in self.ABYSS:   # field node: gathers left
                    left[(name, x, y)] = self.NODE_USES - used
                if _k == getattr(d, "using_eid", None) and time.time() - getattr(d, "using_t", 0) < 8:
                    self.node_busy = (name, x, y)            # the one you're gathering: pops out
        out.sort()
        out = out[:60]
        # Farming: the game only sends live nodes within ~150-240 m, so also the map data's known spots of
        # that material (where it spawns, maybe gathered already) on the edge, faded: the nearest few only.
        known = set()
        mx = 5 * w
        livexy = [(x, y) for _d, _n, x, y in out]
        for name in farmed:
            if name in hidden or (getattr(self, "craft_ok", None) and not self.craft_ok(name)):
                continue
            far = []
            for x, y in pts.get("res", {}).get(name, []):
                X, Y = to(x, y)
                if 0 <= X <= w and 0 <= Y <= h:
                    continue                                 # inside the minimap: live nodes only there
                dd = math.hypot(X - cx0, Y - cy0)
                if dd < mx and not any(abs(x - a) < 300 and abs(y - b) < 300 for a, b in livexy):
                    far.append((dd, name, x, y))
            far.sort()
            for f in far[:self.KNOWN_EDGE]:
                known.add(f[1:])
                out.append(f)
        self.node_left, self.node_edge, self.node_known = left, edge | known, known
        return [(n, x, y) for _d, n, x, y in out]

    def live_now(self, pts, want):
        """Pets in view right now: drop ones you killed, walked far from, or saw long ago."""
        d = self.big.data
        live = getattr(d, "live", None)
        if live is None or self.pos is None or not self.W:
            return []
        gx0, gx1, gy0, gy1 = pts["bounds"]
        s = self.s
        me_x = gx0 + (self.pos[0] + self.CX * s) / self.W * (gx1 - gx0)
        me_y = gy0 + (self.pos[1] + self.CY * s) / self.W * (gy1 - gy0)
        now = time.time()
        for nm, t in list(getattr(d, "kills", [])):
            d.kills.remove((nm, t))
            cand = [(math.hypot(v[1] - me_x, v[2] - me_y), k) for k, v in list(live.items()) if v[0] == nm]
            if cand:
                k = min(cand)[1]                               # the one you just killed: fade it out now
                v = live.pop(k, None)
                if v:
                    self.ghosts.append((v[0], v[1], v[2], now))
        for k, (nm, x, y, t) in list(live.items()):
            # no time limit any more: a pet standing still while you're AFK / alt-tabbed sends nothing and
            # vanished after 5 min. It goes when the game says it died or left view, or when you're far
            if math.hypot(x - me_x, y - me_y) > 32000:
                live.pop(k, None)
        self.ghosts = [g for g in self.ghosts if now - g[3] < 0.25]
        return [(nm, x, y) for nm, x, y, t in list(live.values()) if want is None or nm in want]

    PIN_NEAR = 2500         # game units (about 25 m): walking this close to the pin unpins it

    def _pin_check(self):
        """Pinned pet / spot: once you walk up to it, the pin goes by itself (after you've been away from it
        first, so pinning one right next to you doesn't vanish at once)."""
        pin = self.big.pin
        if not pin or str(pin[0]) != str(self.world) or not self.visible_now() or not self.W or \
                self.world not in self.big.points:
            return
        me = self._me(self.world, self.W)
        d = math.hypot(me[0] - pin[2], me[1] - pin[3])
        if getattr(self, "_pin_armed", None) != pin:
            if d > 2 * self.PIN_NEAR:
                self._pin_armed = pin
            return
        if d < self.PIN_NEAR:
            self.big.toggle_pin(*pin)                    # same pin = unpin (saved)
            self._pin_armed = None
            self.ver += 1

    def _frame(self):
        if self.visible_now() and self.W and self.world in self.big.points:
            me = self._me(self.world, self.W)
            self.last_me = (self.world, me[0], me[1], time.time())   # the big map opens centred on this
        self._pin_check()
        pinned = bool(self.big.pin) and str(self.big.pin[0]) == str(self.world)
        pk = getattr(self, "picks", None)
        live = self.visible_now() and ((pk.any_shown("mini") if pk else True) or pinned)   # a pin always shows
        self.op = 1.0 if live else 0.0                           # there at once, gone the moment it's covered
        if self.op > 0:
            if self.rect and self.geometry().getRect() != self.rect:
                self.setGeometry(*self.rect)
            if not self.isVisible():
                self.show()
                from ui import no_activate
                no_activate(self)
            if self.ver != self.painted or self.op < 1 or (self.big.pin and self.big.pin[0] == self.world) or \
                    getattr(self.big.data, "live", None) or getattr(self.big.data, "nodes", None):
                self.update()
        else:
            if self.isVisible():
                self.hide()
            if not self.active:
                self.timer.stop()

    @staticmethod
    def _to_edge(X, Y, cx, cy, w, h, m):
        """Where the line from you (cx, cy) to (X, Y) meets the minimap's edge (m in from it)."""
        dx, dy = X - cx, Y - cy
        k = 1.0
        if dx > 0:
            k = min(k, (w - m - cx) / dx)
        elif dx < 0:
            k = min(k, (m - cx) / dx)
        if dy > 0:
            k = min(k, (h - m - cy) / dy)
        elif dy < 0:
            k = min(k, (m - cy) / dy)
        return cx + dx * k, cy + dy * k

    def _uses_mark(self, p, r, left, col, s):
        """Gathers left on a node: its ring in 3 parts with wide gaps, lit = left (no number: too small)."""
        p.setBrush(Qt.NoBrush)
        for i in range(self.NODE_USES):
            a0 = 90 - i * 120 - 17                       # 86° parts, 34° gaps
            p.setPen(QPen(QColor(0, 0, 0, 200), 3.2 * s, Qt.SolidLine, Qt.FlatCap))
            p.drawArc(r, int(a0 * 16), int(-86 * 16))
            p.setPen(QPen(col if i < left else QColor(255, 255, 255, 45), 1.8 * s, Qt.SolidLine, Qt.FlatCap))
            p.drawArc(r, int(a0 * 16), int(-86 * 16))
        p.setPen(Qt.NoPen)

    def paintEvent(self, _):
        b, pos, W = self.big, self.pos, self.W
        if pos is None or not W or self.world not in b.points:
            return
        self.painted = self.ver
        pts = b.points[self.world]
        gx0, gx1, gy0, gy1 = pts["bounds"]
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setOpacity(self.op)
        s = self.s
        w, h = self.width(), self.height()
        p.setClipRect(QRectF(2 * s, 2 * s, w - 4 * s, h - 4 * s))

        def to(x, y):
            return (x - gx0) / (gx1 - gx0) * W - pos[0], (y - gy0) / (gy1 - gy0) * W - pos[1]
        want = b.want_pets()
        cx0, cy0 = self.CX * s, self.CY * s                             # you: the minimap's centre
        pk = getattr(self, "picks", None)            # her ticks: pets and materials can show together
        fam = getattr(self, "fam_ok", None)
        pets = [q for q in self.live_now(pts, None) if (not pk or pk.shown("mini", "pets", q[0])) and
                (fam is None or fam(q[0]))]
        live = pets + self.nodes_near(pts, to, w, h)
        self.drawn = len(live)
        sz = 17 * s
        now = time.time()
        placed = []
        for name, x, y, fade in [(n, x, y, 1.0) for n, x, y in live] + \
                [(g[0], g[1], g[2], 1 - (now - g[3]) / 0.25) for g in self.ghosts]:
            X, Y = to(x, y)
            e = b.entry(pts, name)
            m = 9 * s
            busy = (name, x, y) == getattr(self, "node_busy", None)
            if fade >= 1.0 and (name, x, y) in getattr(self, "node_edge", ()):
                X, Y = self._to_edge(X, Y, cx0, cy0, w, h, m)   # far, but you're farming it: on the edge
                if any(abs(X - a) < 12 * s and abs(Y - b) < 12 * s for a, b in placed):
                    continue                             # one per spot on the edge, no pile-ups
                placed.append((X, Y))
                kn = (name, x, y) in getattr(self, "node_known", ())
                p.setOpacity(self.op * (0.45 if kn else 0.9))   # known spot (maybe gathered): faded
                r = sz * 0.9
            elif m <= X <= w - m and m <= Y <= h - 4 * s - m:
                d = math.hypot(X - cx0, Y - cy0)
                near = 0.4 + 0.6 * min(1.0, max(0.0, (d - 8 * s) / (30 * s)))   # faded on top of you
                p.setOpacity(self.op * fade * (1.0 if busy else near))
                r = sz * (1.2 if busy else 1.0)          # the one you're gathering: full and a bit bigger
            else:                                    # only what's actually there, inside the minimap
                continue
            ir = QRectF(X - r / 2, Y - r / 2, r, r)
            if busy:                                     # a soft white halo so it stands out on top of you
                p.setPen(QPen(QColor(255, 255, 255, 140), 1.6 * s))
                p.setBrush(Qt.NoBrush)
                p.drawEllipse(ir.adjusted(-1.8 * s, -1.8 * s, 1.8 * s, 1.8 * s))
            MapView._pet_icon(p, ir, b.icon(name, e), b.ring(e), s * 0.5)
            n_left = getattr(self, "node_left", {}).get((name, x, y)) if fade >= 1.0 else None
            if n_left is not None and 0 < n_left <= self.NODE_USES:
                self._uses_mark(p, ir, n_left, b.ring(e), s)
        p.setOpacity(self.op)
        pin = b.pin
        if pin and pin[0] == self.world:
            X, Y = to(pin[2], pin[3])
            cx, cy = cx0, cy0
            m = 25 * s                                        # room for the arrow inside the minimap
            inside = 12 * s <= X <= w - 12 * s and 12 * s <= Y <= h - 26 * s
            white = QColor(255, 255, 255)
            p.setClipping(False)
            if not inside:                                    # stick to the edge, pointing the way
                dx, dy = X - cx, Y - cy
                k = min((w / 2 - m) / max(1e-6, abs(dx)), (h / 2 - m) / max(1e-6, abs(dy)))
                X, Y = cx + dx * k, cy + dy * k
                ang = math.atan2(dy, dx)
                tip = QPointF(X + math.cos(ang) * 15 * s, Y + math.sin(ang) * 15 * s)
                l = QPointF(X + math.cos(ang + 2.6) * 6 * s + math.cos(ang) * 8 * s,
                            Y + math.sin(ang + 2.6) * 6 * s + math.sin(ang) * 8 * s)
                r_ = QPointF(X + math.cos(ang - 2.6) * 6 * s + math.cos(ang) * 8 * s,
                             Y + math.sin(ang - 2.6) * 6 * s + math.sin(ang) * 8 * s)
                path = QPainterPath()
                path.moveTo(tip)
                path.lineTo(l)
                path.lineTo(r_)
                path.closeSubpath()
                p.setPen(QPen(QColor(0, 0, 0, 170), 1.4 * s))
                p.setBrush(white)
                p.drawPath(path)
            big = 20 * s
            t = (time.time() * 0.8) % 1.0                     # a soft ripple going out, like a sonar ping
            p.setPen(QPen(QColor(255, 255, 255, int(150 * (1 - t))), 1.6 * s))
            p.setBrush(Qt.NoBrush)
            p.drawEllipse(QPointF(X, Y), big / 2 + 2 * s + t * 9 * s, big / 2 + 2 * s + t * 9 * s)
            e = b.entry(pts, pin[1])
            MapView._pet_icon(p, QRectF(X - big / 2, Y - big / 2, big, big), b.icon(pin[1], e), b.ring(e), s * 0.8)
            draw_pin(p, X + big * 0.42, Y - big * 0.48, 4.2 * s, white)
        p.end()
