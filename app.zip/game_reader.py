"""
Reads Aion 2's own network data (read-only, like DPS meters do) so the overlay
doesn't need the original pet tracker.

Passive only: it listens with Npcap, never sends anything and never touches the game.
Works with ExitLag/VPNs (their traffic runs through the loopback adapter).

What it understands so far:
  0090  pet collection (sent at login / when the pet list refreshes)
  1b56  inventory slot update (item id + new count): soul pickups, gathering
  3336  entered zone (teleport / loading screen)
  ffff  LZ4-compressed bundle of other messages
"""
import re
import struct
import threading
import time
from collections import deque

import lz4.block

GAME_NAMES = {"aion2", "aion2-win64-shipping"}
SOUL_BASE = 534660000           # soul item id = SOUL_BASE + (petId - 999)


def soul_to_pet(item):
    return item - SOUL_BASE + 999


def rv(b, i):
    v = s = 0
    while True:
        x = b[i]
        i += 1
        v |= (x & 0x7F) << s
        s += 7
        if not x & 0x80:
            return v, i
        if s > 28:
            raise ValueError("bad varint")


class MessageStream:
    """Turns one direction of a TCP connection into game messages."""

    MAX_MSG = 4_000_000

    def __init__(self, on_message):
        self.on_message = on_message
        self.buf = bytearray()
        self.synced = False

    def _length_at(self, i):
        L, j = rv(self.buf, i)
        total = (j - i) + L - 4
        if total < (j - i) + 2 or total > self.MAX_MSG:
            return None
        return total, j

    def feed(self, data):
        self.buf += data
        i = 0
        b = self.buf
        while i < len(b) - 3:
            try:
                r = self._length_at(i)
            except (IndexError, ValueError):
                break                       # need more bytes
            if r is None:
                self.synced = False
                i += 1                      # stray byte or joined mid-stream: hunt for a header
                continue
            total, j = r
            if i + total > len(b):
                if not self.synced and total > 200_000:
                    i += 1                  # implausible while unsynced
                    continue
                break                       # wait for the rest
            if not self.synced:
                # only trust a guessed position if the next message also lines up
                k = i + total
                try:
                    nxt = self._length_at(k) if k < len(b) - 3 else None
                except (IndexError, ValueError):
                    nxt = None
                if k < len(b) - 3 and nxt is None:
                    i += 1
                    continue
                self.synced = True
            t = bytes(b[j:j + 2])
            body = bytes(b[j + 2:i + total])
            self._dispatch(t, body)
            i += total
        del self.buf[:i]
        if len(self.buf) > 8_000_000:       # never grow without limit
            del self.buf[:-1_000_000]
            self.synced = False

    def _dispatch(self, t, body, depth=0):
        if t == b"\xff\xff" and depth < 3 and len(body) > 4:
            raw = struct.unpack_from("<I", body, 0)[0]
            if raw > 20_000_000:
                return
            try:
                inner = lz4.block.decompress(body[4:], uncompressed_size=raw)
            except Exception:
                return
            i = 0
            while i < len(inner) - 3:
                try:
                    L, j = rv(inner, i)
                except (IndexError, ValueError):
                    return
                total = (j - i) + L - 4
                if total < (j - i) + 2 or i + total > len(inner):
                    i += 1
                    continue
                self._dispatch(inner[j:j + 2], inner[j + 2:i + total], depth + 1)
                i += total
            return
        try:
            self.on_message(t.hex(), body)
        except Exception:
            pass


class TcpDirection:
    """Minimal in-order TCP reassembly for one direction."""

    def __init__(self, stream):
        self.stream = stream
        self.next_seq = None
        self.pending = {}

    def add(self, seq, payload):
        if not payload:
            return
        if self.next_seq is None:
            self.next_seq = seq
        d = (seq - self.next_seq) & 0xFFFFFFFF
        if d >= 0x80000000:                         # old / retransmitted data
            overlap = (self.next_seq - seq) & 0xFFFFFFFF
            if overlap >= len(payload):
                return
            payload = payload[overlap:]
            seq = self.next_seq
            d = 0
        if d > 0:
            self.pending[seq] = payload
            if len(self.pending) > 2000:            # lost a packet: skip ahead and resync
                self.pending.clear()
                self.next_seq = None
                self.stream.synced = False
            return
        self.stream.feed(payload)
        self.next_seq = (seq + len(payload)) & 0xFFFFFFFF
        while self.next_seq in self.pending:
            p = self.pending.pop(self.next_seq)
            self.stream.feed(p)
            self.next_seq = (self.next_seq + len(p)) & 0xFFFFFFFF


class GameReader:
    """Listens on every adapter, follows the game's connections, emits events."""

    def __init__(self, on_event, log=print):
        self.on_event = on_event          # called from the capture thread: (kind, data)
        self.log = log
        self.local_ports = set()          # the game's own local TCP ports
        self.dirs = {}
        self.sniffers = []
        self.running = False
        self.status = "starting"
        self.packets = 0
        self.messages = 0
        self.watch = []                   # [(4-byte pattern, boss id)]
        self.rec, self.rec_until, self.rec_path = [], 0, None
        self.ip_bytes = {}                # game server address -> bytes received (busiest = the game world)
        self.self_eid = None

    def _learn_self(self, v):
        """You are the one entity the game sends a 1-a-second status tick for (2b38, 44 bytes). Used when
        the login message (3336) wasn't seen, e.g. the app restarted mid-session or you relogged."""
        now = time.time()
        ticks = self.__dict__.setdefault("_ticks", {})
        ticks.setdefault(v, []).append(now)
        if len(ticks[v]) > 30:
            del ticks[v][:-30]
        if self.self_eid and now - ticks.get(self.self_eid, [0])[-1] < 30:
            return                                 # still hearing from the one we know
        best = max(ticks, key=lambda k: sum(1 for x in ticks[k] if now - x < 15))
        n = sum(1 for x in ticks[best] if now - x < 15)
        if n >= 8 and best != self.self_eid:
            self.self_eid = best
            self.on_event("self", (best, None))
        for k in [k for k, xs in ticks.items() if now - xs[-1] > 60]:
            del ticks[k]

    def server_ip(self):
        return max(self.ip_bytes, key=self.ip_bytes.get) if self.ip_bytes else None

    def watch_ids(self, ids):
        self.watch = [(struct.pack("<I", i), i) for i in ids if i > 100000]

    # -- game process / connections (reads the Windows connection table only)
    def _watch(self):
        import psutil
        while self.running:
            ports = set()
            for p in psutil.process_iter(["name"]):
                n = (p.info["name"] or "").lower()
                if n.endswith(".exe"):
                    n = n[:-4]
                if n in GAME_NAMES:
                    try:
                        conns = p.net_connections(kind="tcp") if hasattr(p, "net_connections") \
                            else p.connections(kind="tcp")
                        for c in conns:
                            if c.raddr and c.raddr.port not in (80, 443):
                                ports.add(c.laddr.port)
                    except Exception:
                        pass
            self.local_ports = ports
            self.status = "reading" if ports else "waiting for Aion"
            time.sleep(3)

    def _packet(self, pkt):
        try:
            from scapy.layers.inet import IP, TCP
            if TCP not in pkt or IP not in pkt:
                return
            t = pkt[TCP]
            if t.dport not in self.local_ports:      # only server -> game data
                return
            payload = bytes(t.payload)
            if not payload:
                return
            self.packets += 1
            src = pkt[IP].src
            self.ip_bytes[src] = self.ip_bytes.get(src, 0) + len(payload)
            key = (src, t.sport, t.dport)
            d = self.dirs.get(key)
            if d is None:
                d = self.dirs[key] = TcpDirection(MessageStream(self._message))
            d.add(t.seq, payload)
        except Exception:
            pass

    @staticmethod
    def _records(body):
        """Bag/chest records: [inst u32][00][slot u16][00][item u32][count u32][4 x 00][container u8]."""
        out = {}
        for o in range(8, len(body) - 13):
            item = struct.unpack_from("<I", body, o)[0]
            if 100_000_000 <= item < 999_999_999 and body[o - 4] == 0 and body[o - 1] == 0 \
                    and body[o + 8:o + 12] == b"\0\0\0\0" and 1 <= body[o + 12] <= 30:
                count = struct.unpack_from("<I", body, o + 4)[0]
                if 0 < count < 100_000:
                    out[struct.unpack_from("<I", body, o - 8)[0]] = (item, count, body[o + 12])
        return out

    def record(self, secs, path):
        """Save every message for the next few seconds (used to learn new parts of the game data)."""
        if time.time() < self.rec_until:
            return
        self.rec, self.rec_until, self.rec_path = [], time.time() + secs, path

    def _flush_rec(self):
        try:
            import json
            with open(self.rec_path, "w", encoding="utf-8") as f:
                for row in self.rec:
                    f.write(json.dumps(row) + "\n")
        except Exception as e:
            self.log(f"recording failed: {e}")
        self.rec = []

    def _message(self, t, body):
        self.messages += 1
        if self.rec_until:
            if time.time() < self.rec_until:
                self.rec.append([round(time.time(), 2), t, body.hex()])
            else:
                self.rec_until = 0
                self._flush_rec()
        if t == "1b56" and len(body) >= 19:
            inst = struct.unpack_from("<I", body, 3)[0]
            item, count = struct.unpack_from("<II", body, 11)
            cont = body[23] if len(body) > 23 and 1 <= body[23] <= 30 else 1
            if 100_000_000 <= item < 999_999_999:
                self.on_event("item", (item, count, inst, cont))
        elif t == "1156" and len(body) > 100:          # login: bag and character chest
            inv = self._records(body)
            if inv:
                self.on_event("bag", inv)
        elif t == "0090" and len(body) > 8:
            pets = self._collection(body)
            if pets:
                self.on_event("collection", pets)
        elif t == "0d90" and len(body) >= 9:      # pet progress: [n][petId u32][amount u32]...
            n = body[0]
            for k in range(min(n, (len(body) - 1) // 8)):
                pet, amount = struct.unpack_from("<II", body, 1 + 8 * k)
                if 900 < pet < 2000 and 0 < amount < 200:
                    self.on_event("pet_souls", (pet, amount))
        elif t == "0240" and len(body) >= 5:      # entered a map / instance: [world u32][flag]
            self.on_event("zone", struct.unpack_from("<I", body, 0)[0])
        elif t == "3336":
            m = re.search(rb"\x0e\x00(..\x00\x00)\x00\x00\x00\x00\1\1", body)
            self.on_event("zone", struct.unpack("<I", m.group(1))[0] if m else None)
            try:                                  # starts with you: [entity][4][1][name length][name]
                v, o = rv(body, 0)
                o += 4
                if v and o + 2 < len(body) and 2 <= body[o + 1] <= 36:
                    name = body[o + 2:o + 2 + body[o + 1]].decode("utf-8")
                    if name.isprintable():
                        self.self_eid = v
                        self.on_event("self", (v, name))
            except (IndexError, ValueError):
                pass
        elif t in ("2a38", "2b38") and 20 <= len(body) <= 80:
            v, _o = rv(body, 0)                   # effects on you carry where you stand (last 12 bytes)
            if t == "2b38" and len(body) == 44:
                self._learn_self(v)
            if v and v == self.self_eid:
                x, y = struct.unpack_from("<ff", body, len(body) - 12)
                if abs(x) < 1e6 and abs(y) < 1e6 and (x or y):
                    self.on_event("self_pos", (x, -y))
        elif t == "0051" and len(body) > 40:      # entries left for timed content: [id u32][left][base][bonus]...
            table, o = {}, 2
            while o + 7 <= len(body):
                i = struct.unpack_from("<I", body, o)[0]
                if 17_000_000 <= i < 18_000_000 and body[o + 4] < 100:
                    table[i] = (body[o + 4], body[o + 5], body[o + 6])
                    o += 16
                else:
                    o += 1
            if table:
                self.content_base = {i: v[1:] for i, v in table.items()}
                self.on_event("content", table)
        elif t == "2937" and len(body) >= 18:     # something moved: [entity varint][2][x y z f32]
            v, sh, o = 0, 0, 0
            while o < 5:
                c = body[o]
                v |= (c & 0x7F) << sh
                o += 1
                sh += 7
                if c < 0x80:
                    break
            if o + 14 <= len(body):
                x, y = struct.unpack_from("<ff", body, o + 2)
                if abs(x) < 1e6 and abs(y) < 1e6:
                    self.on_event("move", (v, x, -y))
        elif t == "4136" and len(body) >= 24:     # a monster came into view: [entity varint][3][id u32][2][x y z f32]
            v, sh, o = 0, 0, 0
            while o < 5:
                c = body[o]
                v |= (c & 0x7F) << sh
                o += 1
                sh += 7
                if c < 0x80:
                    break
            if o + 21 <= len(body):
                mon = struct.unpack_from("<I", body, o + 3)[0]
                x, y = struct.unpack_from("<ff", body, o + 9)
                if abs(x) < 1e6 and abs(y) < 1e6:
                    self.on_event("npc", (v, mon, x, -y))     # y flipped to match the map data
        elif t == "0191" and len(body) > 16:      # field boss list (the map's Field Boss tab)
            fb = self._field_bosses(body)
            if fb:
                self.on_event("field_bosses", fb)
        elif t == "1338" and len(body) >= 13 and body[0] == 1:    # entry refreshed: [1][id][1][id][left][base][bonus]
            i = struct.unpack_from("<I", body, 1)[0]
            base = getattr(self, "content_base", {}).get(i)
            # the game also sends placeholder rows while loading; only rows that agree with the table count
            if base and body[1:5] == body[6:10] and body[10] < 100 and (body[11], body[12]) == base:
                self.on_event("content", {i: (body[10], body[11], body[12])})
        elif len(body) > 60:                      # any other list in the same shape (e.g. a chest you open)
            inv = self._records(body)
            if inv:
                self.on_event("store", (t, inv))
        if self.watch and t not in ("1b56", "1156", "0090", "0d90"):
            for pat, mid in self.watch:              # field / world boss ids seen in game data
                o = body.find(pat)
                if o >= 0:
                    self.on_event("boss_seen", (t, mid, o, body[max(0, o - 24):o + 40]))

    @staticmethod
    def _field_bosses(b):
        """(world, [(boss id, alive, time ms, (x, y, z) or None)]). time = spawned at (alive) or respawns at."""
        try:
            world = struct.unpack_from("<H", b, 2)[0]
            n, i = b[6], 7
            now = time.time() * 1000
            out = []
            for _ in range(n):
                alive = b[i]
                i += 1
                bid, i = rv(b, i)
                for off in range(0, 17):
                    t = struct.unpack_from("<Q", b, i + off)[0]
                    if abs(t - now) < 3 * 86400 * 1000:
                        pos = struct.unpack_from("<fff", b, i) if alive and off >= 12 else None
                        i += off + 8
                        break
                else:
                    return None
                out.append((bid, bool(alive), t, pos))
            return world, out
        except (struct.error, IndexError):
            return None

    @staticmethod
    def _collection(b):
        """{petId: (level, souls_in_level)}"""
        try:
            n, i = rv(b, 4)
            levels = {}
            for _ in range(n):
                pid, _pid2, lvl = struct.unpack_from("<III", b, i)
                levels[pid] = lvl
                i += 12
            m, i = rv(b, i)
            prog = {}
            for _ in range(m):
                pid, cur = struct.unpack_from("<II", b, i)
                prog[pid] = cur
                i += 8
        except (struct.error, IndexError, ValueError):
            return None
        if not levels or any(not (900 < p < 2000) for p in list(levels)[:5]):
            return None
        return {p: (levels[p], prog.get(p, 0)) for p in levels}

    def start(self):
        from scapy.all import AsyncSniffer, conf
        self.running = True
        threading.Thread(target=self._watch, daemon=True).start()
        for iface in conf.ifaces.values():
            try:
                sn = AsyncSniffer(iface=iface, filter="tcp", prn=self._packet, store=False)
                sn.start()
                self.sniffers.append(sn)
            except Exception:
                pass
        if not self.sniffers:
            self.status = "Npcap not available"

    def stop(self):
        self.running = False
        for sn in self.sniffers:
            try:
                sn.stop()
            except Exception:
                pass
