"""
Keeps Pet Overlay up to date by itself, on every PC that has it.

Each update is published on github.com/nmitsuu/pet-overlay-releases (files on its main branch):
  app.zip        the app's own files (code, icons, data); small, swapped in place, the app restarts
  PetOverlay.zip the whole program, on the repo's latest Release (only when its built-in parts change:
                 "runtime" goes up)
  version.json   {"version": "1.2.3", "runtime": 1}
Your own files (maps, saved settings, session, logs) are never touched.
"""
import json
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

REPO = "nmitsuu/pet-overlay-releases"
BASE = f"https://raw.githubusercontent.com/{REPO}/main/"
CHECK_EVERY = 10 * 60
NPCAP_URL = "https://npcap.com/dist/npcap-1.90.exe"
KEEP = {"maps", "samples", "__pycache__"}          # never replaced by an update


def _ver(v):
    try:
        return tuple(int(x) for x in str(v).lstrip("v").split("."))
    except ValueError:
        return (0,)


def _get(url, timeout=30):
    req = urllib.request.Request(url, headers={"User-Agent": "PetOverlay-updater",
                                               "Accept": "application/vnd.github+json"})
    return urllib.request.urlopen(req, timeout=timeout).read()


class Updater:
    def __init__(self, app_dir, log):
        self.app_dir = Path(app_dir)
        self.log = log
        self.state = "not checked yet"
        try:
            self.local = json.loads((self.app_dir / "version.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            self.local = {"version": "0.0.0", "runtime": 0}
        self.frozen = bool(getattr(sys, "frozen", False))

    def status(self):
        return f"v{self.local.get('version')} ({self.state})"

    def start(self):
        threading.Thread(target=self._loop, daemon=True, name="updater loop").start()

    def _loop(self):
        time.sleep(20)
        while True:
            try:
                self.check()
            except Exception as e:
                self.state = f"check failed: {e}"
            time.sleep(CHECK_EVERY)

    def check(self):
        try:
            remote = json.loads(_get(BASE + "version.json?t=%d" % int(time.time() // 300)))
        except urllib.error.HTTPError:
            self.state = "no update published yet"
            return
        assets = {"app.zip": BASE + "app.zip",
                  "PetOverlay.zip": f"https://github.com/{REPO}/releases/latest/download/PetOverlay.zip"}
        if _ver(remote.get("version")) <= _ver(self.local.get("version")):
            self.state = "up to date"
            return
        if self.frozen and remote.get("runtime", 0) > self.local.get("runtime", 0):
            self.state = f"updating program to v{remote['version']}"
            self._whole(assets["PetOverlay.zip"])
        else:
            self.state = f"updating to v{remote['version']}"
            self._app(assets["app.zip"])
            self.local = remote
            self.state = f"updated to v{remote['version']}"

    def _app(self, url):
        """Swap in the new app files; the app notices its files changed and restarts by itself."""
        tmp = Path(tempfile.mkdtemp(prefix="petoverlay_"))
        try:
            zp = tmp / "app.zip"
            zp.write_bytes(_get(url, 120))
            out = tmp / "x"
            with zipfile.ZipFile(zp) as z:
                for n in z.namelist():
                    if ".." in n or n.startswith(("/", "\\")):
                        raise ValueError("bad file name in update")
                z.extractall(out)
            files = [f for f in out.rglob("*") if f.is_file() and f.relative_to(out).parts[0] not in KEEP]
            # data and pictures first, code last (the restart starts once the code has changed)
            for f in sorted(files, key=lambda f: (f.suffix == ".py", f.name == "pet_overlay.py")):
                dst = self.app_dir / f.relative_to(out)
                dst.parent.mkdir(parents=True, exist_ok=True)
                part = dst.with_name(dst.name + ".new")
                shutil.copyfile(f, part)
                part.replace(dst)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def _whole(self, url):
        """New program files: unpack next to the app, then a small script swaps them in after we close."""
        exe_dir = Path(sys.executable).parent
        tmp = Path(tempfile.mkdtemp(prefix="petoverlay_"))
        zp = tmp / "PetOverlay.zip"
        zp.write_bytes(_get(url, 600))
        with zipfile.ZipFile(zp) as z:
            z.extractall(tmp / "x")
        src = next((p for p in (tmp / "x").iterdir() if p.is_dir()), tmp / "x")
        bat = tmp / "swap.bat"
        bat.write_text(
            "@echo off\r\n"
            "timeout /t 3 /nobreak >nul\r\n"
            f'robocopy "{src}" "{exe_dir}" /E /NFL /NDL /NJH /NJS /XD maps samples >nul\r\n'
            f'start "" "{sys.executable}"\r\n', encoding="utf-8")
        subprocess.Popen(["cmd", "/c", str(bat)], creationflags=0x08000000)
        from PySide6.QtWidgets import QApplication
        app = QApplication.instance()
        if app:
            from PySide6.QtCore import QTimer
            QTimer.singleShot(0, app.quit)


def ensure_npcap(log):
    """The packet reader the app needs. Its free version can't be installed silently, so the official
    installer is downloaded and opened once; one click on Install and the app works."""
    import os
    if Path(os.environ.get("WINDIR", r"C:\Windows"), "System32", "Npcap", "wpcap.dll").exists():
        return True
    try:
        exe = Path(tempfile.gettempdir()) / Path(NPCAP_URL).name
        if not exe.exists():
            exe.write_bytes(_get(NPCAP_URL, 300))
        import ctypes
        ctypes.windll.shell32.ShellExecuteW(None, "runas", str(exe), None, None, 1)
    except Exception as e:
        log(f"npcap install: {e}")
        import webbrowser
        webbrowser.open("https://npcap.com/#download")
    return False
